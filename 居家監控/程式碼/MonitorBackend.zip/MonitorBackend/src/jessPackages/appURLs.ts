

export function connectToPi(userId: string, uuid: string): void {
        
}