export type registerResult = {
    resultStatus: number
    errorMessage: string
    resultMessage: string
}