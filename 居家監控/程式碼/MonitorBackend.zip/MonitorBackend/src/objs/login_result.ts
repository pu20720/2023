export type loginResult = {
    resultStatus: number
    errorMessage: string
    resultData: string
}