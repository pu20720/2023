package jz;

public final class envSettings {
    public static final String ws_client_info = "ws://120.110.113.211:8080";
}
