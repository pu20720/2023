package jz;

import cclo.Main;

import javax.websocket.ClientEndpointConfig;
import javax.websocket.ContainerProvider;
import javax.websocket.Session;
import javax.websocket.WebSocketContainer;
import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ws_client {
    private WebSocketContainer container;
    private client_endpoint endpoint;
    private Map<String, List<String>> headers = new HashMap<>();
    private ClientEndpointConfig con;
    private Client_config config;

    public ws_client(Main pMain) {
        this.config = new Client_config();
        this.config.beforeRequest(headers);
        this.container = ContainerProvider.getWebSocketContainer();
        this.endpoint = new client_endpoint(pMain);
        this.con = ClientEndpointConfig.Builder.create().configurator(this.config).build();
    }

    public void pingServer() {
        try {
            this.container.connectToServer(this.endpoint, this.con, new URI(envSettings.ws_client_info));
//            System.out.println(this.config);
            System.out.print("==============connect to WS==============");
            this.endpoint.sendMessage("pi://connect");
        } catch (Exception e) {
            System.out.println("pingServer error");
        }
    }

    public void sendMessage(String str) {
        try {
            this.endpoint.sendMessage(str);
        } catch (Exception e) {
            System.out.println("sendMessage error");
        }
    }

}

class Client_config extends ClientEndpointConfig.Configurator {
    @Override
    public void beforeRequest(Map<String, List<String>> headers) {
        headers.put("token", Arrays.asList("-2"));
    }
}