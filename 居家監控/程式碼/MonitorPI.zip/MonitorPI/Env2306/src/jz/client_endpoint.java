package jz;

import cclo.Main;

import javax.websocket.*;
import java.io.IOException;

public class client_endpoint extends Endpoint {
    private Session session;
    private final Main pMain;

    public client_endpoint(Main pMain) {
        this.pMain = pMain;
    }

    @Override
    public void onOpen(Session session, EndpointConfig endpointConfig) {
        this.session = session;
        this.session.addMessageHandler(new MessageHandler.Whole<String>() {
            @Override
            public void onMessage(String message) {
                receiveMessage(message);
            }
        });
    }

    @Override
    public void onClose(Session session, CloseReason closeReason) {
        super.onClose(session, closeReason);
        pMain.stopRec();
    }

    public void receiveMessage(String message) {
        System.out.println("backend: " + message);
        if ("pi://startRec".equals(message)) {
//            CLIENT.client.sendMessage("Jess-start rec");
            pMain.startRec();
        } else if ("pi://stopRec".equals(message)) {
            pMain.stopRec();
        } else if ("not message".equals(message)) {
            System.out.println("Jess" + message);
        }
    }

    public void sendMessage(String message) throws IOException {
        this.session.getBasicRemote().sendText(message);
    }
}
