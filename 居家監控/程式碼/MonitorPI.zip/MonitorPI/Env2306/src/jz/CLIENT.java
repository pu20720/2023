package jz;

public class CLIENT {
    public static ws_client client;
//    紀錄錄音狀態 true->recording

    public static void setCLIENT(ws_client client) {
        CLIENT.client = client;
    }
}
