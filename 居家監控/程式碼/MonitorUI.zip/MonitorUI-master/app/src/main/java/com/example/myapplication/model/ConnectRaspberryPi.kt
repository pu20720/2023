package com.example.myapplication.model

data class ConnectRaspberryPi(
    val name : String
)