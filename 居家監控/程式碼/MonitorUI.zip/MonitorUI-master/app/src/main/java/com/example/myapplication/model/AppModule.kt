package com.example.myapplication.model
/*
import android.app.Application
import dagger.Module
import dagger.Provides

@Module
class AppModule(private val application: myapplicationApplication) {

    @Provides
    fun getApp(): Application = application

    @Provides
    fun getMCLApp(): myapplicationApplication = application
}

*/