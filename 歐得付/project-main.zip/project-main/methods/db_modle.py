import sqlite3

# Connect to or create a new SQLite database file
conn = sqlite3.connect('orderfood.db')

# Create a cursor object
cursor = conn.cursor()

# Create a stores table
cursor.execute('''
    CREATE TABLE IF NOT EXISTS stores (
        id INTEGER PRIMARY KEY,
        area TEXT,
        store TEXT,
        main TEXT,
        submain TEXT
    )
''')
conn.commit()

# Create a users table
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        email TEXT,
        pwd TEXT,
        acc TEXT,
        name TEXT,
        phone INTEGER
    )
''')
conn.commit()

# Create a orders table
cursor.execute('''
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY,
        u_id INTEGER,
        s_id INTEGER,
        count INTEGER,
        money INTEGER,
        createTime DATETIME,
        s_name TEXT,
        s_main TEXT,
        FOREIGN KEY (u_id) REFERENCES users(id),
        FOREIGN KEY (s_id) REFERENCES stores(id)
    )
''')
conn.commit()

# Create a complete_order table
cursor.execute('''
    CREATE TABLE IF NOT EXISTS complete_order (
        id INTEGER PRIMARY KEY,
        u_id INTEGER,
        s_id INTEGER,
        count INTEGER,
        money INTEGER,
        createTime DATETIME,
        s_name TEXT,
        s_main TEXT,
        FOREIGN KEY (u_id) REFERENCES users(id),
        FOREIGN KEY (s_id) REFERENCES stores(id)
    )
''')
conn.commit()


conn.close()