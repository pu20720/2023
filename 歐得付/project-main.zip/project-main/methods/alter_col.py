import sqlite3

conn = sqlite3.connect('orderfood.db')
cursor = conn.cursor()

# alter col

# cursor.execute('''
#     ALTER TABLE orders
#     ADD COLUMN s_main TEXT;
# ''')


conn.commit()