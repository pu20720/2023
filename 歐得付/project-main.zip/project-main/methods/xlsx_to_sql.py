import pandas as pd
import sqlite3

excel_file = "main.xlsx"
df = pd.read_excel(excel_file)

db_path = 'orderfood.db'
conn = sqlite3.connect(db_path)

table_name = 'stores'
df.to_sql(table_name, conn, if_exists='append', index=False)

conn.close()