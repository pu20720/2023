# NOTE
## structure
```
Project
|---methods/
|   |---alter_col.py
|   |---db_model.py
|   |---xlsx_to_sql.py
|---static/
|   |---img/
|   |   |---background.jpg
|   |---js/
|   |   |---morninghill.js
|   |---style/
|       |---home.css
|---templates/
|   |---base.hmtl
|   |---home.html
|   |---login.hmtl
|   |---register.hmtl
|   |---shop.hmtl
|   |---shoppingcart.hmtl
|   |---store.html
|---app.py
|---main.xlsx
|---note.md
|orderfood.db

```
## database design
### orderfood.db
**stores**  
|s_id|area|store|main|submain|money|
|---|---|---|---|---|---|
|品項id|靜園|極咖哩|品項|子品項|價錢|
|.|靜園|極咖哩|拉麵|豬排|75|
||宜園|早安山丘||||
||至善|好吃鮮果||||

**users**
|u_id|email|pwd|acc|name|phone|
|---|---|---|---|---|---|
|1|auth@auth.com|admin|admin|admin|0912345678|

**order**
|id|u_id|s_id|count|money|createTime|s_name|s_main|
|---|---|---|---|---|---|---|---|
|1|1|1|2|60|2023-08-29 00:00:00|極咖哩|咖哩豬排|
|2|1|3|3|150|2023-09-01 12:00:00|極咖哩|咖哩水煮雞肉|

**complete_order**
|id|u_id|s_id|count|money|createTime|s_name|s_main|
|---|---|---|---|---|---|---|---|
|1|1|3|3|150|2023-09-01 12:00:00|極咖哩|咖哩水煮雞肉|
  
Edit in 2023/10/23