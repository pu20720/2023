from flask import Flask, render_template, redirect, request, url_for, session
import sqlite3
import datetime

app = Flask("__main__")
db_path = 'orderfood.db'
app.config['SECRET_KEY'] = 'your_secret_key'

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/store')
def store():
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    col1 = 'area'
    col2 = 'store'
    cursor.execute(f"SELECT DISTINCT {col1},{col2} FROM stores")
    areas_and_store = cursor.fetchall()
    store_list = []
    for store in areas_and_store:
        store_list.append(store)
    print(store_list)
    return render_template('store.html', store_list = store_list)

@app.route('/shoppingcart')
def shoppingcart():
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    orders = cursor.execute("select * from orders where u_id = ?", (session['id'],)).fetchall()
    print(orders)
    return render_template('shoppingcart.html', orders = orders)

@app.route('/stores/<string:stores>', methods=['GET','POST'])
def shop(stores):

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    store = str(stores)
    mains = cursor.execute(f"SELECT * FROM stores where store ='{store}'").fetchall()
    main = cursor.execute(f"SELECT DISTINCT store, main FROM stores where store='{store}'").fetchall()
    if request.method == 'GET':
        return render_template('shop.html',store = stores ,mains = mains ,main = main)
    elif request.method == 'POST':
        data = request.form
        d = request.form.get('count')
        print("------------------")
        print(data)
        print(d)

        o = cursor.execute(f"SELECT * FROM stores where main = ? and submain = ?", (data['main'], data['submain'])).fetchone()
        u = session['id']
        s_id = o[0]
        money = o[5]*int(data['count'])
        print("u_id:", u, "s_id:", s_id, "count:", data['count'], "money:", money, "createTime:", datetime.datetime.now(), "s_name:", o[2], "s_main:", data['main']+data['submain'])
        cursor.execute(f"INSERT INTO orders (u_id, s_id, count, money, createTime, s_name, s_main) VALUES (?, ?, ?, ?, ?, ?, ?)", (u, s_id, data['count'], money, datetime.datetime.now(), o[2], data['main']+data['submain']))
        conn.commit()
        return render_template('shop.html',store = stores ,mains = mains ,main = main)
    else:
        return '<h1>404'

@app.route('/register', methods=['GET','POST'])
def register():
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    if request.method == 'GET':
        return render_template('register.html')
    elif request.method == 'POST':
        data = request.form
        print('信箱:', data['mail'],'密碼:', data['pwd'], '密碼:', data['acc'], '名字:', data['name'], '手機:', data['phone'])
        phone = data['phone'][1:]
        print(phone)
        check_email = cursor.execute("SELECT * FROM users WHERE email = ?", (data['mail'],)).fetchone()
        check_acc = cursor.execute("SELECT * FROM users WHERE acc = ?", (data['acc'],)).fetchone()
        check_phone = cursor.execute("SELECT * FROM users WHERE phone = ?", (phone,)).fetchone()
        print('email\t比對資料:', check_email)
        print('帳號\t比對資料:', check_acc)
        print('phone\t比對資料:', check_phone)
        if check_email:
            err = 'Email 已存在!'
            return render_template('register.html', danger = err)
        elif check_acc:
            err = 'Account 已存在!'
            return render_template('register.html', danger = err)
        elif check_phone:
            err = 'Phone 已存在!'
            return render_template('register.html', danger = err)
        elif data['pwd'] != data['cpwd']:
            err = '密碼不正確!'
            return render_template('register.html', danger = err)
        else:
            cursor.execute('INSERT INTO users (email, pwd, acc, name, phone) VALUES (?, ?, ?, ?, ?)', (data['mail'], data['pwd'], data['acc'], data['name'], phone))
            conn.commit()
            return redirect(url_for('login'))
    
    else:
        return '<h1>404'
   
@app.route('/login', methods=['GET','POST'])
def login():
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    if request.method == 'GET':
        return render_template('login.html')
    elif request.method == 'POST':
        data = request.form
        print(data)
        phone = data['login_text'][1:]
        check_email = cursor.execute("SELECT * FROM users WHERE email = ? and pwd = ?", (data['login_text'], data['pwd'])).fetchone()
        check_acc = cursor.execute("SELECT * FROM users WHERE acc = ? and pwd = ?", (data['login_text'], data['pwd'])).fetchone()
        check_phone = cursor.execute("SELECT * FROM users WHERE pwd = ? and phone = ?", (data['pwd'], phone)).fetchone()
        print(check_acc)
        if check_email:
            print(check_email)
            session['name'] = check_email[4]
            session['id'] = check_email[0]
            return redirect(url_for('home'))
        elif check_acc:
            print(check_acc)
            session['name'] = check_acc[4]
            session['id'] = check_acc[0]
            return redirect(url_for('home'))
        elif check_phone:
            print(check_phone)
            session['name'] = check_phone[4]
            session['id'] = check_phone[0]
            return redirect(url_for('home'))
        else:
            err = '帳號或密碼錯誤'
            return render_template('login.html', danger = err)
    else:
        return '<h1>404'

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

@app.route('/del/<int:order>')
def delt(order):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM orders WHERE id = ?", (order,))
    conn.commit()
    return redirect(url_for('shoppingcart'))

@app.route('/del_order/<int:order>')
def delt_order(order):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM complete_order WHERE id = ?", (order,))
    conn.commit()
    return redirect(url_for('order'))

@app.route('/comp/<int:order>')
def comp(order):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    compl = cursor.execute("select * FROM orders WHERE id = ?", (order,)).fetchone()
    cursor.execute(f"INSERT INTO complete_order (u_id, s_id, count, money, createTime, s_name, s_main) VALUES (?, ?, ?, ?, ?, ?, ?)", (compl[1], compl[2], compl[3], compl[4], compl[5], compl[6], compl[7]))
    conn.commit()
    cursor.execute("DELETE FROM orders WHERE id = ?", (order,))
    conn.commit()
    return redirect(url_for('shoppingcart'))

@app.route('/order')
def order():
    order_info = []
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    ord = cursor.execute("SELECT * FROM complete_order WHERE s_name = ?", (session['name'],)).fetchall()
    for o in ord:
        print('訂單',o)
        set_u_id = o[1]
        u_info = cursor.execute("SELECT phone, name FROM users WHERE id = ?", (set_u_id,)).fetchone()
        print('u_info',u_info)
        info = (o[0], o[1], o[2], o[3], o[4], o[5], o[6], o[7], u_info[0], u_info[1])
        order_info.append(info)
    return render_template('order.html', order_info = order_info)

if __name__ == "__main__":
    app.run(debug=True)