//
//  MyMapView.swift
//  easycar10
//
//  Created by EC on 2023/11/15.
//

import SwiftUI
import MapKit

struct MyMapView: UIViewRepresentable {
   let destination: CLLocationCoordinate2D
    
    var landmarks: [LandmarkAnnotation]?
    
    func makeUIView(context: Context) -> MKMapView {
        MKMapView(frame: .zero)
    }
    
    func updateUIView(_ uiView: MKMapView, context: Context) {
        
        let coordinate = destination
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let region = MKCoordinateRegion(center: coordinate, span: span)
        uiView.setRegion(region, animated: true)
        
        uiView.delegate = context.coordinator
        
        uiView.showsUserLocation = true
        uiView.addAnnotations(landmarks ?? [])
    }
    
    func makeCoordinator() -> MyMapViewCoordinator {
        MyMapViewCoordinator(self)
    }
    
    func drawRoute(_ uiView: MKMapView,  _ start:CLLocationCoordinate2D, _ end:CLLocationCoordinate2D, isChangeRegion:Bool){
        let startPlacemark = MKPlacemark(coordinate: start)
        let endPlacemark = MKPlacemark(coordinate: end)
        let startMapItem = MKMapItem(placemark: startPlacemark)
        let endMapItem = MKMapItem(placemark: endPlacemark)
        
        let directionRequest = MKDirections.Request()
        directionRequest.source = startMapItem
        directionRequest.destination = endMapItem
        directionRequest.transportType = .automobile
        let directions = MKDirections(request: directionRequest)
        
        directions.calculate(completionHandler: {(response, err) in
            guard let response = response else {
                if let err = err{
                    print("Error: \(err)")
                }
                return
            }
            let route = response.routes[0]
            uiView.removeOverlays(uiView.overlays)
            uiView.addOverlay(route.polyline, level: .aboveRoads)
            if isChangeRegion{
                let rect = route.polyline.boundingMapRect
                uiView.setRegion(MKCoordinateRegion(rect), animated: true)
            }
        })
    }
}

class MyMapViewCoordinator: NSObject, MKMapViewDelegate {
    var myMapViewController: MyMapView
    
    var isFirst = true
    
    init(_ control: MyMapView){
        self.myMapViewController = control
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if let routePolyline = overlay as? MKPolyline {
            let renderer = MKPolylineRenderer(polyline: routePolyline)
            renderer.strokeColor = UIColor.systemBlue
            renderer.lineWidth = 6
            return renderer
        }
        return MKOverlayRenderer()
    }
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let start = userLocation.coordinate
        self.myMapViewController.drawRoute(mapView, start, self.myMapViewController.destination, isChangeRegion: isFirst)
        isFirst = false
    }
}
