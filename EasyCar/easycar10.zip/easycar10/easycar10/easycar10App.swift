//
//  easycar10App.swift
//  easycar10
//
//  Created by EC on 2023/11/9.
//

import SwiftUI


@main
struct easycar10App: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContetView()
        }
    }
}
