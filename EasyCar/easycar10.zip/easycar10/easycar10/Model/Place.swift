//
//  Place.swift
//  easycar10
//
//  Created by EC on 2023/11/10.
//

import SwiftUI
import MapKit

struct Place: Identifiable {
    
    var id = UUID().uuidString
    var place:CLPlacemark
}
