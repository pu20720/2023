//
//  ContetView.swift
//  easycar10
//
//  Created by EC on 2023/11/10.
//

import SwiftUI
import MapKit

struct ContetView: View {
    var body: some View {
        Home()
    }
}

struct ContetView_Previews: PreviewProvider {
    static var previews: some View {
       ContetView()
    }
}

