//
//  ContentView.swift
//  easycar10
//
//  Created by EC on 2023/11/9.
//

import SwiftUI
import CoreData
import MapKit

struct ContentView: View {
    @State private var cameraPosition: MapCameraPosition = .region(.userRegion)
    
    var body: some View {
        Map(position: $cameraPosition){
           // MapMarker("My location", systemImage: "paperplane", coordinate" .userLocation)
           //tint(.blue)
            Annotation("My location", coordinate: .userLocation){
                ZStack{
                    Circle()
                        .frame(weight: 100, height: 100)
                        .foregroundStyle(.blue.opacity(0.25))
                }
            }
        }
    }
}
extension CLLocationCoordinate2D{
    static var userLocation: CLLocationCoordinate2D{
        return .init(latitude: 25.7682, longitude: -80.1959)
    }
}
extension MKCoordinateRegion{
    static var userRegion: MKCoordinateRegion{
        return .init(center: .userLocation, latitudinalMeters: 10000, longitudinalMeters: 10000)
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
