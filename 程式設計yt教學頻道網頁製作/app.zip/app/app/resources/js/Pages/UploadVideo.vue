<script setup>
import { Head, useForm } from "@inertiajs/vue3";
import MainLayout from "@/Layouts/MainLayout.vue";

const props = defineProps({
    canLogin: Boolean,
    canRegister: Boolean,
});

const form = useForm({
    title: "",
    video_url: "",
    programming_language: "",
    difficulty: null,
});

function submit() {
    form.post(route("video.create"));
}
</script>

<template>
    <Head title="上傳題目" />

    <MainLayout :canLogin="canLogin" :canRegister="canRegister">
        <template #content>
            <div style="padding-left: 8vw">
                <form
                    class="w-2/3 px-16 py-8 flex flex-col gap-4 bg-white dark:bg-gray-800"
                    @submit.prevent="submit"
                >
                    <div class="flex items-center">
                        <label for="title" class="w-32 dark:text-white">題目名稱</label>
                        <input
                            class="w-full rounded-md"
                            type="text"
                            name="title"
                            v-model="form.title"
                        />
                    </div>
                    <p v-if="form.errors.title" class="text-red-500">
                        {{ form.errors.title }}
                    </p>

                    <div class="flex items-center">
                        <label for="video_url" class="w-32 dark:text-white">影片連結</label>
                        <input
                            class="w-full rounded-md"
                            type="text"
                            name="video_url"
                            v-model="form.video_url"
                        />
                    </div>
                    <p class="text-gray-400 ml-32">
                        網址格式 https://www.youtube.com/watch?v=[影片id]
                    </p>
                    <p v-if="form.errors.video_url" class="text-red-500">
                        {{ form.errors.video_url }}
                    </p>

                    <div class="flex items-center">
                        <label for="programming_language" class="w-32 dark:text-white"
                            >程式語言</label
                        >
                        <input
                            class="w-full rounded-md"
                            type="text"
                            name="programming_language"
                            v-model="form.programming_language"
                        />
                    </div>
                    <p
                        v-if="form.errors.programming_language"
                        class="text-red-500"
                    >
                        {{ form.errors.programming_language }}
                    </p>

                    <div class="flex items-center">
                        <label for="difficulty" class="w-32 dark:text-white">CPE星數</label>
                        <select
                            class="w-full rounded-md"
                            name="difficulty"
                            v-model="form.difficulty"
                        >
                            <option value=""></option>
                            <option :value="i" v-for="i in 5" :key="i">
                                {{ i }}★
                            </option>
                        </select>
                    </div>
                    <p v-if="form.errors.difficulty" class="text-red-500">
                        {{ form.errors.difficulty }}
                    </p>

                    <button
                        class="mt-4 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mx-auto self-center"
                    >
                        上傳
                    </button>
                </form>
            </div>
        </template>
    </MainLayout>
</template>
