<script setup>
import { Head } from "@inertiajs/vue3";
import MainLayout from "@/Layouts/MainLayout.vue";

const props = defineProps({
    canLogin: Boolean,
    canRegister: Boolean,
    students: Array,
});
</script>

<template>
    <Head title="學生列表" />

    <MainLayout :canLogin="canLogin" :canRegister="canRegister">
        <template #content>
            <div style="padding-left: 8vw">
                <div class="w-2/3 px-16 py-8 bg-white dark:bg-gray-800">
                    <table class="table-fixed w-full">
                        <thead>
                            <tr class="bg-gray-600 text-white">
                                <th class="border border-white text-left px-2">
                                    信箱
                                </th>
                                <th
                                    class="border border-white text-left px-2 min-w-32 max-w-64"
                                >
                                    使用者名稱
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="student in students" :key="student.id" class="dark:text-white">
                                <td>{{ student.email }}</td>
                                <td>{{ student.name }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </template>
    </MainLayout>
</template>
