<script setup>
import { Head } from "@inertiajs/vue3";
import MainLayout from "@/Layouts/MainLayout.vue";
import CommentSection from "@/Components/comment/CommentSection.vue";

const props = defineProps({
    canLogin: Boolean,
    canRegister: Boolean,
    video: Object,
    likesState: Object,
});
</script>

<template>
    <Head :title="video.title" />

    <MainLayout :canLogin="canLogin" :canRegister="canRegister">
        <template #content>
            <div class="pt-10 grid grid-cols-12">
                <div class="col-span-10">
                    <!-- video -->
                    <iframe
                        class="w-full sm:px-4"
                        height="600"
                        :src="video.video_url"
                        :title="video.title"
                        frameborder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowfullscreen
                    ></iframe>
                    <div class="mt-8 sm:px-2 lg:px-10 dark:text-white">
                        <div class="flex leading-7 items-center gap-2">
                            <p class="text-3xl font-semibold">
                                {{ video.title }}
                            </p>
                            <p class="text-lg">{{ video.difficulty }}★</p>
                            <p class="text-lg ml-auto">
                                {{
                                    new Date(video.created_at).toLocaleString()
                                }}
                            </p>
                        </div>
                        <div>
                            <div
                                class="mt-2 text-base text-gray-600 dark:text-gray-400 text-sm"
                            >
                                {{ video.description }}
                            </div>
                        </div>
                        <p class="text-xl">{{ video.creator?.name }}</p>
                    </div>
                    <!-- end video -->
                    <hr class="my-6" />
                    <!-- comments -->
                    <CommentSection
                        :videoId="video.id"
                        :comments="video.comments"
                        :likesState="likesState"
                    />
                    <!-- end comments -->
                </div>
                <div class="col-span-2 dark:text-white">
                    <p class="text-3xl">{{ video.programming_language }}</p>
                </div>
            </div>
        </template>
    </MainLayout>
</template>
