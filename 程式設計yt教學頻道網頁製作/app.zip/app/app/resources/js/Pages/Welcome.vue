<script setup>
import { Head } from "@inertiajs/vue3";
import VideoCards from "@/Components/VideoCards.vue";
import MainLayout from "@/Layouts/MainLayout.vue";
import { useContextStore } from "@/Stores/context";

const store = useContextStore();

defineProps({
    canLogin: Boolean,
    canRegister: Boolean,
    videos: Array,
});
</script>

<template>
    <Head title="首頁" />

    <MainLayout :canLogin="canLogin" :canRegister="canRegister">
        <template #content>
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div
                    class="mt-8 overflow-hidden sm:rounded-lg dark:bg-gray-800 "
                >
                    <div class="grid grid-cols-1 md:grid-cols-3 md:gap-3">
                        <VideoCards
                            :videos="
                                store.difficulty
                                    ? videos.filter(
                                          (video) =>
                                              video.difficulty ===
                                              store.difficulty
                                      )
                                    : videos
                            "
                        />
                    </div>
                </div>
            </div>
        </template>
    </MainLayout>
</template>
