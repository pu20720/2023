<script setup>
import { Link } from "@inertiajs/vue3";

defineProps({
    videos: Array,
});
</script>

<template>
    <div class="p-6" v-for="video in videos" :key="video.id">
        <div>
            <Link :href="route('video', video.id)">
                <img :src="video.cover" :alt="video.title" />
            </Link>
        </div>

        <div class="flex items-center">
            <div class="mt-2 text-2xl leading-7 font-semibold">
                <Link
                    :href="route('video', video.id)"
                    class="text-gray-900 dark:text-white"
                    >{{ video.title }}
                </Link>
            </div>
        </div>

        <div class="">
            <div class="mt-2 text-gray-600 dark:text-gray-400 text-sm">
                {{ video.description }}
            </div>
        </div>
    </div>
</template>
