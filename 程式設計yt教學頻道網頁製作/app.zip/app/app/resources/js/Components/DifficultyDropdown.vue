<script setup>
import Dropdown from "@/Components/Dropdown.vue";
import { useContextStore } from "@/Stores/context";

const store = useContextStore();

const setDifficulty = (difficulty) => {
    difficulty = difficulty !== store.difficulty ? difficulty : 0;
    store.setDifficulty(difficulty);
};
</script>

<template>
    <Dropdown>
        <template #trigger>
            <button
                type="button"
                class="border border-transparent rounded-md focus:outline-none focus:bg-gray-100 active:bg-gray-50 transition"
            >
                題庫難度
            </button>
        </template>
        <template #content>
            <div
                :class="
                    ['block', 'px-4', 'py-2', 'hover:bg-gray-300'].concat(
                        i === store.difficulty ? 'bg-gray-300' : []
                    )
                "
                v-for="i in 5"
                :key="i"
                @click="setDifficulty(i)"
            >
                {{ i }}★
            </div>
        </template>
    </Dropdown>
</template>
