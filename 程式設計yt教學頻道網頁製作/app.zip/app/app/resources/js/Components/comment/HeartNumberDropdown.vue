<script setup>
import Dropdown from "@/Components/Dropdown.vue";
import { useCommentFilterStore } from "@/Stores/commentFilter";

const store = useCommentFilterStore();

const setOrder = (order) => {
    order = order !== store.heart_number ? order : null;
    store.setHeartNumberFilter(order);
};
</script>

<template>
    <Dropdown>
        <template #trigger>
            <button
                type="button"
                class="border border-transparent rounded-md dark:text-white focus:outline-none focus:bg-gray-100 active:bg-gray-50 transition"
            >
                愛心數排序
            </button>
        </template>
        <template #content>
            <div
                :class="
                    ['block', 'px-4', 'py-2', 'hover:bg-gray-300'].concat(
                        k === store.heart_number ? 'bg-gray-300' : []
                    )
                "
                v-for="[k, v] in Object.entries({
                    desc: '最多人喜歡優先',
                    asc: '最少人喜歡優先',
                })"
                :key="k"
                @click="setOrder(k)"
            >
                {{ v }}
            </div>
        </template>
    </Dropdown>
</template>
