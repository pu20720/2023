<script setup>
import { usePage } from "@inertiajs/vue3";
import { computed } from "vue";

const props = defineProps({
    comments: Array,
    likesState: Object,
});

const user = computed(() => usePage().props.user);

const likeComment = async (commentId) => {
    try {
        const response = await window.axios.post(
            route("comment.like.create", commentId),
            {},
            {
                headers: {
                    "content-type": "application/json",
                    accept: "application/json",
                },
            }
        );

        if (response.status == 200) {
            const likeState = props.likesState[commentId];
            if (likeState) {
                Object.assign(likeState, {
                    heart_number: likeState.heart_number + 1,
                    liked: 1,
                });
            } else {
                props.likesState[commentId] = {
                    heart_number: 1,
                    liked: 1,
                };
            }
        }
    } catch {}
};

const dislikeComment = async (commentId) => {
    try {
        const response = await window.axios.post(
            route("comment.like.delete", commentId),
            {},
            {
                headers: {
                    "content-type": "application/json",
                    accept: "application/json",
                },
            }
        );

        if (response.status == 200) {
            const likeState = props.likesState[commentId];
            if (likeState) {
                Object.assign(likeState, {
                    heart_number: likeState.heart_number - 1,
                    liked: 0,
                });
            } else {
                likeState = {
                    heart_number: 0,
                    liked: 0,
                };
            }
        }
    } catch {}
};
</script>

<template>
    <div
        v-for="comment in comments"
        :key="comment.id"
        class="items-center flex"
    >
        <!-- <img
            class="inline-block w-12 h-12 rounded-full"
            :src="comment.user.avatar"
            :alt="comment.user.name"
        /> -->
        <section class="w-full inline-block ml-4">
            <div
                class="flex items-center gap-2 mb-2 text-xl leading-7 font-semibold"
            >
                <p class="text-gray-900 dark:text-white">
                    {{ comment.user.name }}
                </p>
                <p class="text-gray-600 text-sm">
                    {{ new Date(comment.created_at).toLocaleString() }}
                </p>
                <span class="ml-auto dark:text-white">
                    <button
                        :class="[
                            likesState[comment.id]?.liked ? 'text-red-500' : '',
                        ]"
                        :title="user ? '喜歡' : '登入即可支持留言'"
                        :disabled="!user"
                        @click="
                            () =>
                                likesState[comment.id]?.liked
                                    ? dislikeComment(comment.id)
                                    : likeComment(comment.id)
                        "
                    >
                        ♥
                    </button>
                    {{ likesState[comment.id]?.heart_number ?? 0 }}
                </span>
            </div>
            <span
                class="whitespace-pre-line text-md text-gray-600 dark:text-gray-400"
            >
                {{ comment.content }}
            </span>
        </section>
    </div>
</template>
