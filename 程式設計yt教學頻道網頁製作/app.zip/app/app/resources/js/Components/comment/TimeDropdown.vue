<script setup>
import Dropdown from "@/Components/Dropdown.vue";
import { useCommentFilterStore } from "@/Stores/commentFilter";

const store = useCommentFilterStore();

const setOrder = (order) => {
    order = order !== store.time ? order : null;
    store.setTimeFilter(order);
};
</script>

<template>
    <Dropdown>
        <template #trigger>
            <button
                type="button"
                class="border border-transparent rounded-md dark:text-white focus:outline-none focus:bg-gray-100 active:bg-gray-50 transition"
            >
                時間排序
            </button>
        </template>
        <template #content>
            <div
                :class="
                    ['block', 'px-4', 'py-2', 'hover:bg-gray-300'].concat(
                        k === store.time ? 'bg-gray-300' : []
                    )
                "
                v-for="[k, v] in Object.entries({
                    desc: '最新優先',
                    asc: '最舊優先',
                })"
                :key="k"
                @click="setOrder(k)"
            >
                {{ v }}
            </div>
        </template>
    </Dropdown>
</template>
