<script setup>
import { Link, usePage } from "@inertiajs/vue3";
import { computed, reactive } from "vue";
import HeartNumberDropdown from "@/Components/comment/HeartNumberDropdown.vue";
import TimeDropdown from "@/Components/comment/TimeDropdown.vue";
import { useCommentFilterStore } from "@/Stores/commentFilter";
import CommentList from "@/Components/comment/CommentList.vue";
import _ from "lodash";

const store = useCommentFilterStore();

const props = defineProps({
    videoId: Number,
    comments: Array,
    likesState: Object,
});

const form = reactive({
    content: "",
});

const user = computed(() => usePage().props.user);

const commentsOrdered = computed(() => {
    const fields = [];
    const orders = [];
    if (store.time) {
        fields.push("created_at");
        orders.push(store.time);
    }
    if (store.heart_number) {
        fields.push("heart_number");
        orders.push(store.heart_number);
    }

    props.comments.forEach((comment) => {
        comment.heart_number = props.likesState[comment.id]?.heart_number ?? 0;
    });

    return _.orderBy(props.comments, fields, orders);
});

const createComment = async () => {
    try {
        const response = await window.axios.post(
            route("comment.create", props.videoId),
            form,
            {
                headers: {
                    "content-type": "application/json",
                    accept: "application/json",
                },
            }
        );

        if (response.status == 200) {
            props.comments.push({
                ...response.data,
                user: user,
            });
            form.content = "";
        }
    } catch {}
};
</script>

<template>
    <div class="my-2 mx-4 py-4 sm:px-2 lg:px-8 grid grid-cols-1 gap-3 bg-white dark:bg-gray-800">
        <p class="font-semibold text-3xl dark:text-white">留言區</p>

        <!-- filter -->
        <div class="w-full flex gap-3 justify-end border-b">
            <TimeDropdown />
            <HeartNumberDropdown />
        </div>

        <!-- list -->
        <CommentList :comments="commentsOrdered" :likesState="likesState" />
        <!-- END list -->

        <!-- input -->
        <div v-if="user" class="flex row items-center mt-6">
            <textarea
                v-model="form.content"
                rows="2"
                style="width: 50vw"
                class="inline-block p-2.5 text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
            ></textarea>
            <button
                class="ml-3 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                @click="createComment"
                :disabled="!form.content"
            >
                送出
            </button>
        </div>
        <!-- END input -->

        <!-- please login -->
        <div v-else>
            留言請先
            <Link
                :href="route('login')"
                class="text-sm text-gray-700 dark:text-gray-500 underline"
            >
                登入
            </Link>
            喔
        </div>
        <!-- END please login -->
    </div>
</template>
