<script setup>
import { Link, router } from "@inertiajs/vue3";
import DifficultyDropdown from "@/Components/DifficultyDropdown.vue";

defineProps({
    canLogin: Boolean,
    canRegister: Boolean,
});

const logout = () => {
    router.post(route("logout"));
};
</script>

<template>
    <div
        class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center sm:pt-20"
    >
        <div
            class="bg-white top-0 left-0 w-full h-16 fixed flex items-center justify-between"
        >
            <div class="flex gap-4 top-0 left-0 px-2 py-4 sm:px-6">
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    <Link href="/">網頁影片教學網</Link>
                </h2>
                <Link :href="route('video.create')">上傳題目</Link>
                <DifficultyDropdown v-if="route().current() === 'home'" />
                <Link :href="route('students.list')">同學列表</Link>
            </div>
            <div v-if="canLogin" class="flex gap-4 top-0 right-0 px-6 py-4">
                <!-- <Link
                    v-if="$page.props.user"
                    :href="route('dashboard')"
                    class="text-sm text-gray-700 dark:text-gray-500 underline"
                    >Dashboard</Link
                > -->
                <!-- Authentication -->
                <form
                    v-if="$page.props.user"
                    method="POST"
                    @submit.prevent="logout"
                >
                    <button
                        class="text-gray-700 dark:text-gray-500"
                        type="submit"
                    >
                        登出
                    </button>
                </form>
                <template v-else>
                    <Link
                        :href="route('login')"
                        class="text-gray-700 dark:text-gray-500"
                        >登入</Link
                    >
                    <Link
                        v-if="canRegister"
                        :href="route('register')"
                        class="text-gray-700 dark:text-gray-500"
                        >註冊</Link
                    >
                </template>
            </div>
        </div>

        <main class="w-full min-h-screen dark:bg-gray-900">
            <slot name="content" />
        </main>
    </div>
</template>
