import { instance } from "@/APIs"

export const createComment = () => {
}

export const likeComment = () => {

}

export const dislikeComment = () => {

}
