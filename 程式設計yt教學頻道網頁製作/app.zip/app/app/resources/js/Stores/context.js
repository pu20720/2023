// stores/counter.js
import { defineStore } from 'pinia'

export const useContextStore = defineStore('context', {
  state: () => {
    return { difficulty: 0 }
  },
  // could also be defined as
  // state: () => ({ count: 0 })
  actions: {
    setDifficulty(difficulty) {
      this.difficulty = difficulty
    },
  },
})