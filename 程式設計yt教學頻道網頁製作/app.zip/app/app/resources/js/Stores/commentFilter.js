// stores/counter.js
import { defineStore } from 'pinia'

export const useCommentFilterStore = defineStore('commentFilter', {
  state: () => {
    return { time: 'desc', heart_number: null }
  },
  actions: {
    setTimeFilter(time) {
      this.time = time
    },
    setHeartNumberFilter(heart_number) {
      this.heart_number = heart_number
    },
  },
})