<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Route;
use App\Models\User;

class UserController extends Controller
{
    /**
     * Get user list.
     *
     * @return view
     */
    public function list()
    {
        return Inertia::render('Students', [
            'canLogin' => Route::has('login'),
            'canRegister' => Route::has('register'),
            'students' => User::all(),
        ]);
    }
}
