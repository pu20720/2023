<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Video;

class CommentController extends Controller
{
    public function store(Request $request, $id)
    {
        $validated = $request->validate([
            'content' => ['required', 'min:1', 'max:512'],
        ]);

        $result = Video::find($id)->comments()->create(
            $validated + ['user_id' => $request->user()->id]
        );

        $result->load('likes');

        return response()->json($result, 200);
    }
}
