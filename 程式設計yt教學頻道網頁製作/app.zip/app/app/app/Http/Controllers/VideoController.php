<?php

namespace App\Http\Controllers;

use App\Models\Video;
use Illuminate\Support\Facades\Route;

use Illuminate\Http\Request;
use Inertia\Inertia;

class VideoController extends Controller
{
    /**
     * Get video list.
     *
     * @return Inertia::render
     */
    public function list()
    {
        return Inertia::render('Welcome', [
            'canLogin' => Route::has('login'),
            'canRegister' => Route::has('register'),
            'videos' => Video::all(),
        ]);
    }

    /**
     * Get a video page.
     *
     * @param  int  $id
     * @return Inertia::render
     */
    public function detail(Request $request, $id)
    {
        $video = Video::with("comments", "comments.user", "creator")->find($id);

        $likes_state = [];

        foreach ($video->comments as $comment) {
            $likes = $comment->likes();
            $likes_state[$comment->id] = [
                'heart_number' => $likes->count(),
                'liked' => $request->user() ? $likes->where("user_id", $request->user()->id)->count() : 0,
            ];
        }

        return Inertia::render('Video', [
            'canLogin' => Route::has('login'),
            'canRegister' => Route::has('register'),
            'video' => $video,
            'likesState' => $likes_state,
        ]);
    }

    /**
     * Get a video form page.
     *
     * @return Inertia::render
     */
    public function video_form()
    {
        return Inertia::render('UploadVideo', [
            'canLogin' => Route::has('login'),
            'canRegister' => Route::has('register'),
        ]);
    }

    /**
     * Create a video.
     *
     * @return Inertia::render
     */
    public function store(Request $request)
    {
        $pattern = '/^https:\/\/www\.youtube\.com\/watch\?v=([a-zA-Z0-9-_]+).*?$/';
        $matches = array();

        $validated = $request->validate([
            'title' => ['required', 'min:1', 'max:64'],
            'video_url' => ['required', 'min:16', 'max:64', "regex:{$pattern}"],
            'difficulty' => ['required', 'gte:1', 'lte:5'],
            'programming_language' => ['required', 'min:1', 'max:32'],
        ]);

        preg_match($pattern, $validated['video_url'], $matches);
        $validated['video_url'] = "https://www.youtube.com/embed/{$matches[1]}";

        $result = Video::create($validated + [
            'creator_id' => $request->user()->id,
            'cover' => "https://i.ytimg.com/vi/{$matches[1]}/hqdefault.jpg"
        ]);

        return to_route('video', ['id' => $result->id]);
    }
}
