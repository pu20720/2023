<?php

namespace App\Http\Controllers;

use App\Models\Comment;
use App\Models\CommentLikes;
use Illuminate\Http\Request;

class CommentLikeController extends Controller
{

    public function store(Request $request, $id)
    {
        $result = Comment::find($id)->likes()->create(
            [
                'comment_id' => $id,
                'user_id' => $request->user()->id,
            ]
        );

        return response()->json($result, 200);
    }

    public function destroy(Request $request, $id)
    {
        $result = CommentLikes::where('comment_id', $id)->where('user_id', $request->user()->id)->delete();

        return response()->json($result, 200);
    }
}
