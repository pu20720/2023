<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    use HasFactory;

    protected $fillable = ["content", "video_id", "user_id"];


    /**
     * Get the user of the comment.
     */
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function heart_number()
    {
        return $this->hasMany(CommentLikes::class, 'comment_id')->count();
    }

    public function likes()
    {
        return $this->hasMany(CommentLikes::class, 'comment_id');
    }
}
