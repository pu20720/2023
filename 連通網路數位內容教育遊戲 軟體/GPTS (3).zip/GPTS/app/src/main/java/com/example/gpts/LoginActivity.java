package com.example.gpts;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    private EditText emailEditText;
    private EditText passwordEditText;
    private Button loginButton;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        mAuth = FirebaseAuth.getInstance();

        emailEditText = findViewById(R.id.email_edit_text); // 与你的布局文件中的实际 ID 匹配
        passwordEditText = findViewById(R.id.password_edit_text); // 与你的布局文件中的实际 ID 匹配
        loginButton = findViewById(R.id.login_button); // 与你的布局文件中的实际 ID 匹配

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = emailEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // 在此处执行登录逻辑
                signInWithEmailPassword(email, password);
            }
        });
    }

    private void signInWithEmailPassword(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // 登录成功
                            Toast.makeText(LoginActivity.this, "登入成功", Toast.LENGTH_SHORT).show();

                            // 获取已登录用户的 email
                            String userEmail = mAuth.getCurrentUser().getEmail();

                            // 使用 userEmail 作为用户的唯一标识符
                            String userId = userEmail;

                            // 在这里添加跳转到 BlankActivity 的代码
                            Intent intent = new Intent(LoginActivity.this, BlankActivity.class);
                            startActivity(intent);
                        } else {
                            // 登录失败
                            Toast.makeText(LoginActivity.this, "登入失敗", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}
