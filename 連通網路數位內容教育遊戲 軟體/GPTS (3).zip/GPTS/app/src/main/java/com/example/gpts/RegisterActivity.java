package com.example.gpts;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {

    // 在 onCreate 方法中设置布局
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_activity);

        Button registerButton = findViewById(R.id.register_button);
        // 添加点击事件监听器来处理注册
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 在这里执行用户注册逻辑
                registerUser();
            }
        });
    }

    // 注册用户的方法
    private void registerUser() {
        // 获取用户输入的电子邮件和密码
        EditText emailEditText = findViewById(R.id.email_edit_text);
        EditText passwordEditText = findViewById(R.id.password_edit_text);
        String email = emailEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // 使用 Firebase Authentication 进行用户注册
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // 注册成功
                            Toast.makeText(RegisterActivity.this, "注册成功", Toast.LENGTH_SHORT).show();
                            // 注册成功后导航到activity_blank页面
                            Intent intent = new Intent(RegisterActivity.this, BlankActivity.class);
                            startActivity(intent);
                            finish(); // 结束当前活动
                        } else {
                            // 注册失败
                            Toast.makeText(RegisterActivity.this, "注册失败：" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

}