package com.example.gpts;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.media.MediaPlayer;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class GameActivity extends AppCompatActivity {
    private TextView questionTextView;
    private RadioButton optionA, optionB, optionC, optionD;
    private Button submitButton;
    private Button backToHomeButton;  // 新增回到首頁按钮
    private Button chatWithGptButton; // 新增跟GPT聊聊按钮
    private TextView bossHealthTextView;
    private TextView timerTextView;
    private CountDownTimer countDownTimer;
    private int currentQuestionIndex = 0;
    private List<Question> questionList;
    private Toast correctToast;
    private Toast wrongToast;
    private int correctToastCount = 0;
    private int wrongToastCount = 0;
    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;
    private long remainingTime = 0;
    private Set<Integer> selectedQuestionIndices = new HashSet<>();
    private String userId;

    private MediaPlayer bgmPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        userId = "user-email";

        questionTextView = findViewById(R.id.question_text);
        optionA = findViewById(R.id.option1);
        optionB = findViewById(R.id.option2);
        optionC = findViewById(R.id.option3);
        optionD = findViewById(R.id.option4);
        submitButton = findViewById(R.id.submit_button);
        bossHealthTextView = findViewById(R.id.boss_health);
        timerTextView = findViewById(R.id.timer_text);

        // 初始化回到首頁按钮
        backToHomeButton = findViewById(R.id.back_to_home_button);
        backToHomeButton.setVisibility(View.GONE);  // 初始不可见
        // 初始化跟GPT聊聊按钮
        chatWithGptButton = findViewById(R.id.chat_with_gpt_button);
        chatWithGptButton.setVisibility(View.GONE); // 初始不可见

        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getWritableDatabase();

        bgmPlayer = MediaPlayer.create(this, R.raw.fightbgm);
        bgmPlayer.setLooping(true);
        bgmPlayer.start();

        countDownTimer = new CountDownTimer(600000, 1000) {
            public void onTick(long millisUntilFinished) {
                remainingTime = millisUntilFinished;
                long secondsElapsed = 600 - (millisUntilFinished / 1000);
                timerTextView.setText("你花了: " + secondsElapsed + " 秒");
            }

            public void onFinish() {
                remainingTime = 0;
                // 游戏结束时设置按钮可见
                backToHomeButton.setVisibility(View.VISIBLE);
                chatWithGptButton.setVisibility(View.VISIBLE);
            }
        };

        questionList = getRandomQuestions(10);

        correctToast = Toast.makeText(this, "答案正确！", Toast.LENGTH_SHORT);
        wrongToast = Toast.makeText(this, "答案不正确，请再试一次。", Toast.LENGTH_SHORT);

        showQuestion(currentQuestionIndex);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String playerAnswer = getSelectedAnswer();
                boolean isCorrect = validateAnswer(playerAnswer);

                if (isCorrect) {
                    correctToast.show();
                    correctToastCount++;
                    updateBossHealth();
                    submitButton.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            showQuestion(currentQuestionIndex + 1);
                        }
                    }, correctToast.getDuration());
                } else {
                    wrongToast.show();
                    wrongToastCount++;
                }
            }
        });

        backToHomeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(GameActivity.this, BlankActivity.class);
                startActivity(intent);
            }
        });

        chatWithGptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(GameActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void showQuestion(int index) {
        if (index == 0) {
            countDownTimer.start();
        }

        if (index < questionList.size()) {
            currentQuestionIndex = index;
            Question currentQuestion = questionList.get(index);
            questionTextView.setText(currentQuestion.getQuestion());
            optionA.setText(currentQuestion.getOptionA());
            optionB.setText(currentQuestion.getOptionB());
            optionC.setText(currentQuestion.getOptionC());
            optionD.setText(currentQuestion.getOptionD());

            optionA.setChecked(false);
            optionB.setChecked(false);
            optionC.setChecked(false);
            optionD.setChecked(false);
            submitButton.setVisibility(View.VISIBLE);

            if (index == 0) {
                bossHealthTextView.setText("❤️❤️❤️❤️❤️❤️❤️❤️❤️❤️");
            }
        } else {
            countDownTimer.cancel();
            optionA.setVisibility(View.INVISIBLE);
            optionB.setVisibility(View.INVISIBLE);
            optionC.setVisibility(View.INVISIBLE);
            optionD.setVisibility(View.INVISIBLE);
            questionTextView.setText("遊戲結束\n 分數:"+(correctToastCount*10+wrongToastCount*-20));
            submitButton.setVisibility(View.GONE);
            backToHomeButton.setVisibility(View.VISIBLE);
            chatWithGptButton.setVisibility(View.VISIBLE);
            ImageView bossDragonImageView = findViewById(R.id.my_image_view);
            bossDragonImageView.setVisibility(View.INVISIBLE);
        }
    }

    private String getSelectedAnswer() {
        if (optionA.isChecked()) {
            return "A";
        } else if (optionB.isChecked()) {
            return "B";
        } else if (optionC.isChecked()) {
            return "C";
        } else if (optionD.isChecked()) {
            return "D";
        }
        return "";
    }

    private boolean validateAnswer(String answer) {
        if (currentQuestionIndex < questionList.size()) {
            Question currentQuestion = questionList.get(currentQuestionIndex);
            return answer.equalsIgnoreCase(currentQuestion.getCorrectAnswer());
        }
        return false;
    }

    private void updateBossHealth() {
        String bossHealth = bossHealthTextView.getText().toString();
        if (bossHealth.length() >= 2) {
            bossHealth = bossHealth.substring(0, bossHealth.length() - 2);
            bossHealthTextView.setText(bossHealth);
            if (bossHealth.isEmpty()) {
                TextView bossNameTextView = findViewById(R.id.boss_name);
                bossNameTextView.setVisibility(View.GONE);
            }
        }
    }

    private List<Question> getRandomQuestions(int count) {
        List<Question> selectedQuestions = new ArrayList<>();
        List<Question> allQuestions = getQuestionsFromDatabase(count);
        Random random = new Random();

        while (selectedQuestions.size() < count) {
            int randomIndex;
            do {
                randomIndex = random.nextInt(allQuestions.size());
            } while (selectedQuestionIndices.contains(randomIndex));

            selectedQuestionIndices.add(randomIndex);
            Question randomQuestion = allQuestions.get(randomIndex);
            selectedQuestions.add(randomQuestion);
        }
        return selectedQuestions;
    }

    private List<Question> getQuestionsFromDatabase(int count) {
        List<Question> questions = new ArrayList<>();
        String[] columns = {
                DatabaseHelper.COLUMN_QUESTION,
                DatabaseHelper.COLUMN_OPTION_A,
                DatabaseHelper.COLUMN_OPTION_B,
                DatabaseHelper.COLUMN_OPTION_C,
                DatabaseHelper.COLUMN_OPTION_D,
                DatabaseHelper.COLUMN_CORRECT_ANSWER
        };
        Cursor cursor = db.query(DatabaseHelper.TABLE_NAME, columns, null, null, null, null, "RANDOM()", String.valueOf(count));
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String questionText = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_QUESTION));
                @SuppressLint("Range") String optionA = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_OPTION_A));
                @SuppressLint("Range") String optionB = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_OPTION_B));
                @SuppressLint("Range") String optionC = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_OPTION_C));
                @SuppressLint("Range") String optionD = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_OPTION_D));
                @SuppressLint("Range") String correctAnswer = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_CORRECT_ANSWER));
                Question question = new Question(questionText, optionA, optionB, optionC, optionD, correctAnswer);
                questions.add(question);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return questions;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (bgmPlayer != null) {
            bgmPlayer.stop();
            bgmPlayer.release();
        }
    }
}
