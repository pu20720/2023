package com.example.gpts;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;

public class BlankActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private Button loginButton;
    private Button logoutButton; // 新添加的登出按钮
    private MusicPlayer musicPlayer; // 添加音乐播放器

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blank);

        mAuth = FirebaseAuth.getInstance();
        loginButton = findViewById(R.id.login_button);
        logoutButton = findViewById(R.id.logout_button);
        musicPlayer = MusicPlayer.getInstance(this); // 初始化音乐播放器

        // 播放背景音乐
        musicPlayer.start();

        // 在 onCreate 中检查登录状态并相应地启用或禁用登录按钮
        updateLoginButtonState();

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 启动登录页面
                Intent intent = new Intent(BlankActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        Button goToMainActivityButton = findViewById(R.id.go_to_main_button);

        goToMainActivityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 启动MainActivity
                Intent intent = new Intent(BlankActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // 处理登出按钮的点击事件
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 在此执行登出逻辑
                mAuth.signOut();
                // 登出后再次检查登录状态并更新登录按钮状态
                updateLoginButtonState();
                // 可以根据需要添加其他登出后的操作
            }
        });

        Button startGameButton = findViewById(R.id.start_game_button);
        Button registerButton = findViewById(R.id.register_button);

        startGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 启动游戏
                Intent intent = new Intent(BlankActivity.this, GameActivity.class);
                intent.putExtra("game_started", true);
                startActivity(intent);
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 启动注册页面
                Intent intent = new Intent(BlankActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }

    // 更新登录按钮的状态
    private void updateLoginButtonState() {
        if (mAuth.getCurrentUser() != null) {
            // 用户已登录，禁用登录按钮
            loginButton.setEnabled(false);
        } else {
            // 用户未登录，启用登录按钮
            loginButton.setEnabled(true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        musicPlayer.start(); // 当返回到该 Activity 时，继续播放背景音乐
    }

    @Override
    protected void onPause() {
        super.onPause();
        musicPlayer.pause(); // 当离开该 Activity 时，暂停背景音乐
    }
}

