package com.example.gpts;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "QuizGame.db";
    private static final int DATABASE_VERSION = 21;

    public static final String TABLE_NAME = "questions";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_QUESTION = "question";
    public static final String COLUMN_OPTION_A = "optionA";
    public static final String COLUMN_OPTION_B = "optionB";
    public static final String COLUMN_OPTION_C = "optionC";
    public static final String COLUMN_OPTION_D = "optionD";
    public static final String COLUMN_CORRECT_ANSWER = "correctAnswer";

    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_QUESTION + " TEXT, " +
                    COLUMN_OPTION_A + " TEXT, " +
                    COLUMN_OPTION_B + " TEXT, " +
                    COLUMN_OPTION_C + " TEXT, " +
                    COLUMN_OPTION_D + " TEXT, " +
                    COLUMN_CORRECT_ANSWER + " TEXT" +
                    ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);

        // 插入问题和答案数据
        insertSampleQuestions(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // 插入示例问题和答案数据
    private void insertSampleQuestions(SQLiteDatabase db) {
        String[][] sampleQuestions = {
                {"哪个大陆是世界上最大的陆地？", "亚洲", "非洲", "北美洲", "南美洲", "A"},
                {"太阳系中最矮小的行星是？", "水星", "金星", "地球", "火星", "A"},
                {"哪个国家被称为“千湖之国”？", "芬兰", "加拿大", "瑞士", "日本", "A"},
                {"世界上最高的山脉是？", "赞岐山脉", "喜马拉雅山脉", "阿尔卑斯山脉", "乌拉尔山脉", "B"},
                {"什么元素的符号是'Fe'？", "氧气", "铁", "锰", "铝", "B"},
                {"哪种大猫被称为“森林之王”？", "狮子", "老虎", "美洲豹", "豹", "B"},
                {"莎士比亚的代表作品之一是什么？", "《哈姆雷特》", "《罗密欧与朱丽叶》", "《奥赛罗》", "《李尔王》", "A"},
                {"第一个成功登上月球的人是？", "尼尔·阿姆斯特朗", "约翰·格伦", "尤里·加加林", "巴兹·奥尔德林", "A"},
                {"哪个星座代表着两只孪生兄弟？", "狮子座", "双子座", "巨蟹座", "天秤座", "B"},
                {"人体最大的器官是什么？", "心脏", "大脑", "皮肤", "肝脏", "C"},
                {"哪种动物是世界上最大的陆地哺乳动物？", "狮子", "大象", "长颈鹿", "斑马", "B"},
                {"太阳系中最靠近太阳的行星是？", "金星", "地球", "火星", "水星", "D"},
                {"世界上最长的河流是什么？", "尼罗河", "亚马逊河", "长江", "密西西比河", "A"},
                {"哪个国家以其独特的冰川景观而闻名？", "加拿大", "挪威", "冰岛", "瑞士", "C"},
                {"哪个行星被称为“晨星”或“傍晚星”？", "金星", "火星", "水星", "木星", "A"},
                {"在周期表中，氢的原子序数是多少？", "1", "2", "3", "4", "A"},
                {"哪个国家以其恶魔面具和狂欢节而著名？", "巴西", "墨西哥", "法国", "意大利", "A"},
                {"哪个大洋位于美洲的东侧？", "太平洋", "大西洋", "印度洋", "北冰洋", "B"},
                {"什么是地球上最高的山峰？", "喜马拉雅山", "安第斯山", "洛基山脉", "阿尔卑斯山", "A"},
                {"哪种动物被认为是世界上最快的陆地动物？", "豹", "猎豹", "狮子", "老虎", "B"},
                {"莫扎特是哪个国家的著名作曲家？", "德国", "奥地利", "法国", "意大利", "B"},
                {"哪个行星被称为“红色行星”？", "水星", "金星", "地球", "火星", "D"},
                {"哪个大陆是世界上最小的陆地？", "南极洲", "澳大利亚", "南美洲", "非洲", "A"},
                {"哪个元素的符号是'Hg'？", "铁", "铜", "锰", "汞", "D"},
                {"什么是地球上最深的海洋？", "太平洋", "大西洋", "印度洋", "马里亚纳海沟", "A"},
                {"哪个国家以其古老的金字塔而著名？", "希腊", "意大利", "埃及", "中国", "C"},
                {"哪种动物被认为是世界上最聪明的非人类动物？", "大猩猩", "海豚", "狼", "乌鸦", "D"},
                {"哪个行星是太阳系中最大的行星？", "金星", "火星", "木星", "土星", "C"},
                {"世界上最大的大洋是什么？", "太平洋", "大西洋", "印度洋", "北冰洋", "A"},
                {"哪个国家以其悬崖村庄而著名？", "挪威", "瑞士", "希腊", "秘鲁", "B"},
                {"哪种动物被认为是世界上最古老的陆地生物？", "鳄鱼", "象龟", "鳄鱼", "蜥蜴", "B"},
                {"哪个国家以其美丽的珊瑚礁而著名？", "巴哈马", "马尔代夫", "斐济", "大堡礁", "D"},
                {"什么是地球上最大的大陆？", "南美洲", "非洲", "亚洲", "欧洲", "C"},
                {"哪种动物被认为是世界上最快的鸟类？", "鸵鸟", "秃鹰", "隼", "信天翁", "A"},
                {"哪个城市以其斜塔而著名？", "巴黎", "纽约", "伦敦", "比萨", "D"},
                {"哪个行星被称为“晨星”或“傍晚星”？", "金星", "火星", "水星", "木星", "A"},
                {"在周期表中，氧的原子序数是多少？", "6", "7", "8", "9", "C"},
                {"哪个国家以其美丽的自然景观和峡谷而著名？", "挪威", "加拿大", "智利", "澳大利亚", "B"},
                {"哪个大洋位于美洲的西侧？", "太平洋", "大西洋", "印度洋", "北冰洋", "A"},
                {"什么是地球上最高的瀑布？", "尼亚加拉瀑布", "伊瓜苏瀑布", "安赫尔瀑布", "亚马逊瀑布", "B"},
                {"哪种动物被认为是世界上最大的鸟类？", "鸽子", "鸭子", "孔雀", "鸵鸟", "D"},
                {"哪个国家以其独特的野生动物而著名？", "肯尼亚", "巴拿马", "荷兰", "韩国", "A"},
                {"哪个元素的符号是'Na'？", "镁", "钠", "铝", "铁", "B"},
                {"什么是地球上最大的沙漠？", "撒哈拉沙漠", "澳大利亚大沙漠", "基伍纳大沙漠", "蒙古大沙漠", "A"},
                {"哪个国家以其美丽的雪山而著名？", "瑞士", "尼泊尔", "新西兰", "俄罗斯", "B"},
                {"哪种动物被认为是世界上最大的猫科动物？", "狮子", "老虎", "豹", "美洲豹", "B"},
                {"哪个行星被称为“晨星”或“傍晚星”？", "金星", "火星", "水星", "木星", "A"},
                {"在周期表中，铁的原子序数是多少？", "24", "25", "26", "27", "C"},
                {"哪个国家以其古老的文明和金字塔而著名？", "中国", "印度", "埃及", "希腊", "C"},
                {"哪种动物被认为是世界上最大的爬行动物？", "鳄鱼", "蜥蜴", "蟒蛇", "巨蜥", "A"},
                {"哪个国家以其丰富的大熊猫种群而著名？", "印度", "中国", "巴西", "澳大利亚", "B"},
                {"哪个元素的符号是'K'？", "铝", "钠", "钾", "锌", "C"},
        };

        for (String[] questionData : sampleQuestions) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_QUESTION, questionData[0]);
            values.put(COLUMN_OPTION_A, questionData[1]);
            values.put(COLUMN_OPTION_B, questionData[2]);
            values.put(COLUMN_OPTION_C, questionData[3]);
            values.put(COLUMN_OPTION_D, questionData[4]);
            values.put(COLUMN_CORRECT_ANSWER, questionData[5]);

            db.insert(TABLE_NAME, null, values);
        }
    }
}
