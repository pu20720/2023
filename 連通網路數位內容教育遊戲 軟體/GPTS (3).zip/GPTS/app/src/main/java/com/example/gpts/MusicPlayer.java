package com.example.gpts;

import android.content.Context;
import android.media.MediaPlayer;

public class MusicPlayer {
    private static MusicPlayer instance;
    private MediaPlayer mediaPlayer;
    private boolean isPaused = false;

    private MusicPlayer(Context context) {
        // 初始化 MediaPlayer
        mediaPlayer = MediaPlayer.create(context, R.raw.bgm);
        mediaPlayer.setLooping(true); // 设置音乐循环播放
    }

    public static MusicPlayer getInstance(Context context) {
        if (instance == null) {
            instance = new MusicPlayer(context);
        }
        return instance;
    }

    public void start() {
        if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
            if (isPaused) {
                mediaPlayer.start(); // 从暂停状态继续播放
                isPaused = false;
            } else {
                mediaPlayer.start(); // 启动音乐播放
            }
        }
    }

    public void pause() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause(); // 暂停音乐播放
            isPaused = true;
        }
    }

    public void stop() {
        if (mediaPlayer != null) {
            mediaPlayer.stop(); // 停止音乐播放
        }
    }

    public void release() {
        if (mediaPlayer != null) {
            mediaPlayer.release(); // 释放 MediaPlayer 资源
            mediaPlayer = null;
        }
    }
}
