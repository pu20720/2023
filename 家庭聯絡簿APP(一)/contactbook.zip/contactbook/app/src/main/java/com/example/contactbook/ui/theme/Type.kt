package com.example.contactbook.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// 一組用於開始的 Material 風格設定
val Typography = Typography(
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Default,    // 字型家族使用預設字型
        fontWeight = FontWeight.Normal, // 字重正常
        fontSize = 16.sp,   // 字體大小 16sp
        lineHeight = 24.sp, // 行高 24sp
        letterSpacing = 0.5.sp  // 字距 0.5sp
    )
    /* 其他預設文字風格可覆蓋
    titleLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 22.sp,
        lineHeight = 28.sp,
        letterSpacing = 0.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp
    )
    */
)