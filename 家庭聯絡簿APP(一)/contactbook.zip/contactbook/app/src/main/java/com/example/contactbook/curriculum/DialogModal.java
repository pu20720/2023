package com.example.contactbook.curriculum;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.contactbook.curriculum.DBHelper;
import com.example.contactbook.curriculum.curriculum;
import com.example.contactbook.R;

public class DialogModal extends Activity {
    Button close_activity;
    Button save_activity;
    Spinner selected_time;
    Spinner selected_day;
    EditText subject;
    EditText teacher;
    //命名資料庫名
    public final String DB_NAME = "classes_db.db";
    public final String TABLE_NAME = "classes_db";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);// 隱藏標題列
        setContentView(R.layout.activity_set);

        // 當點擊對話框之外的區域時完成此 Activity
        setFinishOnTouchOutside(true);

        // 關閉按鈕操作
        close_activity = (Button) findViewById(R.id.close_activity);
        close_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogModal.this.finish();
            }
        });

        // 保存按鈕操作
        save_activity = findViewById(R.id.save_activity);
        save_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();

                selected_day = findViewById(R.id.selected_day);
                String day = selected_day.getSelectedItem().toString();

                if (day.equals("--請選擇--")) {
                    save_activity.setError("");
                    return;
                }
                selected_time = findViewById(R.id.selected_time);
                String time = selected_time.getSelectedItem().toString();
                if (time.equals("--請選擇--")) {
                    save_activity.setError("");
                    return;
                }

                subject = findViewById(R.id.subject);
                String text = subject.getText().toString();
                if ("".equals(text)) {
                    save_activity.setError("");
                    return;
                }

                teacher = findViewById(R.id.teacher);
                String teacher1 = teacher.getText().toString();
                if ("".equals(teacher1)) {
                    save_activity.setError("");
                    return;
                }

                // 創建一個資料庫對象
                DBHelper dbHelper = new DBHelper(DialogModal.this, DB_NAME, null, 1);

                // 把數據存儲在 ContentValues 中
                ContentValues contentValues = new ContentValues();
                // combineId() 方法的目的是通過星期幾和第幾堂課來計算對應的課程 ID
                contentValues.put("c_id", combineId(day, time));
                contentValues.put("c_name", text);
                contentValues.put("c_time", time);
                contentValues.put("c_day", day);
                contentValues.put("c_teacher", teacher1);

                // 更新資料庫記錄
                update(dbHelper, contentValues);

                // 清空堆疊中的所有 Activity
                intent.setFlags(intent.FLAG_ACTIVITY_CLEAR_TASK);

                // 啟動 MainActivity
                intent.setClass(DialogModal.this, curriculum.class);
                startActivity(intent);
            }
        });
    }

    public String combineId(String day, String time) {

        // 星期幾轉換成 int 型
        int day1 = utils.getDay(day);

        // 如果是 1-2 堂課，只取 1
        int time1 = Integer.parseInt(time.substring(0, 1));

        return String.valueOf((day1 - 1) * 5 + ((time1 - 1) / 2 + 1));
    }

    public void update(DBHelper dbHelper, ContentValues contentValues) {

        String[] a = {contentValues.get("c_id").toString()};

        // 透過 DBHelper 類別取得一個讀寫的 SQLiteDatabase 對象
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.update(TABLE_NAME, contentValues, "c_id=?", a);

        // 釋放連接
        db.close();
    }

}

