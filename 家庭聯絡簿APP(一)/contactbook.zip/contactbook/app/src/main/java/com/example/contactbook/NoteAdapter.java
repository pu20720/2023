package com.example.contactbook;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;

import java.util.ArrayList;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteHolder> {

    MainActivity main;
    ArrayList<Note> nList;

    ActivityResultLauncher<Intent> editLauncher; // 用於處理編輯筆記的 ActivityResultLauncher
    Gson gson = new Gson();

    public NoteAdapter(Context c_, ArrayList<Note> n_) {
        main = (MainActivity) c_;
        nList = n_;
    }

    @NonNull
    @Override
    public NoteHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // 建立並回傳筆記項目的 ViewHolder
        View view = LayoutInflater.from(main).inflate(R.layout.note_item, parent, false);
        return new NoteHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteHolder holder, int position) {
        // 設定筆記項目的標題
        holder.tv_title.setText(nList.get(position).title);
    }

    @Override
    public int getItemCount() {
        return nList.size();
    }

    public class NoteHolder extends RecyclerView.ViewHolder {
        TextView tv_title;

        public NoteHolder(@NonNull View itemView) {
            super(itemView);
            tv_title = itemView.findViewById(R.id.tv_title);

            // 點擊筆記項目時觸發編輯筆記的操作
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    Note p = nList.get(position);
                    String json = gson.toJson(p);
                    Intent it = new Intent(main, Act_Note.class);
                    it.putExtra("json", json);
                    it.putExtra("action", Action.EDIT);
                    main.noteEditLauncher.launch(it);
                }
            });

            // 長按筆記項目時觸發刪除筆記的操作
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(main);
                    builder.setTitle("刪除訊息");
                    int position = getAdapterPosition();
                    builder.setMessage("確定要刪除標題為 " + nList.get(position).title + " 的訊息嗎？");
                    builder.setPositiveButton("確定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            int position = getAdapterPosition();
                            Note n = nList.get(position);
                            main.helper.deleteNote(n);
                            nList = main.helper.getAllNotes();
                            NoteAdapter.this.notifyDataSetChanged();
                            dialogInterface.dismiss();
                        }
                    });
                    builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    });
                    builder.show();
                    return true;
                }
            });

        }
    }
}
