package com.example.contactbook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.gson.Gson;

public class Act_Note extends AppCompatActivity {

    EditText et_title, et_data;  // 文章標題和內容的輸入框
    Button bt_OK, bt_Cancel;     // 確定和取消按鈕
    Gson gson = new Gson();      // 使用 Gson 庫來處理 JSON 數據
    int id = -1;                // 文章的唯一 ID
    String action = "";         // 用於指示當前操作（新建或編輯）

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);

        et_title = findViewById(R.id.et_title);   // 連接文章標題的輸入框
        et_data = findViewById(R.id.et_data);     // 連接文章內容的輸入框
        bt_OK = findViewById(R.id.bt_OK);         // 連接確定按鈕
        bt_Cancel = findViewById(R.id.bt_Cancel); // 連接取消按鈕


        Intent it = getIntent();                // 從意圖中獲取傳遞的數據
        String action = it.getStringExtra("action");  // 獲取操作類型（新建或編輯）
        if (action.equals(Action.EDIT)) {    // 如果操作是編輯
            String json = it.getStringExtra("json");  // 從意圖中獲取 JSON 數據
            Note p = gson.fromJson(json, Note.class);  // 使用 Gson 解析 JSON 數據為 Note 對象
            id = p.id;               // 獲取記事的唯一 ID
            et_title.setText(p.title);  // 將記事標題設定為編輯前的值
            et_data.setText(p.data);    // 將記事內容設定為編輯前的值
        }

        bt_Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent();
                it.putExtra("action", Action.CANCEL);
                setResult(RESULT_CANCELED, it);
                finish();
            }
        });

        bt_OK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = et_title.getText().toString();  // 獲取文章標題的文本
                String data = et_data.getText().toString();    // 獲取文章內容的文本
                if (action.equals(Action.NEW)) {
                    id = -1;  // 如果是新建文章，將 ID 設定為 -1
                }
                Note p = new Note(id, title, data);  // 創建一個 Note 對象
                String json = gson.toJson(p);        // 使用 Gson 將 Note 對象轉換為 JSON 字符串
                Intent it = new Intent();
                it.putExtra("json", json);   // 將 JSON 數據傳遞回主活動
                setResult(RESULT_OK, it);     // 設定操作結果為成功
                finish();                    // 結束當前活動
            }
        });
    }
}