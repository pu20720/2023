package com.example.contactbook;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;

import com.example.contactbook.PaintView;

import java.util.HashSet;
import java.util.Timer;
import java.util.TimerTask;


public class sign1 extends AppCompatActivity {


    Button bt_start, bt_stop, bt_save, bt_clear;
    FrameLayout frameLayout;
    HashSet<Integer> colorSet = new HashSet<>();
    CheckBox cb1, cb2, cb3, cb4, cb5;

    Timer timer;
    PaintView paintView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign);

        cb1 = findViewById(R.id.cb1);
        cb2 = findViewById(R.id.cb2);
        cb3 = findViewById(R.id.cb3);
        cb4 = findViewById(R.id.cb4);
        cb5 = findViewById(R.id.cb5);
        frameLayout = findViewById(R.id.frame);
        int frameWidth = frameLayout.getWidth();
        int frameHeight = frameLayout.getHeight();
        Log.d("FrameLayoutSize", "FrameLayout width: " + frameWidth + ", height: " + frameHeight);

        bt_save = findViewById(R.id.bt_save);
        bt_clear = findViewById(R.id.bt_clear);

        paintView = new PaintView(this);
        frameLayout.addView(paintView);


        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                paintView.save("saved_painting.dat");
            }
        });


        paintView.load("saved_painting.dat");


        bt_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                paintView.clear();
            }
        });

        cb1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                int color = ContextCompat.getColor(sign1.this, R.color.colorPrimary);
                if (isChecked) {
                    paintView.setSelectedColor(color);
                }
            }
        });

        cb2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                int color = ContextCompat.getColor(sign1.this, R.color.purple_200);
                if (isChecked) {
                    paintView.setSelectedColor(color);
                }
            }
        });

        cb3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                int color = ContextCompat.getColor(sign1.this, R.color.black);
                if (isChecked) {
                    paintView.setSelectedColor(color);
                }
            }
        });

        cb4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                int color = ContextCompat.getColor(sign1.this, R.color.white);
                if (isChecked) {
                    paintView.setSelectedColor(color);
                }
            }
        });

        cb5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                int color = ContextCompat.getColor(sign1.this, R.color.primary_color);
                if (isChecked) {
                    paintView.setSelectedColor(color);
                }
            }
        });
    }

    int[] getCheckedColor() {
        int[] checkedColor = new int[colorSet.size()];
        int i = 0;
        for (int color : colorSet) {
            checkedColor[i++] = color;
        }
        return checkedColor;
    }
}