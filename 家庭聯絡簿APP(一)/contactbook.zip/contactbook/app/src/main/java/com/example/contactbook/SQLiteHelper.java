package com.example.contactbook;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class SQLiteHelper extends SQLiteOpenHelper {

    private static final String TABLE_Friends = "friends"; // 建立朋友資料表
    private static final String TABLE_Notes = "notes"; // 建立記事本資料表
    private static final String ID = "id"; // 資料表的 ID 欄位
    private static final String NAME = "name"; // 朋友的名字
    private static final String TEL = "tel"; // 朋友的電話號碼
    private static final String ADDR = "addr"; // 朋友的地址
    private static final String TITLE = "title"; // 記事本標題
    private static final String DATA = "data"; // 記事本內容

    public SQLiteHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        // 建立朋友資料表
        String CREATE_Friend_TABLE = "CREATE TABLE if not exists "
                + TABLE_Friends + "("
                + ID + " INTEGER PRIMARY KEY,"
                + NAME + " TEXT,"
                + TEL + " TEXT, "
                + ADDR + " TEXT" + ")";
        db.execSQL(CREATE_Friend_TABLE);

        // 建立記事本資料表
        String CREATE_NOTE_TABLE = "CREATE TABLE if not exists "
                + TABLE_Notes + "("
                + ID + " INTEGER PRIMARY KEY,"
                + TITLE + " TEXT,"
                + DATA + " TEXT" + ")";
        db.execSQL(CREATE_NOTE_TABLE);

    }

    public void dropAll() {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        // 刪除所有資料表
        String drop1 = "DROP TABLE IF EXISTS " + TABLE_Friends;
        sqLiteDatabase.execSQL(drop1);
        String drop2 = "DROP TABLE IF EXISTS " + TABLE_Notes;
        sqLiteDatabase.execSQL(drop2);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        // 升級資料庫，刪除舊的資料表
        String drop = "DROP TABLE IF EXISTS " + TABLE_Friends;
        db.execSQL(drop);
        String drop2 = "DROP TABLE IF EXISTS " + TABLE_Notes;
        db.execSQL(drop2);
    }

    void addFriend(String name, String tel, String addr) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(NAME, name); // 設定朋友名字
        values.put(TEL, tel); // 設定朋友電話號碼
        values.put(ADDR, addr); // 設定朋友地址

        // 插入新資料
        db.insert(TABLE_Friends, null, values);
        //第二個參數是包含 nullColumnHack 的字串
        db.close(); // 關閉資料庫連接
    }

    // 取得單一聯絡人的程式碼
    Friend getFriend(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_Friends,
                new String[]{ID, NAME, TEL, ADDR},
                ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        Friend friend = new Friend(Integer.parseInt(cursor.getString(0)),
                cursor.getString(1), cursor.getString(2), cursor.getString(3));
        // return friend
        return friend;
    }

    void addNote(String title, String data) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(TITLE, title); // 設定記事本標題
        values.put(DATA, data); // 設定記事本內容

        //  插入新資料
        db.insert(TABLE_Notes, null, values);
        //第二個參數是包含 nullColumnHack 的字串
        db.close(); // 關閉資料庫連接
    }

    // 取得單一聯絡人的程式碼
    Note getNote(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_Notes,
                new String[]{ID, TITLE, DATA},
                ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        Note note = new Note(Integer.parseInt(cursor.getString(0)),
                cursor.getString(1), cursor.getString(2));
        // return Note
        return note;
    }

    //程式碼讓所有人都在清單檢視中
    public ArrayList<Friend> getAllFriends() {
        ArrayList<Friend> peopleList = new ArrayList<Friend>();
        // 全選查詢
        String selectQuery = "SELECT  * FROM " + TABLE_Friends;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Friend p = new Friend(
                        Integer.parseInt(cursor.getString(0)),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3)
                );
                peopleList.add(p);
            } while (cursor.moveToNext());
        }
        return peopleList;
    }

    public ArrayList<Note> getAllNotes() {
        ArrayList<Note> noteList = new ArrayList<Note>();
        // 全選查詢
        String selectQuery = "SELECT  * FROM " + TABLE_Notes;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Note n = new Note(
                        Integer.parseInt(cursor.getString(0)),
                        cursor.getString(1),
                        cursor.getString(2)
                );
                noteList.add(n);
            } while (cursor.moveToNext());
        }
        return noteList;
    }

    public int updateFriend(Friend friend) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ID, friend.id);
        values.put(NAME, friend.name);
        values.put(TEL, friend.tel);
        values.put(ADDR, friend.addr);

        // 更新行
        return db.update(TABLE_Friends, values, ID + " = ?",
                new String[]{String.valueOf(friend.id)});
    }

    public int updateNote(Note note) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ID, note.id);
        values.put(TITLE, note.title);
        values.put(DATA, note.data);

        // 更新行
        return db.update(TABLE_Notes, values, ID + " = ?",
                new String[]{String.valueOf(note.id)});
    }

    // 刪除好友
    public void deleteFriend(Friend friend) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_Friends, ID + " = ?",
                new String[]{String.valueOf(friend.id)});
        db.close();
    }

    public void deleteNote(Note note) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_Notes, ID + " = ?",
                new String[]{String.valueOf(note.id)});
        db.close();
    }

    // 統計人數
    public int getFriendsCount() {
        String countQuery = "SELECT  * FROM " + TABLE_Friends;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        cursor.close();

        // return count
        return cursor.getCount();
    }

    public int getNotesCount() {
        String countQuery = "SELECT  * FROM " + TABLE_Notes;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        cursor.close();

        // return count
        return cursor.getCount();
    }

}
