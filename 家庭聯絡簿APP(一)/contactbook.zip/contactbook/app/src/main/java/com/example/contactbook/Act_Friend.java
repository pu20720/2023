package com.example.contactbook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.gson.Gson;

public class Act_Friend extends AppCompatActivity {

    EditText et_name, et_tel, et_addr;
    Button bt_OK, bt_Cancel;
    Gson gson = new Gson();
    int id = -1;
    String action = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friend);

        // 初始化畫面元素
        et_name = findViewById(R.id.et_name);
        et_tel = findViewById(R.id.et_tel);
        et_addr = findViewById(R.id.et_addr);
        bt_OK = findViewById(R.id.bt_OK);
        bt_Cancel = findViewById(R.id.bt_Cancel);

        // 從 Intent 中取得操作類型（新增或編輯）
        Intent it = getIntent();
        String action = it.getStringExtra("action");
        // 如果是編輯操作，則載入朋友的資料
        if (action.equals(Action.EDIT)) {
            String json = it.getStringExtra("json");
            Friend p = gson.fromJson(json, Friend.class);
            id = p.id;
            et_name.setText(p.name);
            et_tel.setText(p.tel);
            et_addr.setText(p.addr);
        }

        // 處理取消按鈕的點擊事件
        bt_Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent();
                it.putExtra("action", Action.CANCEL);
                setResult(RESULT_CANCELED, it);
                finish();
            }
        });

        // 處理確定按鈕的點擊事件
        bt_OK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = et_name.getText().toString();
                String tel = et_tel.getText().toString();
                String addr = et_addr.getText().toString();
                if (action.equals(Action.NEW)) {
                    id = -1;
                }
                Friend p = new Friend(id, name, tel, addr);
                String json = gson.toJson(p);
                Intent it = new Intent();
                it.putExtra("json", json);
                setResult(RESULT_OK, it);
                finish();
            }
        });
    }
}