package com.example.contactbook.ui.login;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import android.util.Patterns;

import com.example.contactbook.data.LoginRepository;
import com.example.contactbook.data.Result;
import com.example.contactbook.data.model.LoggedInUser;
import com.example.contactbook.R;

public class LoginViewModel extends ViewModel {

    private MutableLiveData<LoginFormState> loginFormState = new MutableLiveData<>(); // 用於存儲登入表單的狀態
    private MutableLiveData<LoginResult> loginResult = new MutableLiveData<>(); // 用於存儲登入結果
    private LoginRepository loginRepository;

    LoginViewModel(LoginRepository loginRepository) {
        this.loginRepository = loginRepository;
    }

    LiveData<LoginFormState> getLoginFormState() {
        return loginFormState;
    }

    LiveData<LoginResult> getLoginResult() {
        return loginResult;
    }

    public void login(String username, String password) {
        // 登入操作，可能在單獨的異步作業中執行
        Result<LoggedInUser> result = loginRepository.login(username, password);

        if (result instanceof Result.Success) {
            LoggedInUser data = ((Result.Success<LoggedInUser>) result).getData();
            loginResult.setValue(new LoginResult(new LoggedInUserView(data.getDisplayName()))); // 登入成功，傳遞用戶詳細信息
        } else {
            loginResult.setValue(new LoginResult(R.string.login_failed)); // 登入失敗，設置錯誤消息
        }
    }

    public void loginDataChanged(String username, String password) {
        if (!isUserNameValid(username)) {
            loginFormState.setValue(new LoginFormState(R.string.invalid_username, null)); // 用戶名無效，設置相應的錯誤消息
        } else if (!isPasswordValid(password)) {
            loginFormState.setValue(new LoginFormState(null, R.string.invalid_password)); // 密碼無效，設置相應的錯誤消息
        } else {
            loginFormState.setValue(new LoginFormState(true)); // 登入表單數據有效
        }
    }

    // 用於驗證用戶名的占位符方法
    private boolean isUserNameValid(String username) {
        if (username == null) {
            return false;
        }
        if (username.contains("@")) {
            return Patterns.EMAIL_ADDRESS.matcher(username).matches(); // 使用正則表達式驗證電子郵件格式
        } else {
            return !username.trim().isEmpty(); // 檢查用戶名是否為非空字符串
        }
    }

    // 用於驗證密碼的占位符方法
    private boolean isPasswordValid(String password) {
        return password != null && password.trim().length() > 5; // 檢查密碼是否長度大於5個字符
    }
}
