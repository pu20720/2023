package com.example.contactbook;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;

import java.util.ArrayList;

class FriendAdapter extends RecyclerView.Adapter<FriendAdapter.FriendHolder> {
    MainActivity main;
    ArrayList<Friend> pList;

    Gson gson = new Gson();
    ActivityResultLauncher<Intent> editLauncher;

    public FriendAdapter(Context c_, ArrayList<Friend> p_) {
        main = (MainActivity) c_;
        pList = p_;
    }

    @NonNull
    @Override
    public FriendHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(main).inflate(R.layout.friend_item, parent, false);
        return new FriendHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FriendHolder holder, int position) {
        holder.tv_name.setText(pList.get(position).name);
        holder.tv_tel.setText(pList.get(position).tel);
        holder.tv_addr.setText(pList.get(position).addr);
    }

    @Override
    public int getItemCount() {
        return pList.size();
    }

    public class FriendHolder extends RecyclerView.ViewHolder {
        TextView tv_name, tv_tel, tv_addr;

        public FriendHolder(@NonNull View itemView) {
            super(itemView);
            tv_name = itemView.findViewById(R.id.tv_name);
            tv_tel = itemView.findViewById(R.id.tv_tel);
            tv_addr = itemView.findViewById(R.id.tv_addr);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    Friend p = pList.get(position);
                    String json = gson.toJson(p);
                    Intent it = new Intent(main, Act_Friend.class);
                    it.putExtra("json", json);
                    it.putExtra("action", Action.EDIT);
                    main.friendEditLauncher.launch(it);
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(main);
                    builder.setTitle("刪除訊息");
                    int position = getAdapterPosition();
                    builder.setMessage("確定要刪除 " + pList.get(position).name + " 的訊息嗎？");
                    builder.setPositiveButton("確定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            int position = getAdapterPosition();
                            Friend f = pList.get(position);
                            main.helper.deleteFriend(f);
                            pList = main.helper.getAllFriends();
                            FriendAdapter.this.notifyDataSetChanged();
                            dialogInterface.dismiss();
                        }
                    });
                    builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    });
                    builder.show();
                    return true;
                }
            });
        }
    }
}

