package com.example.contactbook.ui.theme

import androidx.compose.ui.graphics.Color

// 深紫色，80% 不透明度
val Purple80 = Color(0xFFD0BCFF)

// 深紫色灰調，80% 不透明度
val PurpleGrey80 = Color(0xFFCCC2DC)

// 深粉紅色，80% 不透明度
val Pink80 = Color(0xFFEFB8C8)

// 深紫色，40% 不透明度
val Purple40 = Color(0xFF6650a4)

// 深紫色灰調，40% 不透明度
val PurpleGrey40 = Color(0xFF625b71)

// 深粉紅色，40% 不透明度
val Pink40 = Color(0xFF7D5260)