package com.example.contactbook.curriculum;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.widget.TextView;

import com.example.contactbook.R;

public class Detail extends Activity {

    TextView time;      // 用於顯示時間的 TextView
    TextView clsNum;    // 用於顯示課程編號的 TextView
    TextView sub;       // 用於顯示課程名稱的 TextView
    TextView teacher;   // 用於顯示教師名稱的 TextView

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);// 隱藏標題列
        setContentView(R.layout.activity_press);

        // 從上一個 Activity 取得傳遞的資料
        Intent intent = getIntent();

        // 連接到介面中的 TextView 元件
        sub = findViewById(R.id.sub);
        sub.setText(intent.getStringExtra("name")); // 設定課程名稱

        time = findViewById(R.id.time);
        time.setText(intent.getStringExtra("day")); // 設定時間

        clsNum = findViewById(R.id.clsNum);
        clsNum.setText(intent.getStringExtra("time")); // 設定課程時間

        teacher = findViewById(R.id.teacher);
        teacher.setText(intent.getStringExtra("teacher")); // 設定教師名稱


        setFinishOnTouchOutside(true); // 當觸碰 Activity 外部區域時結束該 Activity


    }

}
