package com.example.contactbook.curriculum;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {

    public SQLiteDatabase getWritableDatabase() {
        return super.getWritableDatabase();
    }

    public DBHelper(@Nullable Context context,
                    @Nullable String name,
                    @Nullable SQLiteDatabase.CursorFactory factory,
                    int version) {

        super(context, name, factory, version);

    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // 創建名為 "classes_db" 的資料表
        sqLiteDatabase.execSQL("create table classes_db" +
                "(c_id Integer not null primary key autoincrement," +
                " c_name varchar(50) not null," +
                " c_time varchar(50) not null," +
                " c_day varchar(50) not null," +
                " c_teacher varchar(50) not null)");

        // 創建一個 ContentValues 物件來設定參數
        ContentValues contentValues = new ContentValues();

        // 設定初始資料的預設值
        // 課程名稱
        contentValues.put("c_name", "0");
        // 第幾節課
        contentValues.put("c_time", "0");
        // 星期幾
        contentValues.put("c_day", "0");
        // 任課教師
        contentValues.put("c_teacher", "0");

        // 插入 1 到 36 的 ID 對應的課程資料，以便之後新增課程
        for (int i = 1; i < 37; i++) {
            contentValues.put("c_id", i);
            sqLiteDatabase.insert("classes_db", "", contentValues);
        }

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        // 資料庫升級邏輯，如果版本號變更，可以在這裡處理
        // 在此示例中，我們未執行任何操作

    }
}

