package com.example.contactbook.ui.login;

import androidx.annotation.Nullable;

/**
 * Data validation state of the login form.
 */
class LoginFormState {
    @Nullable
    private Integer usernameError;// 用於存儲用戶名驗證錯誤的資源 ID（如果有錯誤）。
    @Nullable
    private Integer passwordError;// 用於存儲密碼驗證錯誤的資源 ID（如果有錯誤）。
    private boolean isDataValid; // 表示表單是否有效的標誌。

    // 帶有錯誤資源 ID 的構造函數，用於表示表單有驗證錯誤的情況。
    LoginFormState(@Nullable Integer usernameError, @Nullable Integer passwordError) {
        this.usernameError = usernameError;
        this.passwordError = passwordError;
        this.isDataValid = false; // 表示表單無效。
    }

    // 帶有有效標誌的構造函數，用於表示表單數據驗證通過的情況。
    LoginFormState(boolean isDataValid) {
        this.usernameError = null;
        this.passwordError = null;
        this.isDataValid = isDataValid; // 表示表單有效。
    }

    @Nullable
    Integer getUsernameError() {
        return usernameError;
    }

    @Nullable
    Integer getPasswordError() {
        return passwordError;
    }

    boolean isDataValid() {
        return isDataValid;
    }
}