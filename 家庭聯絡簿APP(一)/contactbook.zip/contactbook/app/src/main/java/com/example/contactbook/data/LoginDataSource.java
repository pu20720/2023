package com.example.contactbook.data;

import com.example.contactbook.data.model.LoggedInUser;

import java.io.IOException;

/**
 * 這個類別處理帶有登入憑證的身份驗證，並擷取使用者資訊。
 */
public class LoginDataSource {

    public Result<LoggedInUser> login(String username, String password) {

        try {
            // TODO: 處理已登入使用者的身份驗證
            LoggedInUser fakeUser =
                    new LoggedInUser(
                            java.util.UUID.randomUUID().toString(),
                            "");
            return new Result.Success<>(fakeUser);
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }

    public void logout() {
        // TODO: 撤銷身份驗證
    }
}