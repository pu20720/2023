package com.example.contactbook;

public class Note {
    int id;      // 筆記的唯一識別號
    String title; // 筆記標題
    String data;  // 筆記內容

    // 建構子，用於初始化筆記的屬性
    public Note(int id_, String t_, String d_) {
        id = id_;
        title = t_;
        data = d_;
    }

}
