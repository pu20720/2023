package com.example.contactbook;

import android.graphics.Path;
import android.graphics.PathMeasure;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SerializablePath implements Serializable {
    private List<Float> points;
    private int color;

    public SerializablePath(Path path, int color) {
        this.color = color;
        this.points = pathToFloatArray(path);
    }

    public Path toPath() {
        Path path = new Path();
        if (points.size() >= 2) {
            path.moveTo(points.get(0), points.get(1));
            for (int i = 2; i < points.size(); i += 2) {
                path.lineTo(points.get(i), points.get(i + 1));
            }
        }
        return path;
    }

    public int getColor() {
        return color;
    }

    private List<Float> pathToFloatArray(Path path) {
        List<Float> pointList = new ArrayList<>();
        PathMeasure pathMeasure = new PathMeasure(path, false);
        float[] coordinates = new float[2];

        for (float distance = 0; distance < pathMeasure.getLength(); distance += 1) {
            pathMeasure.getPosTan(distance, coordinates, null);
            pointList.add(coordinates[0]);
            pointList.add(coordinates[1]);
        }
        return pointList;
    }
}

