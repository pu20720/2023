package com.example.contactbook;

class Friend {
    int id;        // 朋友的編號
    String name;   // 朋友的名字
    String tel;    // 朋友的電話號碼
    String addr;   // 朋友的地址

    // 建構子用來初始化朋友的資訊
    public Friend(int id_, String n_, String t_, String a_) {
        id = id_;
        name = n_;
        tel = t_;
        addr = a_;
    }
}
