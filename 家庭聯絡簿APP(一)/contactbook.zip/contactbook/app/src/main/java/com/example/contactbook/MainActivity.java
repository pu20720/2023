package com.example.contactbook;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    String DB = "CCLo";
    ArrayList<Friend> fList = new ArrayList<>();
    ArrayList<Note> uList = new ArrayList<>();
    SQLiteHelper helper;
    Gson gson = new Gson();
    Button bt_frined, bt_note;
    FrameLayout frameLayout;
    Frag_Friend frag_friend;
    Frag_Note frag_note;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 取得畫面元件
        bt_frined = findViewById(R.id.bt_friend);
        bt_note = findViewById(R.id.bt_note);
        frameLayout = findViewById(R.id.frame);

        // 初始化資料庫助手
        helper = new SQLiteHelper(this, DB, null, 1);

        // 初始化兩個片段
        frag_friend = new Frag_Friend(this);
        frag_note = new Frag_Note(this);


        // 設定按鈕點擊監聽器，切換片段
        bt_frined.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "顯示通訊錄", Toast.LENGTH_LONG).show();
                FragmentTransaction t = getSupportFragmentManager().beginTransaction();
                t.replace(R.id.frame, frag_friend)
                        .commit();
            }
        });
        bt_note.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "顯示記事本", Toast.LENGTH_LONG).show();
                FragmentTransaction t = getSupportFragmentManager().beginTransaction();
                t.replace(R.id.frame, frag_note)
                        .commit();
            }
        });
    }

    ActivityResultLauncher<Intent> friendEditLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        String json = data.getStringExtra("json");
                        Friend p = gson.fromJson(json, Friend.class);
                        helper.updateFriend(p);
                        frag_friend.update();
                    }
                }
            });

    ActivityResultLauncher<Intent> newFriendLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent it = result.getData();
                        String json = it.getStringExtra("json");
                        Friend f = gson.fromJson(json, Friend.class);
                        helper.addFriend(f.name, f.tel, f.addr);
                        frag_friend.update();
                    }
                }
            }
    );

    ActivityResultLauncher<Intent> noteEditLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        String json = data.getStringExtra("json");
                        Note p = gson.fromJson(json, Note.class);
                        helper.updateNote(p);
                        frag_note.update();
                    }
                }
            });

    ActivityResultLauncher<Intent> newNoteLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent it = result.getData();
                        String json = it.getStringExtra("json");
                        Note p = gson.fromJson(json, Note.class);
                        helper.addNote(p.title, p.data);
                        frag_note.update();
                    }
                }
            }
    );

}