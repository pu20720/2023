package com.example.contactbook;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;


public class ChatActivity extends AppCompatActivity {
    private EditText messageEditText;
    private Button sendButton;
    private TextView chatTextView;
    private TextView serverStatusTextView;

    private Socket socket;
    private BufferedReader in;
    private OutputStream out;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chatactivity);

        messageEditText = findViewById(R.id.messageEditText);
        sendButton = findViewById(R.id.sendButton);
        chatTextView = findViewById(R.id.chatTextView);
        serverStatusTextView = findViewById(R.id.serverStatusTextView);

        serverStatusTextView.setText("Server Status: Disconnected");

        sendButton.setOnClickListener(v -> {
            String message = messageEditText.getText().toString();
            sendMessage(message);
        });

        new ConnectToServerTask().execute();
    }

    private void sendMessage(String message) {
        new SendMessageTask().execute(message);
        messageEditText.setText("");
    }

    private class ConnectToServerTask extends AsyncTask<Void, Void, Boolean> {
        @Override
        protected Boolean doInBackground(Void... voids) {
            try {
                socket = new Socket("13.211.157.247", 22);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = socket.getOutputStream();
                runOnUiThread(() -> serverStatusTextView.setText("Server Status: Connected"));
                return true;
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean connected) {
            if (!connected) {
                // 连接失败的处理
            }
        }
    }

    private class SendMessageTask extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... messages) {
            for (String message : messages) {
                try {
                    out.write(message.getBytes());
                    out.write("\n".getBytes());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
    }

    private class ReceiveMessageTask extends AsyncTask<Void, String, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                while (true) {
                    String message = in.readLine();
                    if (message != null) {
                        publishProgress(message);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(String... values) {
            chatTextView.append(values[0] + "\n");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        new ReceiveMessageTask().execute();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}