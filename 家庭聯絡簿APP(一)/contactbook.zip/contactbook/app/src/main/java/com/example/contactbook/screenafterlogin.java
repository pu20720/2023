package com.example.contactbook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.contactbook.curriculum.curriculum;

public class screenafterlogin extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screenafterlogin);

        // 建立 jnote 按鈕的點擊事件監聽器
        Button jnote = findViewById(R.id.jnote);
        jnote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 點擊 jnote 按鈕時，建立一個 Intent 以導航到 MainActivity
                Intent intent = new Intent(screenafterlogin.this, MainActivity.class);
                startActivity(intent);
            }
        });

        Button b_sign3 = findViewById(R.id.b_sign3);
        b_sign3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(screenafterlogin.this, sign1.class);
                startActivity(intent);
            }
        });


        Button b_sign2 = findViewById(R.id.b_sign2);
        b_sign2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(screenafterlogin.this, WE.class);
                startActivity(intent);
            }
        });

        Button b_sign = findViewById(R.id.b_sign);
        b_sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(screenafterlogin.this, ChatActivity.class);
                startActivity(intent);
            }
        });



        // 建立 b_curriculum 按鈕的點擊事件監聽器
        Button b_curriculum = findViewById(R.id.b_curriculum);
        b_curriculum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 點擊 b_curriculum 按鈕時，建立一個 Intent 以導航到 curriculum 類別
                Intent intent = new Intent(screenafterlogin.this, curriculum.class);
                startActivity(intent);
            }
        });
    }
}
