package com.example.contactbook;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.ArrayList;


public class Frag_Friend extends Fragment {

    RecyclerView rcv_friend;  // 顯示朋友清單的 RecyclerView
    Button btNewFriend;      // 用於新增朋友的按鈕
    MainActivity main;       // 主活動的參考
    FriendAdapter friendAdapter; // 用於填充朋友清單的適配器
    ArrayList<Friend> fList = new ArrayList<>(); // 朋友清單

    public Frag_Friend() {
        // 空的建構子
    }

    public Frag_Friend(Context c_) {
        main = (MainActivity) c_; // 建構子接受主活動的參考
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    public void update() {
        friendAdapter.pList = main.helper.getAllFriends();
        friendAdapter.notifyDataSetChanged();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_frag__friend, container, false);
        rcv_friend = v.findViewById(R.id.rcv_friend);
        btNewFriend = v.findViewById(R.id.btNewFriend);
        fList = main.helper.getAllFriends();
        rcv_friend.setLayoutManager(new LinearLayoutManager(main));
        friendAdapter = new FriendAdapter(main, fList);
        rcv_friend.setAdapter(friendAdapter);

        btNewFriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(main, Act_Friend.class);
                it.putExtra("action", Action.NEW); // 傳遞新增操作給新朋友活動
                main.newFriendLauncher.launch(it);

            }
        });


        return v;
    }
}