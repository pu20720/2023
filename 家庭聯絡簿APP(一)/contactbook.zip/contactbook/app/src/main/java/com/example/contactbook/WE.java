package com.example.contactbook;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Person;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class WE extends AppCompatActivity {

    RecyclerView rcv;
    ArrayList<Person> people = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.we);

        rcv = findViewById(R.id.rcv);

        Person aa = new Person(R.drawable.aa, "賴族長", "0900-000-000", "資工四B");
        Person bb = new Person(R.drawable.bb, "陳同學", "0911-111-111", "資工四B");
        Person cc = new Person(R.drawable.cc, "曾同學", "0922-222-222", "資工四B");

        people.add(aa);
        people.add(bb);
        people.add(cc);

        rcv.setLayoutManager(new LinearLayoutManager(this));
        MyAdapter adapter = new MyAdapter(this, people);
        rcv.setAdapter(adapter);
    }

    class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyviewHolder> {
        Context context;
        ArrayList<Person> plist;

        public MyAdapter(Context c_, ArrayList<Person> p_) {
            context = c_;
            plist = p_;
        }

        @NonNull
        @Override
        public MyAdapter.MyviewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.rcv_item, parent, false);
            return new MyviewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyAdapter.MyviewHolder holder, int position) {
            holder.iv_photo.setImageResource(plist.get(position).photoId);
            holder.tv_name.setText(plist.get(position).name);
            holder.tv_tel.setText(plist.get(position).tel);
            holder.tv_addr.setText(plist.get(position).addr);
        }

        @Override
        public int getItemCount() {
            return plist.size();
        }

        class MyviewHolder extends RecyclerView.ViewHolder {
            TextView tv_name, tv_tel, tv_addr;
            ImageView iv_photo;

            public MyviewHolder(@NonNull View itemView) {
                super(itemView);
                iv_photo = itemView.findViewById(R.id.iv_photo);
                tv_name = itemView.findViewById(R.id.tv_name);
                tv_tel = itemView.findViewById(R.id.tv_tel);
                tv_addr = itemView.findViewById(R.id.tv_addr);
            }
        }
    }


    class Person {
        int photoId;
        String name, tel, addr;

        public Person(int pId_, String n_, String t_, String a_) {
            photoId = pId_;
            name = n_;
            tel = t_;
            addr = a_;
        }
    }
}
