package com.example.contactbook.curriculum;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;

import com.example.contactbook.R;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;

import androidx.core.view.WindowCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.contactbook.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.GridLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class curriculum extends AppCompatActivity implements View.OnTouchListener {

    public final String DB_NAME = "classes_db.db";
    public final String TABLE_NAME = "classes_db";

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_curriculum);
        // 隱藏操作列
//        getSupportActionBar().hide();


        // 取得資料庫連線物件，用於讀取資料
        DBHelper dbHelper = new DBHelper(curriculum.this, DB_NAME, null, 1);

        // 動態建立課程格子
        framework();

        // 將資料庫中的課程資料顯示在格子中
        applyDraw(dbHelper);

    }

    public GridLayout LayoutColumn(int i) {

        GridLayout gridLayout = findViewById(R.id.d1);

        switch (i) {
            case 1: {
                gridLayout = findViewById(R.id.d1);
                break;
            }
            case 2: {
                gridLayout = findViewById(R.id.d2);
                break;
            }
            case 3: {
                gridLayout = findViewById(R.id.d3);
                break;
            }
            case 4: {
                gridLayout = findViewById(R.id.d4);
                break;
            }
            case 5: {
                gridLayout = findViewById(R.id.d5);
                break;
            }
            case 6: {
                gridLayout = findViewById(R.id.d6);
                break;
            }
            case 7: {
                gridLayout = findViewById(R.id.d7);
                break;
            }
        }
        return gridLayout;
    }

    public void framework() {

        GridLayout gridLayout;
        int id = 1;

        for (int i = 1; i < 8; i++) {

            gridLayout = LayoutColumn(i);

            for (int j = 1; j < 10; j += 2) {
                TextView textView1 = new TextView(this);

                textView1.setId(id++);
                textView1.setText("");
                textView1.setMaxLines(5);
                textView1.setEllipsize(TextUtils.TruncateAt.END);
                textView1.setBackgroundColor(Color.parseColor("#F0FFFF"));
                textView1.setGravity(Gravity.CENTER);


                GridLayout.LayoutParams params1 = new GridLayout.LayoutParams();
                params1.rowSpec = GridLayout.spec(j, 2, 1);
                params1.setMargins(5, 10, 5, 10);
                params1.width = GridLayout.LayoutParams.MATCH_PARENT;
                params1.height = 0;

                gridLayout.addView(textView1, params1);
            }

        }

    }

    public void applyDraw(DBHelper dbHelper) {

        // 從資料庫中取得課程資料，並儲存在類別的清單中
        List<Classes> classes = query(dbHelper);

        for (Classes aClass : classes) {
            //第幾堂課
            int i = Integer.parseInt(aClass.getC_time().charAt(0) + "");

            //星期幾
            int j = utils.getDay(aClass.getC_day());

            // 取得此課程對應的 TextView 的 ID
            TextView Class = findViewById((j - 1) * 5 + ((i - 1) / 2 + 1));

            // 如果課程的星期和當前星期相同，則更改背景顏色
            Date date = new Date();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEEE");
            if (aClass.getC_day().equals(simpleDateFormat.format(date).toString())) {
                Class.setBackgroundColor(Color.rgb(28, 217, 204));
            }
// 設定當天的背景顏色
            // 設定課程資訊
            Class.setText(aClass.getC_name());// 設定課程名稱

            // 觸碰課程框時觸發事件
            Class.setOnTouchListener(this);// 設定觸碰事件監聽器

        }

    }

    @SuppressLint("Range")
    public List<Classes> query(DBHelper dbHelper) {

        List<Classes> classes = new ArrayList<>();
        // 透過DBHelper類別取得一個讀寫的SQLiteDatabase對象
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        Cursor cursor = db.query(TABLE_NAME, null, null, null, null, null, null);

        // 將滑鼠移到開頭
        cursor.moveToFirst();

        while (!cursor.isAfterLast()) { // 滑鼠只要不是在最後一行之後，就一直循環

            if (!cursor.getString(cursor.getColumnIndex("c_day")).equals("0")) {
                Classes Class = new Classes();

                Class.setC_id(Integer.parseInt(cursor.getString(cursor.getColumnIndex("c_id"))));
                Class.setC_name(cursor.getString(cursor.getColumnIndex("c_name")));
                Class.setC_time(cursor.getString(cursor.getColumnIndex("c_time")));
                Class.setC_day(cursor.getString(cursor.getColumnIndex("c_day")));

                classes.add(Class);
            }

            // 將滑鼠移到下一行
            cursor.moveToNext();

        }

        db.close();
        return classes;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_main, menu);


        MenuItem menuItem = menu.findItem(R.id.action_menu);

        menuItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                Intent intent = new Intent();
                intent.setClass(curriculum.this, DialogModal.class);
                startActivity(intent);
                return true;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    @SuppressLint("Range")
    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {


        switch (motionEvent.getAction()) {
            case MotionEvent.ACTION_DOWN: {
                TextView textView = (TextView) view;


                DBHelper dbHelper = new DBHelper(curriculum.this, DB_NAME, null, 1);
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                Cursor cursor = db.query(TABLE_NAME, null, "c_id=?", new String[]{String.valueOf(textView.getId())}, null, null, null);

                // 將滑鼠移到開頭
                cursor.moveToFirst();
                if (!cursor.isAfterLast()) {
                    Classes Class = new Classes();
                    System.out.println(textView.getId());
                    System.out.println(cursor.getString(cursor.getColumnIndex("c_name")));

                    Intent intent = new Intent();
                    intent.putExtra("name", cursor.getString(cursor.getColumnIndex("c_name")));
                    intent.putExtra("time", cursor.getString(cursor.getColumnIndex("c_time")));
                    intent.putExtra("day", cursor.getString(cursor.getColumnIndex("c_day")));
                    intent.putExtra("teacher", cursor.getString(cursor.getColumnIndex("c_teacher")));
                    intent.setClass(curriculum.this, Detail.class);
                    startActivity(intent);

                }
                return true;
            }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                Intent intent = new Intent(this, curriculum.class);
                startActivity(intent);
                break;
            }
        }

        return false;
    }

}
