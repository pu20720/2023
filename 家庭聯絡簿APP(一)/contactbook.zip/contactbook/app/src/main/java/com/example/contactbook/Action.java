package com.example.contactbook;

public class Action {
    final static String EDIT = "EDIT";     // 編輯操作
    final static String NEW = "NEW";       // 新建操作
    final static String DELETE = "DELETE"; // 刪除操作
    final static String CANCEL = "CANCEL"; // 取消操作
}
