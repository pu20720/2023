package com.example.contactbook;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class PaintView extends View {

    private Path mPath;
    private Paint mPaint;
    private Canvas mCanvas;
    private Bitmap mCacheBitmap;
    private ArrayList<Path> paths = new ArrayList<>();
    private ArrayList<Integer> colors = new ArrayList<>();
    private int selectedColor = Color.BLACK;

    public void setSelectedColor(int color) {
        selectedColor = color;
        mPaint.setColor(selectedColor);
    }

    public PaintView(Context context) {
        super(context);
        mPaint = new Paint();
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeWidth(10);
        mPaint.setColor(selectedColor); // 設置初始顏色
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        mCacheBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        mCanvas = new Canvas(mCacheBitmap);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mPath = new Path();
                mPath.moveTo(x, y);
                paths.add(mPath); // 儲存路徑
                colors.add(mPaint.getColor()); // 儲存顏色
                break;

            case MotionEvent.ACTION_MOVE:
                mPath.lineTo(x, y);
                break;

            case MotionEvent.ACTION_UP:
                // 不需要特殊處理
                break;
        }

        invalidate(); // 通知 View 重劃
        return true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // 繪製之前的路徑
        for (int i = 0; i < paths.size(); i++) {
            mPaint.setColor(colors.get(i));
            canvas.drawPath(paths.get(i), mPaint);
        }
    }

    public void clear() {
        paths.clear();
        colors.clear();
        mCacheBitmap.eraseColor(Color.WHITE);
        invalidate();
    }

    public void save(String filename) {
        try {
            FileOutputStream fos = getContext().openFileOutput(filename, Context.MODE_PRIVATE);
            ObjectOutputStream os = new ObjectOutputStream(fos);

            // 將每個路徑和顏色轉換為 SerializablePath
            ArrayList<SerializablePath> serializablePaths = new ArrayList<>();
            for (int i = 0; i < paths.size(); i++) {
                serializablePaths.add(new SerializablePath(paths.get(i), colors.get(i)));
            }

            // 寫入 SerializablePath 列表
            os.writeObject(serializablePaths);
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "儲存簽名：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void load(String filename) {
        try {
            FileInputStream fis = getContext().openFileInput(filename);
            ObjectInputStream is = new ObjectInputStream(fis);

            // 讀取 SerializablePath 列表
            ArrayList<SerializablePath> serializablePaths = (ArrayList<SerializablePath>) is.readObject();

            // 轉換 SerializablePath 為路徑和顏色
            paths.clear();
            colors.clear();
            for (SerializablePath sp : serializablePaths) {
                paths.add(sp.toPath());
                colors.add(sp.getColor());
            }

            is.close();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "載入請簽名：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}