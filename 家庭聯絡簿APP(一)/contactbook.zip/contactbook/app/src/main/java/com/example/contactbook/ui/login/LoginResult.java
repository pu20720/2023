package com.example.contactbook.ui.login;

import androidx.annotation.Nullable;

/**
 * Authentication result : success (user details) or error message.
 */
class LoginResult {
    @Nullable
    private LoggedInUserView success; // 用於存儲身份驗證成功時的用戶詳細信息。
    @Nullable
    private Integer error; // 用於存儲身份驗證錯誤時的錯誤消息的資源 ID。

    // 帶有錯誤資源 ID 的構造函數，用於表示身份驗證失敗的情況。
    LoginResult(@Nullable Integer error) {
        this.error = error;
    }

    // 帶有用戶詳細信息的構造函數，用於表示身份驗證成功的情況。
    LoginResult(@Nullable LoggedInUserView success) {
        this.success = success;
    }

    @Nullable
    LoggedInUserView getSuccess() {
        return success;
    }

    @Nullable
    Integer getError() {
        return error;
    }
}
