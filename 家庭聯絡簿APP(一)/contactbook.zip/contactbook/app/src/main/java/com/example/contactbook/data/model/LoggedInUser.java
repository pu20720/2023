package com.example.contactbook.data.model;

/**
 * 這是一個資料類別，用於捕獲從 LoginRepository 擷取的已登入使用者的資訊。
 */
public class LoggedInUser {

    private String userId;
    private String displayName;

    public LoggedInUser(String userId, String displayName) {
        this.userId = userId;
        this.displayName = displayName;
    }

    public String getUserId() {
        return userId;
    }

    public String getDisplayName() {
        return displayName;
    }
}