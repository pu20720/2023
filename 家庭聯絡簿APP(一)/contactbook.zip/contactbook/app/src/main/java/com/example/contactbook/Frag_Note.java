package com.example.contactbook;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.ArrayList;


public class Frag_Note extends Fragment {
    RecyclerView rcv_note;      // 顯示筆記清單的 RecyclerView
    Button btNewNote;          // 用於新增筆記的按鈕
    MainActivity main;         // 主活動的參考
    NoteAdapter noteAdapter;  // 用於填充筆記清單的適配器
    ArrayList<Note> n_List = new ArrayList<>(); // 筆記清單

    public Frag_Note() {
    }

    public Frag_Note(Context c_) {
        main = (MainActivity) c_; // 建構子接受主活動的參考
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    public void update() {
        noteAdapter.nList = main.helper.getAllNotes();
        noteAdapter.notifyDataSetChanged();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_frag__note, container, false);
        rcv_note = v.findViewById(R.id.rcv_note);
        btNewNote = v.findViewById(R.id.btNewNote);
        n_List = main.helper.getAllNotes();
        rcv_note.setLayoutManager(new LinearLayoutManager(main));
        noteAdapter = new NoteAdapter(main, n_List);
        rcv_note.setAdapter(noteAdapter);

        btNewNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(main, Act_Note.class);
                it.putExtra("action", Action.NEW); // 傳遞新增操作給新筆記活動
                main.newNoteLauncher.launch(it);

            }
        });


        return v;
    }
}