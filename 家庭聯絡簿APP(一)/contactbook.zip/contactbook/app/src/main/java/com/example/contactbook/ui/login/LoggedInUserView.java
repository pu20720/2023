package com.example.contactbook.ui.login;

/**
 * 這是一個用於將已驗證的使用者詳細資訊提供給使用者介面（UI）的類別。
 */
class LoggedInUserView {
    private String displayName;
    //... 可能對 UI 可存取的其他資料欄位

    LoggedInUserView(String displayName) {
        this.displayName = displayName;
    }

    String getDisplayName() {
        return displayName;
    }
}