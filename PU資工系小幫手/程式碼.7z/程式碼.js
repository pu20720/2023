
var spreadSheetConfig = SpreadsheetApp.getActive();
var sheetConfig = spreadSheetConfig.getSheetByName("參數設定");
var sheetConfigData = sheetConfig.getSheetValues(1, 2, sheetConfig.getLastRow(), sheetConfig.getLastColumn() - 1);
var CHANNEL_ACCESS_TOKEN = sheetConfigData[0][0].replace(/\r?\n|\r/g,"");    //Line Bot 的權杖，並消除換行符號（避免有人複製貼上時複製到換行符號）
var imageFolderId = sheetConfigData[1][0];    //存放圖片的資料夾ID
var spreadSheetId = sheetConfigData[2][0];    //要被搜尋的 Google 試算表 ID
var sheetName = transformArray(sheetConfigData[3]);    //搜尋的工作表名稱
var searchColumn = transformColumnNum(transformArray(sheetConfigData[4]));    //搜尋第幾欄的資料
var hiddenColumn = transformColumnNum(transformArray(sheetConfigData[5]));    //不要將資料傳送到 Line 的欄位
var imageIdColumn = transformColumnNum(transformArray(sheetConfigData[6]));    //取得圖片檔 ID 所在的欄位
var datetimeColumn =  transformColumnNum(transformArray(sheetConfigData[7]));    //取得資料內容是日期時間的欄位
var datetimeFormatColumn =  transformArray(sheetConfigData[8]);    //取得日期時間欄位要呈現的日期時間格式（日期時間都顯示、只顯示日期或只顯示時間）
var simpleModeColumn = transformColumnNum(transformArray(sheetConfigData[9]));    //取得精簡模式時 Flex Message 所顯示的欄位
var simpleMode = sheetConfigData[10][0];    //檢查精簡模式是否啟用
var fuzzySearch = sheetConfigData[11][0];    //檢查模糊搜尋是否啟用
var whiteListMode = sheetConfigData[12][0];    //檢查白名單模式是否啟用
var whiteList = transformArray(sheetConfigData[13]);  //白名單（允許取得資料的使用者 ID）
var initialSearch = sheetConfigData[14][0];    //是否開頭輸入關鍵字才進行搜尋
var onceMaxMessages = sheetConfigData[15][0];    //每次回傳訊息數的最大量（目前最多是 5 則）
var carouselMaxLoad = sheetConfigData[16][0];    //Line 的輪播 Flex Message 每次最多可顯示的 Bubble 數量（目前最多是 12 則）
var flexImageFrameRatio = sheetConfigData[17][0] + sheetConfigData[17][1] + sheetConfigData[17][2];
var flexImageType = sheetConfigData[18][0];
if (flexImageType == "填滿"){flexImageType = "cover";} else{flexImageType = "fit";} //Flex Message 圖片的呈現方式
var flexTitleRatio = sheetConfigData[19][0]; var flexContentRatio = sheetConfigData[19][2];
var spreadSheet;

//取得圖片資料夾的ID和檔名
function getImageFileData() {
  if (imageFolderId != "" && spreadSheetId != "" && sheetName.length != 0 && imageIdColumn.length != 0) {
    getDatabase();
    var imageFolder = DriveApp.getFolderById(imageFolderId);
    var childFolders = imageFolder.getFolders();
    while (childFolders.hasNext()) {
      var childFolder = childFolders.next();
      
      //如果存在和工作表名稱相同的資料夾，從此資料夾裡面找出檔案的 ID 和檔名
      if (sheetName.indexOf(childFolder.getName()) != -1) {
        var files = childFolder.getFiles();
        var fileData = [];
        while (files.hasNext()) {
          var file = files.next();
          fileData.push([file.getId(), file.getName()]);
        }
        var sheet = spreadSheet.getSheetByName(childFolder.getName());
        sheet.getRange(2, imageIdColumn[0], fileData.length, 2).setValues(fileData);
      }
    }
    Browser.msgBox("檔案 ID 取得完成");
  }
  else {
    var returnMessage = ""
    if (imageFolderId == "") {Browser.msgBox("「圖片存放位置資料夾 ID」未填寫");}
    if (spreadSheetId == "") {Browser.msgBox("「要搜尋的試算表 ID」未填寫");}
    if (sheetName.length == 0) {Browser.msgBox("「搜尋工作表名稱」未填寫");}
    if (imageIdColumn.length == 0) {Browser.msgBox("「圖片檔ID欄位」未填寫");}
  }
}

//移除試算表空儲存格
function transformArray(arrayData) {
  var returnArray = [];
  for (var i = 0; i < arrayData.length; i++) {
    if (arrayData[i] !== "") {returnArray.push(arrayData[i]);}
  }
  return returnArray;
}

//把英文字母的欄位轉換成數字
function transformColumnNum(arrayData) {
  var returnArray = [];
  var transformStr;
  var transformNum;
  for (var i = 0; i < arrayData.length; i++) {
    transformStr = arrayData[i].toUpperCase();
    transformNum = 0;
    for (var j = 0; j < transformStr.length; j++) {
      transformNum += Math.pow(26, (transformStr.length - j - 1)) * (transformStr.charCodeAt(j) - 64)
    }
    returnArray.push(transformNum);
  }
  return returnArray;
}

//接收 Line 訊息並進行分析
function doPost(e) {
    getDatabase();
    var userData = JSON.parse(e.postData.contents);
    var replyToken = userData.events[0].replyToken;
    var allowed = whiteListMode;
    var clientID;


//判斷訊息是要回復給個人、群組還是聊天室
    if (userData.events[0].source.type == "user") { clientID = userData.events[0].source.userId;}
    if (userData.events[0].source.type == "group") {clientID = userData.events[0].source.groupId;}
    if (userData.events[0].source.type == "room") {clientID = userData.events[0].source.roomId;}
  
    //白名單模式檢查
    if (allowed == true) {
  
      // 檢查是否是允許的用者提出搜尋需求
      var allowedUser = whiteList.filter(function(item, index, array){
        return item.toString() == clientID;
      });
  
      //非白名單使用者、新加入使用者或使用者輸入了「FindMyID」關鍵字，則輸出使用者 ID
      if (allowedUser.length === 0 || userData.events[0].type == "follow" || userData.events[0].type == "join" || (userData.events[0].message && userData.events[0].message.text.toLowerCase() == "findmyid")) {
        var replyMessage = [{type:"text", text:"您的 " + userData.events[0].source.type + " ID 是「" + clientID + "」，請將此 ID 告知此官方帳號的擁有者加入白名單後才能開始查詢資料。"}];
        sendReplyMessage(CHANNEL_ACCESS_TOKEN, replyToken, replyMessage);
        return;
      }
    }
  


    var sendStart = 0;  //此變數用來判斷從第幾筆資料開始顯示
    if (!(userData.events[0].message || userData.events[0].postback)) {return;} //不處理 message 或 postback 以外的訊息
  
    //當使用者輸入的是文字則進行搜尋功能
    if (userData.events[0].message && userData.events[0].message.type == "text") {
      var word = userData.events[0].message.text;
      
      // 解析使用者傳出的訊息內容
      var searchContent = word;
      searchContent = searchContent.replace("程式設計能力畢業門檻", "畢業門檻"); 
      searchContent = searchContent.replace("人文素養畢業門檻", "畢業門檻"); 
      searchContent = searchContent.replace("英文畢業門檻", "畢業門檻");  
      searchContent = searchContent.replace("通識畢業門檻", "畢業門檻"); 
      searchContent = searchContent.replace("程式設計能力畢業條件", "畢業門檻"); 
      searchContent = searchContent.replace("人文素養畢業條件", "畢業門檻"); 
      searchContent = searchContent.replace("英文畢業條件", "畢業門檻");  
      searchContent = searchContent.replace("通識畢業條件", "畢業門檻");
      searchContent = searchContent.replace("程式設計能力", "畢業門檻"); 
      searchContent = searchContent.replace("人文素養", "畢業門檻"); 
      searchContent = searchContent.replace("英文", "畢業門檻");  
      searchContent = searchContent.replace("通識", "畢業門檻"); 
      searchContent = searchContent.replace("上課教室", "尚克叫市"); 
      searchContent = searchContent.replace("校園資訊", "校園孜迅"); 
      searchContent = searchContent.replace("行政單位", "電話"); 
      searchContent = searchContent.replace("什麼時候", "行事曆");
      searchContent = searchContent.replace("什麼時間", "行事曆");
      searchContent = searchContent.replace("啥時", "行事曆");
      searchContent = searchContent.replace("哪一週", "行事曆");
      searchContent = searchContent.replace("哪週", "行事曆");
      searchContent = searchContent.replace("CPE", "畢業門檻"); 
      searchContent = searchContent.replace("其他", "other");
      searchContent = searchContent.replace("其它", "other");
      searchContent = searchContent.replace("聯絡方式", "");
      searchContent = searchContent.replace("教授", "老師");
      searchContent = searchContent.replace("這學期", "");
      searchContent = searchContent.replace("辦公室", "");
      searchContent = searchContent.replace("研究室", "");
      searchContent = searchContent.replace("email", "");
      searchContent = searchContent.replace("時刻表", "");
      searchContent = searchContent.replace("課程", "");
      searchContent = searchContent.replace("站牌", "");
      searchContent = searchContent.replace("信箱", "");
      searchContent = searchContent.replace("在哪", "");
      searchContent = searchContent.replace("課表", "");
      searchContent = searchContent.replace("教室", "");
      searchContent = searchContent.replace("時間", "");
      searchContent = searchContent.replace("哪天", "");
      searchContent = searchContent.replace("知道", "");
      searchContent = searchContent.replace("上課", "");
      searchContent = searchContent.replace("哪節", "");
      searchContent = searchContent.replace("是誰", "");  
      searchContent = searchContent.replace("哪些", "");
      searchContent = searchContent.replace("關於", "");
      searchContent = searchContent.replace("有關", "");      
      searchContent = searchContent.replace("資料", "");
      searchContent = searchContent.replace("資訊", "");
      searchContent = searchContent.replace("裡", "");
      searchContent = searchContent.replace("嗎", "");
      searchContent = searchContent.replace("？", "");
      searchContent = searchContent.replace("幫", "");
      searchContent = searchContent.replace("我", "");
      searchContent = searchContent.replace("查", "");
      searchContent = searchContent.replace("找", "");
      searchContent = searchContent.replace("要", "");
      searchContent = searchContent.replace("題", "");
      searchContent = searchContent.replace("想", "");
      searchContent = searchContent.replace("詢", "");   
      searchContent = searchContent.replace("在", "");
      searchContent = searchContent.replace("課", ""); 
      searchContent = searchContent.replace("他", "");
      searchContent = searchContent.replace("請", "");
      searchContent = searchContent.replace("問", "");
      searchContent = searchContent.replace("的", ""); 
            
       
      
      
      
    }
  
  //若使用者出入的是 postback 則分析是要顯示更多搜尋結果還是顯示詳細文字資訊
    else {
      var postbackData = userData.events[0].postback.data;    //陣列格式格式，有兩種，格式1：[showMore（顯示更多頁）, 搜尋字串, 數字（從這筆資料開始繼續顯示接下來的資料）]、格式2[show, 搜尋字串, 工作表名稱, index]
      var postbackArray = postbackData.split("m");//改
      if (postbackArray[0] == "show") {
        simpleMode = false; //顯示所有非隱藏欄、非空白資訊
        var replyData = searchSpreadsheet(postbackArray[1]);
  
        //從所有符合關鍵字的搜尋結果中挑出正確空做表內正確 index 的資料來做出詳細資訊訊息
        var resultArray = replyData.filter(function(item, index, array){
          return item[3] == postbackArray[2] && item[5] == parseInt(postbackArray[3]) ;
        });
        resultArray[0][4] = resultArray[0][4].replace(/資工系小幫手/g, "\n");//改
  
        var replyMessage = [];
        if (resultArray[0][4] != "") {replyMessage.push({type:"text", text:resultArray[0][4]});}
        if (resultArray[0][0] != 0) {replyMessage.push({type:"image", originalContentUrl:"https://drive.google.com/uc?id=" + resultArray[0][2], previewImageUrl:"https://drive.google.com/uc?id=" + resultArray[0][2]});}
        sendReplyMessage(CHANNEL_ACCESS_TOKEN, replyToken, replyMessage);
        return;
      }
  
      //顯示更多搜尋結果
      var searchContent = postbackArray[1];
      sendStart = parseInt(postbackArray[2]); //從 postback 所提供的位置開始呈現接下來的資料
    }

    //檢查使否需要起始關鍵字才能進行搜尋
    if (initialSearch != "") {
      if (searchContent.indexOf(initialSearch) != 0) {return;}
      else {searchContent = searchContent.replace(initialSearch, "");}
    }
    
    var word = userData.events[0].message.text;
    // 解析使用者傳出的訊息內容
    var userMessage = word;
    userMessage = userMessage.replace("程式設計能力畢業門檻", "畢業門檻"); 
    userMessage = userMessage.replace("人文素養畢業門檻", "畢業門檻"); 
    userMessage = userMessage.replace("英文畢業門檻", "畢業門檻");  
    userMessage = userMessage.replace("通識畢業門檻", "畢業門檻"); 
    userMessage = userMessage.replace("程式設計能力畢業條件", "畢業門檻"); 
    userMessage = userMessage.replace("人文素養畢業條件", "畢業門檻"); 
    userMessage = userMessage.replace("英文畢業條件", "畢業門檻");  
    userMessage = userMessage.replace("通識畢業條件", "畢業門檻"); 
    serMessage = userMessage.replace("程式設計能力", "畢業門檻"); 
    userMessage = userMessage.replace("人文素養", "畢業門檻"); 
    userMessage = userMessage.replace("英文", "畢業門檻");  
    userMessage = userMessage.replace("通識", "畢業門檻"); 
    userMessage = userMessage.replace("上課教室", "尚克叫市"); 
    userMessage = userMessage.replace("校園資訊", "校園孜迅"); 
    userMessage = userMessage.replace("行政單位", "電話"); 
    userMessage = userMessage.replace("CPE", "畢業門檻"); 
    userMessage = userMessage.replace("其他", "other");
    userMessage = userMessage.replace("其它", "other");
    userMessage = userMessage.replace("什麼時候", "行事曆");
    userMessage = userMessage.replace("什麼時間", "行事曆");
    userMessage = userMessage.replace("啥時", "行事曆");
    userMessage = userMessage.replace("哪一週", "行事曆");
    userMessage = userMessage.replace("哪週", "行事曆");
    userMessage = userMessage.replace("教授", "老師"); 
    userMessage = userMessage.replace("聯絡方式", "");
    userMessage = userMessage.replace("研究室", "");
    userMessage = userMessage.replace("email", "");
    userMessage = userMessage.replace("辦公室", "");
    userMessage = userMessage.replace("這學期", "");
    userMessage = userMessage.replace("時刻表", "");
    userMessage = userMessage.replace("課程", "");
    userMessage = userMessage.replace("站牌", "");
    userMessage = userMessage.replace("課表", "");
    userMessage = userMessage.replace("信箱", "");
    userMessage = userMessage.replace("在哪", "");
    userMessage = userMessage.replace("教室", "");
    userMessage = userMessage.replace("時間", "");
    userMessage = userMessage.replace("哪天", "");
    userMessage = userMessage.replace("知道", "");
    userMessage = userMessage.replace("上課", "");
    userMessage = userMessage.replace("哪節", "");
    userMessage = userMessage.replace("是誰", "");  
    userMessage = userMessage.replace("哪些", "");  
    userMessage = userMessage.replace("關於", "");
    userMessage = userMessage.replace("有關", "");      
    userMessage = userMessage.replace("資料", "");
    userMessage = userMessage.replace("資訊", "");
    userMessage = userMessage.replace("課", "");  
    userMessage = userMessage.replace("幫", "");
    userMessage = userMessage.replace("我", "");
    userMessage = userMessage.replace("他", "");
    userMessage = userMessage.replace("查", "");
    userMessage = userMessage.replace("找", "");
    userMessage = userMessage.replace("要", "");
    userMessage = userMessage.replace("詢", "");
    userMessage = userMessage.replace("題", "");
    userMessage = userMessage.replace("想", "");
    userMessage = userMessage.replace("請", "");
    userMessage = userMessage.replace("問", "");
    userMessage = userMessage.replace("裡", "");
    userMessage = userMessage.replace("嗎", "");
    userMessage = userMessage.replace("？", "");
    userMessage = userMessage.replace("的", "");
    userMessage = userMessage.replace("在", "");
    
    
    if (userMessage.length<2){
      replyMessage = '字數小於1'
      oneword(replyToken, replyMessage)
    }
    if (userMessage=="老師"){
      replyMessage = '只打了老師兩個字'
      toffice(replyToken, replyMessage)
    }


    switch(userMessage) {
        case '校園孜迅': // 圖文選單A區
            replyMessage = 'w'
            where(replyToken, replyMessage)
            break
        case '位置': // 圖文選單B區
            replyMessage = '位置'// 此行無用
            location(replyToken, replyMessage)
            break
        case '學業': // 圖文選單C區
            replyMessage = '課業問題'// 此行無用
            lesson(replyToken, replyMessage)
            break
        case '畢業門檻':
            replyMessage = '畢業門檻'// 此行無用
            graduate(replyToken, replyMessage)
            break
        case '搜尋': // 圖文選單D區
            replyMessage = '搜尋'// 此行無用
            search(replyToken, replyMessage)
            break
        case 'other': 
            replyMessage = '其它'// 此行無用
            other(replyToken, replyMessage)
            break
        case '失物招領': //未做
            replyMessage = '失物招領'// 此行無用
            miss(replyToken, replyMessage)
            break
        case '行事曆': 
            replyMessage = '行事曆'// 此行無用
            calendar(replyToken, replyMessage)
            break
        case '行事曆111_2': //picture
            replyMessage = '行事曆1112'// 此行無用
            calender1112(replyToken, replyMessage)
          break
        case '行事曆112_1': //picture
            replyMessage = '行事曆1121'// 此行無用
            calender1121(replyToken, replyMessage)
          break
        case '行事曆112_2': //picture
            replyMessage = '行事曆1122'// 此行無用
            calender1122(replyToken, replyMessage)
          break
        case '校園地圖': //picture
            replyMessage = '校園地圖'// 此行無用
            map(replyToken, replyMessage)
          break
        case '電話': //picture
            replyMessage = '行政單位'// 此行無用
            paperwork(replyToken, replyMessage)
          break
        case '尚克叫市': //picture
            replyMessage = '上課教室'// 此行無用
            classroom(replyToken, replyMessage)
          break
        case '老師、～': //picture
            replyMessage = '老師研究室'// 此行無用
            toffice(replyToken, replyMessage)
          break
        case '公車': //picture
            replyMessage = '公車'// 此行無用
            bus(replyToken, replyMessage)
          break
        case '林老師': //picture
            replyMessage = '林老師'// 此行無用
            teacherSameLin(replyToken, replyMessage)
          break
        case '翁老師': //picture
            replyMessage = '翁老師'// 此行無用
            teacherSameWon(replyToken, replyMessage)
          break
        case '陳老師': //picture
            replyMessage = '陳老師'// 此行無用
            teacherSameChen(replyToken, replyMessage)
          break
        case '劉老師': //picture
            replyMessage = '劉老師'// 此行無用
            teacherSameLiu(replyToken, replyMessage)
          break
        case '蔡老師': //picture
            replyMessage = '蔡老師'// 此行無用
            teacherSameTsai(replyToken, replyMessage)
          break
        default:
            break
    }
    function reply_text(text) {
        let msgdata = [{//作用域不一樣，var的作用域在函數(function) 裡，let的作用域則是在區塊(block) 裡。
                        "type": "text",
                        "text": text     //回傳文字訊息，內容為text也就是userMessage
                        }]

        return msgdata
    }
    //取出試算表搜尋的結果
function searchSpreadsheet(searchContent) {
  var replyData = [];
  for (var i = 0; i < sheetName.length; i++) {
    var searchResultTemp = [];
    var sheet = spreadSheet.getSheetByName(sheetName[i]);
    var lastRow = sheet.getLastRow();
    var lastColumn = sheet.getLastColumn();
    var sheetData = sheet.getSheetValues(1, 1, lastRow, lastColumn);  //取出工作表裡所有的資料

    //取出符合搜尋的資料
    for (var j = 0; j < searchColumn.length; j++){

      //從 sheetData 中取出所有符合搜尋關鍵字的資料
      var searchTemp = sheetData.filter(function(item, index, array){
        //如果模糊搜尋沒有啟動，則搜尋欄位裡的字要完全和搜尋關鍵字一模一樣
        if (fuzzySearch == false) {
          if (datetimeColumn.indexOf(searchColumn[j]) != -1) {
            switch (datetimeFormatColumn[datetimeColumn.indexOf(searchColumn[j])]) {
              case "顯示日期及時間":
                return new Date(item[searchColumn[j] - 1]).toLocaleString("zh-TW").toLowerCase() === searchContent.toLowerCase();
                break;
            
              case "顯示日期":
                return new Date(item[searchColumn[j] - 1]).toLocaleDateString("zh-TW").toLowerCase() === searchContent.toLowerCase();
                break;

              case "顯示時間":
                return new Date(item[searchColumn[j] - 1]).toLocaleTimeString("zh-TW").toLowerCase() === searchContent.toLowerCase();
                break;
            }
          }
          else {return item[searchColumn[j] - 1].toString().toLowerCase() === searchContent.toLowerCase();}
        }
        //如果模糊搜尋有啟動，則欄位裡只要有部分文字和搜尋關鍵字一樣
        else {
          if (datetimeColumn.indexOf(searchColumn[j]) != -1) {return new Date(item[searchColumn[j] - 1]).toLocaleString("zh-TW").toLowerCase().indexOf(searchContent.toLowerCase()) != -1;}
          else {return item[searchColumn[j] - 1].toString().toLowerCase().indexOf(searchContent.toLowerCase()) != -1;}
        }
      });
      searchResultTemp = searchResultTemp.concat(searchTemp);
    }

    //剔除重複的資料
    if (searchResultTemp.length > 0) {
      searchResultTemp = uniqueArrayElement(searchResultTemp);
      
      //把表單名稱放入搜尋結果陣列中，如果使用者是啟動跨工作表搜尋時，顯示詳細資料時才不會找不到正確的工作表
      for (var j = 0; j < searchResultTemp.length; j++) {
        searchResultTemp[j].push(sheetName[i]);
      }
    }

    searchResultTemp.unshift(sheetData[0]);    //把標題列放在最前面，方便結合文字內容時製作標題
    replyData = replyData.concat(convertSearchResultFormat(searchResultTemp, searchContent));
  }
  return replyData;
}

    
    

  var replyData = searchSpreadsheet(searchContent);    //把 searchResult 轉換成回復訊息所需要的資料格式，陣列資料格式[是否有圖（0表示沒有，1表示有）, 搜尋字串, 圖片ID（沒圖就是空字串）, 工作表名稱, 搜尋結果的文字訊息, index]
    var replyMessage = [];
    if (replyData.length == 0) {
      replyMessage.push({"type": "template",
                    "altText": "靜宜資工系的小幫手",
                    "template": {
                        "type": "carousel",
                        "columns": [
                            {
                                "title": "您好！我是靜宜資工系的小幫手🙋‍♂️",
                                "text": "請善用關鍵字搜尋要找的資訊\n有以下的資料可做搜尋～",
                                "actions": [
                                    {
                                        "type": "message",
                                        "label": "行政單位",
                                        "text": "行政單位"
                                    },
                                    {
                                        "type": "message",
                                        "label": "上課教室",
                                        "text": "上課教室"
                                    },
                                    {
                                        "type": "message",
                                        "label": "老師研究室、課表",
                                        "text": "老師研究室、課表～"
                                    }
                                ]
                            }
                        ]
                    }});
      //查詢不到「" + searchContent + "」的資料\n*有錯別字的話也找不到呦\n*如果不確定可以查哪些資料可以去圖文選單找找看呦><
      sendReplyMessage(CHANNEL_ACCESS_TOKEN, replyToken, replyMessage);
      return;
    }
    else {
      replyData = makeFlexMessages(replyData);
      replyMessage = makeSendMessages(replyData, sendStart, searchContent);
      sendReplyMessage(CHANNEL_ACCESS_TOKEN, replyToken, replyMessage);
    }

  }



//把最初的搜尋結果（searchSpreadsheet 函數）轉換成方便呈現的格式，格視為陣列，結構：[是否有圖（0表示沒有，1表示有）, 搜尋字串, 圖片ID（沒圖就是空字串）, 工作表名稱, 搜尋結果的文字訊息, index]
function convertSearchResultFormat(searchResult, searchContent) {
  var replyData = [];
  for (var k = 1; k < searchResult.length; k++) {
    var replyContent = "";

    //製作搜尋結果的文字訊息
    for (var l = 0; l < searchResult[k].length - 1; l++) {

      //如果是空白資料、圖片欄、隱藏欄或是精簡模式時且非搜尋欄或非精簡模式顯示欄位就不要輸出。
      if (searchResult[k][l] === "" || imageIdColumn.indexOf(l + 1) != -1 || hiddenColumn.indexOf(l + 1) != -1 || (simpleMode == true && ((simpleModeColumn.length == 0 && searchColumn.indexOf(l + 1) == -1) || (simpleModeColumn.length > 0 && simpleModeColumn.indexOf(l + 1) == -1)))) {}
      else {
        if (replyContent != "") {replyContent += "資工系小幫手";}

        //判斷是否是日期時間資料欄位，如果是則對日期時間的顯示格式做設定，若不是則直接輸出資料
        if (datetimeColumn.indexOf(l + 1) != -1) {
          switch (datetimeFormatColumn[datetimeColumn.indexOf(l + 1)]) {
            case "顯示日期及時間":
              replyContent += searchResult[0][l] + "：" + new Date(searchResult[k][l]).toLocaleString("zh-TW");
              break;
            
            case "顯示日期":
              replyContent += searchResult[0][l] + "：" + new Date(searchResult[k][l]).toLocaleDateString("zh-TW");
              break;

            case "顯示時間":
              replyContent += searchResult[0][l] + "：" + new Date(searchResult[k][l]).toLocaleTimeString("zh-TW");
              break;
          }
        }
        else {replyContent += searchResult[0][l] + "：" + searchResult[k][l];}
      }
    }

    var hasImage = 0;    //檢查是否有圖片需要輸出
    for (var m = 0; m < imageIdColumn.length; m++) {
      if (searchResult[k][imageIdColumn[m] - 1] != "" && hiddenColumn.indexOf(imageIdColumn[m]) == -1) {
        replyData.push([1, searchContent, searchResult[k][imageIdColumn[m] - 1], searchResult[k][searchResult[k].length - 1], replyContent, replyData.length]);
        hasImage = 1;
      }
    }
    if (hasImage === 0 && replyContent != "") {replyData.push([0, searchContent, "", searchResult[k][searchResult[k].length - 1], replyContent, replyData.length]);}
  }
  return replyData;
}

//製作呈現結果的 Flex Message Bubble
function makeFlexMessages(arrayData) {
  var flexMessages = [];
  for (var i = 0; i < arrayData.length; i++) {
    var flexMessage = {"type": "bubble"};

    //如果有圖片，則製作 hero 來放置圖片
    if (arrayData[i][0] == 1) {
      flexMessage.hero = {
        "type": "image",
        "url": "https://drive.google.com/uc?id=" + arrayData[i][2],
        "size": "full",
        "aspectRatio": flexImageFrameRatio,
        "aspectMode": flexImageType,
        "action": {
          "type": "postback",
          "label": arrayData[i][1],
          //"data": "showhttps://www.youtube.com/borispcp" + arrayData[i][1] + "https://www.youtube.com/borispcp" + arrayData[i][3] + "https://www.youtube.com/borispcp" + arrayData[i][5]
          "data": "showm" + arrayData[i][1] + "m" + arrayData[i][3] + "m" + arrayData[i][5]
        }
      };
    }
    flexMessage.body = {
      "type": "box",
      "layout": "vertical",
      "spacing": "md",
      "action": {
        "type": "postback",
        "label": arrayData[i][1],
        // "data": "showhttps://www.youtube.com/borispcp" + arrayData[i][1] + "https://www.youtube.com/borispcp" + arrayData[i][3] + "https://www.youtube.com/borispcp" + arrayData[i][5]
        "data": "show" + arrayData[i][1] + arrayData[i][3] + arrayData[i][5]//改
      },
      "contents": [
        {
          "type": "box",
          "layout": "vertical",
          "spacing": "sm",
          "contents": [
            {
              "type": "box",
              "layout": "baseline",
              "contents": [
                {
                  "type": "text",
                  "text": arrayData[i][3],
                  "weight": "bold",
                  "margin": "sm",
                  "size": "20px",
                  "wrap": true
                }
              ]
            }
          ]
        }
      ]
    };

    //製作文字部分的資料
    if (arrayData[i][4] != ""){
      var textContent = arrayData[i][4].split("資工系小幫手");
      for (var j = 0; j < textContent.length; j++) {
        flexMessage.body.contents = flexMessage.body.contents.concat({
          "type": "box",
          "layout": "vertical",
          "spacing": "sm",
          "contents": [
            {
              "type": "box",
              "layout": "baseline",
              "contents": [
                {
                  "type": "text",
                  "text": textContent[j].substring(0,textContent[j].indexOf("：")),
                  "color": "#848484",
                  "margin": "sm",
                  "align": "start",
                  "wrap": true,
                  "flex": flexTitleRatio
                },
                {
                  "type": "text",
                  "text": textContent[j].substring(textContent[j].indexOf("：") + 1),
                  "align": "start",
                  "wrap": true,
                  "flex": flexContentRatio
                }
              ]
            }
          ]
        });
      }
      
    }


    flexMessages.push(flexMessage);
  }
  return flexMessages;
}

//製作 Line 輪播的 Flex Message 的格式
function makeSendMessages(replyData, sendStart, searchContent) {
  var replyMessage = [];
  var level1 = 0; //用來記錄訊息數量是否已達到單次所能傳送的最大數量（onceMaxMessages - decreaseNum）
  var level2 = 0; //用來記錄 Flex Message Carousel 的 Bubble 數量是否已達到單則訊息內的最大值
  var stopPoint = sendStart;  //stopPoint 變數用來計算要呈現的資料是否已經達到最後一筆了
  var tempMessage = []; //用來記錄要以 Bubble 呈現的資料
  var sendMessage = []; //用來記錄要放到每一則訊息裡所有的 Bubble

  //如果是從第 1 筆資料開始呈現，代表是使用者剛輸入搜尋關鍵字後的搜尋結果，所以要扣掉頭尾兩則訊息保留給「總共找到多少筆資料」和「點選顯示更多資料」使用，不然只要保留一則給「點選顯示更多資料」用即可
  if (sendStart == 0) {var decreaseNum = 2;}
  else {var decreaseNum = 1;}
  
  //把 Bubble 以 Carousel 的 Flex Message 方式呈現，並配合資料數量調整版面（當單次傳送訊息數量未達最大值且資料未達最後一筆時執行）
  while(level1 < onceMaxMessages - decreaseNum && stopPoint < replyData.length) {
    tempMessage.push(replyData[stopPoint]);
    level2 += 1; stopPoint += 1;
    if (level2 == carouselMaxLoad || stopPoint == replyData.length) {
      level1 += 1;
      level2 = 0;
      sendMessage.push(tempMessage);
      tempMessage = [];
    }
  }

  if (sendStart == 0) {
    replyMessage.push({type:"text", text:"總共找到 " + replyData.length + " 筆相關資料\n👇🏻👇🏻👇🏻"});

    //判斷是否保留一則訊息給「點選顯示更多資料」使用
    if (sendMessage.length > onceMaxMessages - 2) {var loopEnd = onceMaxMessages - 2;}
    else {loopEnd = sendMessage.length;}
  }
  else {

    //判斷是否保留一則訊息給「點選顯示更多資料」使用
    if (sendMessage.length > onceMaxMessages - 1) {var loopEnd = onceMaxMessages - 1;}
    else {loopEnd = sendMessage.length;}
  }

  //製作 Carousel
  for (l = 0; l < loopEnd; l++) {
    replyMessage.push(
      {
        "type": "flex",
        "altText": "搜尋結果",
        "contents": {
          "type": "carousel",
          "contents": sendMessage[l]
        }
      }
    );
  }

  //如果 stopPoint < replyData.length，代表還有資料沒辦法在這一次的訊息裡顯示出來，因此需要製作「點選顯示更多資料」訊息
  if (stopPoint < replyData.length) {
    replyMessage.push(
      {
        "type": "flex",
        "altText": "顯示更多資料",
        "contents": {
          "type": "bubble",
          "body": {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "點選顯示更多資料",
                "size": "lg",
                "align": "center",
                "weight": "bold"
              }
            ],
            "action": {
              "type": "postback",
              "label": "點選顯示更多資料",
              // "data": "showMorehttps://www.youtube.com/borispcp" + initialSearch + searchContent + "https://www.youtube.com/borispcp" + stopPoint
              "data": "showMore" + initialSearch + searchContent + stopPoint//改
            }
          }
        }
      }
    );
  }
  return replyMessage;
}

//移除陣列中重複的元素
function uniqueArrayElement(arrayData) {
  var result = arrayData.filter(function(element, index, arr){
    return arr.indexOf(element) === index;
  });
  return result;
}

//回送 Line Bot 訊息給使用者
function sendReplyMessage(CHANNEL_ACCESS_TOKEN, replyToken, replyMessage) {
  var url = "https://api.line.me/v2/bot/message/reply";
  UrlFetchApp.fetch(url, {
    "headers": {
      "Content-Type": "application/json; charset=UTF-8",
      "Authorization": "Bearer " + CHANNEL_ACCESS_TOKEN,
    },
    "method": "post",
    "payload": JSON.stringify({
      "replyToken": replyToken,
      "messages": replyMessage,
    }),
  });
}




//這個函式主要是為了避免 SpreadsheetApp.openById(spreadSheetId) 放在全域變數時 onOpen 函式會因沒有權限而執行失敗
function getDatabase() {
  spreadSheet = SpreadsheetApp.openById(spreadSheetId);
}

//當「時間資料欄位」的資料有變化時，「時間資料欄位顯示格式」要跟著變化
function onEdit(e){
  var editCell = e.range;
  if (e.source.getActiveSheet().getSheetName() != "參數設定") {return;}
  if (editCell.rowStart == 8 && editCell.columnStart > 1) {
    var sheetData = sheetConfig.getSheetValues(8, 1, 2, editCell.columnEnd);
    for (var i = editCell.columnStart; i <= editCell.columnEnd; i++ ) {
      if (sheetData[0][i - 1] != "" & sheetData[1][i - 1] == "") {
        sheetConfig.getRange(9, i).setDataValidation(SpreadsheetApp.newDataValidation().setAllowInvalid(false).requireValueInList(["顯示日期及時間", "顯示日期", "顯示時間"], true).build()).setValue("顯示日期及時間");
      }
      if (sheetData[0][i - 1] == "") {
        sheetConfig.getRange(9, i).clearDataValidations().clearContent();
      }
    }
  }
}

function onOpen() {
  var ui = SpreadsheetApp.getUi();
  ui.createMenu('機器人搜尋試算表專用選單')
      .addItem('取得圖片檔案 ID', 'getImageFileData')
      .addToUi();
}