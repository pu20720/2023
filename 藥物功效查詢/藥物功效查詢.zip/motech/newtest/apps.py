from django.apps import AppConfig


class NewtestConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'newtest'
