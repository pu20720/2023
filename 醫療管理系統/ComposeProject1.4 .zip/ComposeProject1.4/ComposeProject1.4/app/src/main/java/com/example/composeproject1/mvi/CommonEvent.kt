package com.example.composeproject1.mvi

open class CommonEvent : IEvent
