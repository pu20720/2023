package com.example.composeproject1.bean

data class UserInfo (
    val userName:String,
    val userId:Long
)