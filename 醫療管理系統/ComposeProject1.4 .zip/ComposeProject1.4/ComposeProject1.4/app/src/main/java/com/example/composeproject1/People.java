package com.example.composeproject1;

public class People {
     String tall,weight,BMI;


     public People(String t_,String w_,String b_) {

         tall = t_;
         weight = w_;
         BMI = b_;
     }
}
