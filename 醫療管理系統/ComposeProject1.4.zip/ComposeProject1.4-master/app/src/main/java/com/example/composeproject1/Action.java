package com.example.composeproject1;

public class Action {
    public final static String EDIT = "EDIT";
    public final static String NEW = "NEW";
    public final static String DELETE = "DELETE";
    public final static String CANCEL = "CANCEL";
}
