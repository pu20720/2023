package com.example.composeproject1.mvi

interface IEvent {
}
interface IEffect
