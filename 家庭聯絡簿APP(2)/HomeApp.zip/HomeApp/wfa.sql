-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- 主機: localhost
-- 建立日期: Jul 18, 2017, 01:09 PM
-- 伺服器版本: 5.0.51
-- PHP 版本: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- 資料庫: `wfa`
-- 

-- --------------------------------------------------------

-- 
-- 資料表格式： `aboutarticle`
-- 


-- 
-- 列出以下資料庫的數據： `aboutarticle`
-- 

-- --------------------------------------------------------

-- 
-- 資料表格式： `article`
-- 

CREATE TABLE `article` (
  `id` bigint(100) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `content` varchar(100) NOT NULL,
  `pic` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `pnum` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  `rdate` varchar(100) NOT NULL,
  `area` varchar(100) NOT NULL default 'none',
  `isread` varchar(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

CREATE TABLE `article2` (
  `id` bigint(100) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `content` varchar(100) NOT NULL,
  `pic` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `pnum` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  `rdate` varchar(100) NOT NULL,
  `area` varchar(100) NOT NULL default 'none',
  `isread` varchar(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

CREATE TABLE `article3` (
  `id` bigint(100) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL,
  `content` varchar(100) NOT NULL,
  `pic` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `pnum` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  `rdate` varchar(100) NOT NULL,
  `area` varchar(100) NOT NULL default 'none',
  `isread` varchar(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- 
-- 列出以下資料庫的數據： `article`
-- 


-- --------------------------------------------------------

-- 
-- 資料表格式： `attend`
-- 

CREATE TABLE `attend` (
  `id` bigint(100) NOT NULL auto_increment,
  `article_id` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  `rdate` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;


-- 
-- 列出以下資料庫的數據： `attend`
-- 

INSERT INTO `attend` VALUES (8, '5', '352636077505852', '2017-06-18 17:09:55');
INSERT INTO `attend` VALUES (9, '5', '354153066729376', '2017-06-18 17:10:33');

-- --------------------------------------------------------

-- 
-- 資料表格式： `discuss`
-- 

CREATE TABLE `discuss` (
  `id` bigint(100) NOT NULL auto_increment,
  `aid` varchar(100) NOT NULL,
  `content` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  `rdate` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=83 ;

-- 
-- 列出以下資料庫的數據： `discuss`
-- 

-- --------------------------------------------------------

-- 
-- 資料表格式： `flist`
-- 

CREATE TABLE `flist` (
  `id` bigint(100) NOT NULL auto_increment,
  `user` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `rdate` varchar(100) NOT NULL,
  `mygroup` varchar(100) NOT NULL,
  `vstatus` varchar(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- 
-- 列出以下資料庫的數據： `flist`
-- 
-- --------------------------------------------------------

-- 
-- 資料表格式： `list`
-- 

CREATE TABLE `list` (
  `id` bigint(100) NOT NULL auto_increment,
  `user` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `rdate` varchar(100) NOT NULL,
  `mygroup` varchar(100) NOT NULL,
  `vstatus` varchar(100) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

-- 
-- 列出以下資料庫的數據： `list`
-- 

INSERT INTO `list` VALUES (31, 'chuuser', '1', '1', '0', '0');
INSERT INTO `list` VALUES (39, 'chuusers', '1', '1', '0', '0');
INSERT INTO `list` VALUES (38, 'handsomeboy', '1', '1', '0', '0');

-- --------------------------------------------------------

-- 
-- 資料表格式： `main_chatroom`
-- 

CREATE TABLE `main_chatroom` (
  `id` bigint(100) NOT NULL auto_increment,
  `user` varchar(100) NOT NULL,
  `touser` varchar(100) NOT NULL,
  `content` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `rdate` varchar(100) NOT NULL,
  `mygroup` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

-- 
-- 列出以下資料庫的數據： `main_chatroom`
-- 


-- --------------------------------------------------------

-- 
-- 資料表格式： `onetoone`
-- 

CREATE TABLE `onetoone` (
  `id` bigint(100) NOT NULL auto_increment,
  `user` varchar(100) NOT NULL,
  `touser` varchar(100) NOT NULL,
  `content` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `rdate` varchar(100) NOT NULL,
  `isread` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

-- 
-- 列出以下資料庫的數據： `onetoone`
-- 

-- --------------------------------------------------------

-- 
-- 資料表格式： `userdata`
-- 

CREATE TABLE `member_table` (
  `id` bigint(100) NOT NULL auto_increment,
  `username` varchar(100) NOT NULL,
  `pwd` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

