package andbas.Ch11TabHost2;

import java.io.ByteArrayOutputStream;


import java.io.IOException;
import java.io.InputStream;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Timer;
import java.util.TimerTask;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import com.xml.LStruct;
import com.xml.ListHandler;
import com.xml.LoginXMLStruct;
import com.xml.MYStruct;
import com.xml.MessageHandler2;
import com.xml.MessageStruct;
import com.xml.MessageStruct2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.provider.MediaStore.Images.Media;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class MainTalk extends Activity {

	String picfilename;
	public int mode;

	private static final int MSG_UPDATE = 1;
	private static final int MSG_TALK = 2;
	public static MainTalk my;

	private ArrayList<MessageStruct2> ms;

	String TAG = "MainTalk";
	String IPAddress;

	String myname;

	MYStruct rep;

	TextView tname;
	EditText name;
	
	String groupname[];

	ListView onlinelist;
	private ArrayList<LStruct> onlinelists;
	private ArrayList<HashMap<String, Object>> mrlist;

	private Timer timer;
	int gindex;
	
	String user;
	
	LoginXMLStruct data;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.maintalk);

		IPAddress = (String) this.getResources().getText(R.string.url);

		Resources res = getResources();
		//groupname = res.getStringArray(R.array.groupname1);		
		Bundle bData = this.getIntent().getExtras();
		
		if (bData != null)
		{
			user = bData.getString( "user" );
		}
	        
		// get online
		onlinelist = (ListView) findViewById(R.id.listview1);
		onlinelists = new ArrayList<LStruct>();
		mrlist = new ArrayList<HashMap<String, Object>>();

		timer = new Timer();

		reload();

		onlinelist.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> a, View v, int position,
					long id) {
				if (onlinelists.get(position).name.equals(user)) {
					openOptionsDialog("����[�J�ۤv");
					return;
				}

				toweb(IPAddress + "addfriend.php?user=" + user +  "&status=" + onlinelists.get(position).name);
				
				Toast.makeText(MainTalk.this, "�[�J�B�ͦ��\", Toast.LENGTH_LONG).show();
				
				finish();

			}
		});

		//timer.schedule(new DateTask(), 500, 10000);
	}


	public int toweb(String uriAPI) {
		int error = 0;
		HttpGet httpRequest = new HttpGet(uriAPI);

		try {
			HttpResponse httpResponse = new DefaultHttpClient()
					.execute(httpRequest);
			if (httpResponse.getStatusLine().getStatusCode() == 200) {
				String strResult = EntityUtils.toString(httpResponse
						.getEntity());
			} else {
				// mTextView1.setText("Error Response: "+httpResponse.getStatusLine().toString());
			}
		} catch (ClientProtocolException e) {
			// mTextView1.setText(e.getMessage().toString());
			e.printStackTrace();
			error = 1;
		} catch (IOException e) {
			// mTextView1.setText(e.getMessage().toString());
			e.printStackTrace();
			error = 1;
		} catch (Exception e) {
			// mTextView1.setText(e.getMessage().toString());
			e.printStackTrace();
			error = 1;
		}

		return error;
	}

	void reload() {
		// read all data
		String uriAPI = IPAddress + "getlist.php";

		URL url = null;
		try {
			url = new URL(uriAPI);

			SAXParserFactory spf = SAXParserFactory.newInstance();
			SAXParser sp = spf.newSAXParser();
			XMLReader xr = sp.getXMLReader();
			ListHandler myHandler = new ListHandler();
			xr.setContentHandler(myHandler);
			// open connection
			xr.parse(new InputSource(url.openStream()));
			onlinelists = myHandler.getContainer().getListItems();
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}

		if (onlinelists != null) {
			updatedata();
		}
	}

	public void updatedata() {
		// put in
		Message msg = new Message();
		msg.what = MSG_UPDATE;
		myHandler.sendMessage(msg);
	}

	public Handler myHandler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case MSG_UPDATE:
				
				ArrayList<HashMap<String, Object>> listitem = new ArrayList<HashMap<String,Object>>();
				 for (int i=0; i<onlinelists.size(); i++)
		         {
		           HashMap<String, Object> map = new HashMap<String, Object>();
		           map.put("ItemTitle", onlinelists.get(i).name);
		           map.put("ItemText", onlinelists.get(i).rdate);

		           listitem.add(map);           
		         }
				 
				 SimpleAdapter listitemAdapter=new SimpleAdapter(MainTalk.this,
						 	listitem,
				            R.layout.no_listview_style,
				            new String[]{"ItemTitle","ItemText"},
				            new int[]{R.id.topTextView, R.id.bottomTextView});

				 onlinelist.setAdapter(listitemAdapter);

				break;
			case MSG_TALK:
				if (ms.size() > 0) {
					if (timer != null)
						timer.cancel();
						openGotoOptionsDialog(ms.get(0).user + " ��z��ܭC");
				}
				break;
			}
		}
	};

	// ���W�����ɭ�
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			toweb(IPAddress + "logout.php?user=" + user);

			if (timer != null)
				timer.cancel();

			finish();
			return true;
		}

		return super.onKeyDown(keyCode, event);
	}

	public class DateTask extends TimerTask {
		public void run() {
			reload();

			// check msg
			try {

				String uriAPI = IPAddress + "getaskusertalk.php?touser=" + user;

				Log.i("TAG", uriAPI);

				URL url = null;
				try {
					url = new URL(uriAPI);

					SAXParserFactory spf = SAXParserFactory.newInstance();
					SAXParser sp = spf.newSAXParser();
					XMLReader xr = sp.getXMLReader();
					MessageHandler2 myHandler = new MessageHandler2();
					xr.setContentHandler(myHandler);
					// open connection
					xr.parse(new InputSource(url.openStream()));
					ms = myHandler.getContainer().getListItems();
				} catch (Exception e) {
					e.printStackTrace();
					return;
				}

				if (ms != null) {

					Message msg = new Message();
					msg.what = MSG_TALK;
					myHandler.sendMessage(msg);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

	public void openOptionsDialog(String info) {
		new AlertDialog.Builder(this).setTitle("message").setMessage(info)
				.setPositiveButton("OK", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialoginterface, int i) {

					}
				}).show();
	}

	public void openGotoOptionsDialog(String info) {
		new AlertDialog.Builder(this)
				.setTitle("message")
				.setMessage(info)
				.setPositiveButton("���D�F",
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialoginterface, int c) {
							}
						}).show();
	}
}