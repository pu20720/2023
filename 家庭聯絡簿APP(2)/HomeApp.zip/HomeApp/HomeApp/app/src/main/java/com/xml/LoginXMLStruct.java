package com.xml;

public class LoginXMLStruct 
{
	  public String h_chilid;	  
}