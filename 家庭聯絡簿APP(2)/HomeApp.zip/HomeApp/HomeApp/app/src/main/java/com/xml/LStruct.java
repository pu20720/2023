package com.xml;


public class LStruct 
{
	
  public String id;
  public String name;
  public String status;
  public String rdate;
  public String group;

 
}