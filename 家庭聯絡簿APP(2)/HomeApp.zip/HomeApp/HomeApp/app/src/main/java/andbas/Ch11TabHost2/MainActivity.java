package andbas.Ch11TabHost2;

import java.io.IOException;
import java.net.URL;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import com.xml.LoginXMLHandler;
import com.xml.LoginXMLStruct;
import com.xml.MessageHandler;
import com.xml.MessageStruct;
import com.xml.UserdataHandler;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TabActivity;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SimpleAdapter;
import android.widget.TabHost;
import android.widget.Toast;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;
import android.app.Activity;


public class MainActivity extends Activity {
    /** Called when the activity is first created. */
	
	private static final int MSG_UPDATE = 1;
	private static final int MSG_GCM_UPDATE = 2;
	
	public TextView Title;
	
	public LocationManager locationManager1;
	public Location location1 = null;
	public String locationProvider1;
	
	String IPAddress;
	
	LoginXMLStruct data;
	
	String id;
	String user;
	
	EditText s1;
	EditText s2;
	
	private ArrayList<MessageStruct> ms;
	
	private Timer timer;

	private GridView gridView;

	//一般會員
	private String[] imgText=new String[]{"家庭任務","家庭聯絡人","收支","行事曆",
			"新增家庭任務","新增收支","新增行事曆",
			"群組功能","私信子系統"};

	private int[] image = {
			R.drawable.mm1, R.drawable.mm2, R.drawable.mm3, R.drawable.mm4,
			R.drawable.mm5, R.drawable.mm6, R.drawable.mm7, R.drawable.mm8,
			R.drawable.mm1
	};


	int type;

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.main);

		IPAddress = (String) this.getResources().getText(R.string.url);
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy); 
		Bundle rdata = getIntent().getExtras();

   	    user = rdata.getString("user");
		type = Integer.valueOf(rdata.getString("type"));
		buildViews();
    }
	
	private void buildViews() {

		List<Map<String, Object>> items = new ArrayList<>();
		for (int i = 0; i < image.length; i++) {
			Map<String, Object> item = new HashMap<>();
			item.put("image", image[i]);
			item.put("text", imgText[i]);
			items.add(item);
		}
		SimpleAdapter adapter = new SimpleAdapter(this,
				items, R.layout.grid_item, new String[]{"image", "text"},
				new int[]{R.id.image, R.id.text});
		gridView = (GridView)findViewById(R.id.main_page_gridview);
		gridView.setNumColumns(2);
		gridView.setAdapter(adapter);
		gridView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

				if (position == 0)
				{
					Intent app = new Intent(MainActivity.this, Dynamic.class);
					Bundle rdata = new Bundle();
					rdata.putString("user", user);
					app.putExtras(rdata);
					startActivity(app);
				}
				else if (position == 1)
				{
					Intent app = new Intent(MainActivity.this, Action.class);
					Bundle rdata = new Bundle();
					rdata.putString("user", user);
					app.putExtras(rdata);
					startActivity(app);
				}
				else if (position == 2)
				{
					Intent app = new Intent(MainActivity.this, Dynamic2.class);
					Bundle rdata = new Bundle();
					rdata.putString("user", user);
					app.putExtras(rdata);
					startActivity(app);
				}
				else if (position == 3)
				{
					Intent app = new Intent(MainActivity.this, Dynamic3.class);
					Bundle rdata = new Bundle();
					rdata.putString("user", user);
					app.putExtras(rdata);
					startActivity(app);
				}
				else if (position == 4)
				{
					Intent app = new Intent(MainActivity.this, Content.class);
					Bundle rdata = new Bundle();
					rdata.putString("user", user);
					app.putExtras(rdata);
					startActivity(app);
				}
				else if (position == 5)
				{
					Intent app = new Intent(MainActivity.this, Content2.class);
					Bundle rdata = new Bundle();
					rdata.putString("user", user);
					app.putExtras(rdata);
					startActivity(app);
				}
				else if (position == 6)
				{
					Intent app = new Intent(MainActivity.this, Content3.class);
					Bundle rdata = new Bundle();
					rdata.putString("user", user);
					app.putExtras(rdata);
					startActivity(app);
				}
				else if (position == 7)
				{
					Intent app = new Intent(MainActivity.this, MainFriend.class);
					Bundle rdata = new Bundle();
					rdata.putString("user", user);
					app.putExtras(rdata);
					startActivity(app);
				}
				else if (position == 8)
				{
					Intent app = new Intent(MainActivity.this, ChatRoom.class);
					Bundle rdata = new Bundle();
					rdata.putString("user", user);
					app.putExtras(rdata);
					startActivity(app);
				}


			}
		});

	}

	public Handler myHandler = new Handler(){
	    public void handleMessage(Message msg) {
	        switch(msg.what)
	        {
	          case MSG_UPDATE:
	        	  break;
	          case MSG_GCM_UPDATE:
	        	  break;
	        }
	    }
	};


}