package andbas.Ch11TabHost2;


import java.net.URL;


import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.xml.MYLHandler;
import com.xml.MYStruct;

public class MYTSRegister extends Activity 
{
	Button myregister;
	EditText account;
	EditText mypwd;
	TextView loginErrorMsg;
	
	public static String IPAddress;
	
	public static MYTSRegister rent;

	String saccount, spwd;
	
	EditText addr, id, sex, phone, mail;
	
	static String thisaccount;
	static String groupid;
	
	MYStruct group;

	Spinner spinner;
	Spinner spinner2;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.myregister);

		rent = this;

		Resources res = getResources();
		
		IPAddress = (String) res.getText(R.string.url);
		if (android.os.Build.VERSION.SDK_INT > 9) {
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}

		myregister = (Button) findViewById(R.id.mregister);

		//addr, id, sex, phone, mail
		account = (EditText) findViewById(R.id.account);
		mypwd = (EditText) findViewById(R.id.mypwd);

		spinner2 = (Spinner) findViewById(R.id.myid);
		ArrayAdapter<CharSequence> nAdapter2 = ArrayAdapter.createFromResource(
				this, R.array.myid, android.R.layout.simple_spinner_item );
		nAdapter2.setDropDownViewResource(
				android.R.layout.simple_spinner_dropdown_item);
		spinner2.setAdapter(nAdapter2);
		
		//check login
        myregister.setOnClickListener(new View.OnClickListener() {

			public void onClick(View view) {
				String str = IPAddress + "" +
						"/mregister.php?myaccount=" + account.getText().toString() + "&mypwd=" + mypwd.getText().toString() + "&myid=" + spinner2.getSelectedItemPosition();

				Log.i("TAG", str);

				URL url = null;
				try {
					url = new URL(str);

					SAXParserFactory spf = SAXParserFactory.newInstance();
					SAXParser sp = spf.newSAXParser();
					XMLReader xr = sp.getXMLReader();
					//Using login handler for xml
					MYLHandler myHandler = new MYLHandler();
					xr.setContentHandler(myHandler);
					//open connection
					xr.parse(new InputSource(url.openStream()));
					//verify OK
					group = myHandler.getParsedData();
				} catch (Exception e) {
					e.printStackTrace();
					return;
				}

	            finally {
					if (!group.h_chilid.equals("-1")) {
						Toast.makeText(view.getContext(), "註冊成功", Toast.LENGTH_LONG).show();
						finish();
					}
					else
					{
						Toast.makeText(view.getContext(), "註冊失敗", Toast.LENGTH_LONG).show();
						finish();
					}
				}

			}
		});
	}
}
