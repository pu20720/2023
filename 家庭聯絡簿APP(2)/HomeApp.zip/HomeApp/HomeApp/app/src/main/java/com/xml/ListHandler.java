package com.xml;


import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import android.util.Log;

public class ListHandler extends DefaultHandler
{
	//tag
	private String TAG = "RentListHandler";
	
	private final static int ID = 1;
	private final static int NAME = 2;
	private final static int STATUS = 3;
	private final static int RDATE = 4;
	private final static int GROUP = 5;

	private LStruct jls;
	private ListContainer jlcs;
	
	private int type;

	public ListContainer getContainer() 
	{
		return jlcs;
	}


	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		
		String s = new String(ch, start, length);
		
		switch (type) 
		{
		case ID:
			jls.id = s;
			type = 0;
			break;
		case NAME:
			jls.name = s;
			type = 0;
			break;
		case STATUS:
			jls.status = s;
			type = 0;
			break;
		case RDATE:
			jls.rdate = s;
			type = 0;
			break;
		case GROUP:
			jls.group = s;
			type = 0;
			break;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {

		if (localName.toLowerCase().equals("item")) 
		{
			jlcs.addRXMLItem(jls);	
		}
	}

	@Override
	public void startDocument() throws SAXException 
	{
		jlcs = new ListContainer();
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException 
	{
		if (localName.toLowerCase().equals("item")) 
		{
			jls = new LStruct();
			return;
		}
		else if (localName.toLowerCase().equals("id")) 
		{
			type = ID;
			return;
		}
		else if (localName.toLowerCase().equals("name")) 
		{
			type = NAME;
			return;
		}
		else if (localName.toLowerCase().equals("status")) 
		{
			type = STATUS;
			return;
		}
		else if (localName.toLowerCase().equals("rdate")) 
		{
			type = RDATE;
			return;
		}		
		else if (localName.toLowerCase().equals("group")) 
		{
			type = GROUP;
			return;
		}		
		type = 0;
	}

}