package andbas.Ch11TabHost2;


import java.io.ByteArrayOutputStream;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;

import java.net.URLEncoder;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.Timer;
import java.util.TimerTask;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import com.xml.MYLHandler;
import com.xml.MYStruct;
import com.xml.MessageHandler2;
import com.xml.MessageStruct2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.provider.MediaStore.Images.Media;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SimpleAdapter;
import android.widget.SimpleAdapter.ViewBinder;
import android.widget.TextView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;


public class ChatRoom extends Activity {

	private static final int MSG_UPDATE = 1;  
	private static final int MSG_FILE_IN = 2;  
	private static final int MSG_FILE_SHOW = 3;  
	
	public int mode;

	public static ChatRoom my;
	
	String TAG = "MainTalk";	
    String IPAddress;
    
    String myname;
    
    MYStruct rep;
    
    TextView tname;
    EditText name;
    
    TextView sp;
    
    String touser;
    
    ArrayList<String> filelist;
    
    TextView textView1;
    
    ListView onlinelist;
    //private ArrayList<OnlineStruct> onlinelists;
    private ArrayList<MessageStruct2> ms;
    private ArrayList<HashMap<String, Object>> mrlist;
    
    private Timer timer;
    
    String picfilename;
    
    String message="";
    
    String id;

	public void onCreate(Bundle savedInstanceState) 
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.onechatroom);

        sp =  (TextView) findViewById(R.id.edit_msg);
        
        textView1  =  (TextView) findViewById(R.id.textView1);
        
        IPAddress = (String) this.getResources().getText(R.string.url);
        
        //get online
        onlinelist = (ListView) findViewById(R.id.lv);
       
        mrlist = new ArrayList<HashMap<String, Object>>();
        ms = new  ArrayList<MessageStruct2>();
        
        Bundle rdata = this.getIntent().getExtras();
        
        touser = rdata.getString("touser");
        
        id = rdata.getString("id");
        
        textView1.setText("�P" + touser + "���");
        
        timer = new Timer();
       
        Button btn_addtalk = (Button) findViewById(R.id.btn_addtalk);
        btn_addtalk.setOnClickListener(new View.OnClickListener() {

			public void onClick(View view) 
			{
				
				try {
					String content = URLEncoder.encode((sp.getText().toString()), "UTF-8");
					
					String uriAPI = IPAddress + "sendto.php?user=" + id + "&touser=" + touser + "&content=" + content + "&type=1";
			        
					senddata(sp.getText().toString());
					
					Log.i("TAG", uriAPI);
					
					
					
			        URL url = null;
			        try{
			          url = new URL(uriAPI);
			          
			          SAXParserFactory spf = SAXParserFactory.newInstance();
			          SAXParser sp = spf.newSAXParser();
			          XMLReader xr = sp.getXMLReader();
			          MYLHandler myHandler = new MYLHandler();
			          xr.setContentHandler(myHandler);
			          //open connection
			          xr.parse(new InputSource(url.openStream()));
			          rep = myHandler.getParsedData();
			        }
			        catch(Exception e){
			          e.printStackTrace();
			          return;
			        }
			        
			        if (ms != null)
			        {
			        	updatedata();
			        }
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
        
        timer.schedule(new DateTask(), 0, 5000);  

	}
	
	  public class DateTask extends TimerTask {
		    public void run() 
		    {
		    	reload(); 
		    }
	}
	  
	  public boolean onCreateOptionsMenu(Menu menu)
	  {

	    super.onCreateOptionsMenu(menu);
	    
	    //�[�Jmenu���
	    menu.add(0 , 0, 0 ,"�ǰe�ɮ׵��o�ӨϥΪ�");
	  
	    return true;  
	  }

	  @Override
	  public boolean onOptionsItemSelected(MenuItem item)
	  {
	    Intent intent = new Intent() ;
	    
	    switch (item.getItemId())
	    { 
	          case 0:
	        	Intent photoPickerIntent = new Intent(Intent.ACTION_GET_CONTENT);
	          	photoPickerIntent.setType("image/*");
	          	startActivityForResult(photoPickerIntent, 1);
	            break;
	    }
	    
	    return true;
	}
	  
	public static String getRealPathFromUri(Activity activity, Uri contentUri) {
		    String[] proj = { Media.DATA };
		    Cursor cursor = activity.managedQuery(contentUri, proj, null, null, null);
		    int column_index = cursor.getColumnIndexOrThrow(Media.DATA);
		    cursor.moveToFirst();
		    return cursor.getString(column_index);
	}


	  
	public boolean onKeyDown(int keyCode, KeyEvent event) 
	    {
	    	if(keyCode==KeyEvent.KEYCODE_BACK)
	    	{  
	    		if (timer != null)
	    			timer.cancel();
	    		
	    		Intent ask = new Intent(ChatRoom.this, MainTalk.class);
	    		startActivity(ask);
	    		
	    		finish();
	    		
	    		return true;
	    	}
			
			return super.onKeyDown(keyCode, event);  
	}
	
	  public void upload(byte [] ba)
	  {
		  String ba1 = Base64.encodeBytes(ba);
		  ArrayList<NameValuePair> nameValuePairs = new  ArrayList<NameValuePair>();

		  nameValuePairs.add(new BasicNameValuePair("image",ba1));
		  nameValuePairs.add(new BasicNameValuePair("filename",picfilename));
		  
		  Log.i(TAG, picfilename);

		  try{
				  HttpClient httpclient = new DefaultHttpClient();

				  String url = IPAddress + "upload.php";
				  Log.i("TAG", url);
				  HttpPost httppost = new HttpPost(url);
				  httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			
				  HttpResponse response = httpclient.execute(httppost);

			    /* http response 200 = ok */
			    Log.v(TAG, "http response status: "+response.getStatusLine().getStatusCode());
			    if (response.getStatusLine().getStatusCode() == 200) {
		
			    /* get data from server url */
			    String strResult = EntityUtils.toString(response.getEntity());
			    Log.d(TAG, "get Result:"+strResult);
		    } else {
		     //tools.showInfo("upload file error: "+httpResponse.getStatusLine().getStatusCode());
		    }

		  }catch(Exception e){
			  Log.e("log_tag", "Error in http connection "+e.toString());
	      }

	  }
	
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
	    super.onActivityResult(requestCode, resultCode, data);
	    
	    if (resultCode == RESULT_OK)
	    {
	        Uri chosenImageUri = data.getData();

	        Bitmap mBitmap = null;
	        try {
				picfilename = getRealPathFromUri( (Activity) ChatRoom.this, chosenImageUri);
				
				StringTokenizer Tok = new StringTokenizer(picfilename, "/");
		        int n=0;

		        while (Tok.hasMoreElements())
		        {
		        	picfilename = (String) Tok.nextElement();
		        }
		        //uploader.setText("fp:"+picfilename);
				mBitmap = Media.getBitmap(this.getContentResolver(), chosenImageUri);
				
				ByteArrayOutputStream baos = new ByteArrayOutputStream();    
				mBitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);
				
				upload(baos.toByteArray());
				
				
				//insert
				try {
					String uriAPI = IPAddress + "sendto.php?user=" + id + "&touser=" + touser + "&content=" + picfilename + "&type=2";
			        
					
					senddata("�ǰe�ɮ� "+ sp.getText().toString() + "��" + touser);
					Log.i("TAG", uriAPI);
					
			        URL url = null;
			        try{
			          url = new URL(uriAPI);
			          
			          SAXParserFactory spf = SAXParserFactory.newInstance();
			          SAXParser sp = spf.newSAXParser();
			          XMLReader xr = sp.getXMLReader();
			          MYLHandler myHandler = new MYLHandler();
			          xr.setContentHandler(myHandler);
			          //open connection
			          xr.parse(new InputSource(url.openStream()));
			          rep = myHandler.getParsedData();
			        }
			        catch(Exception e){
			          e.printStackTrace();
			          return;
			        }				

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        }
	        catch (Exception e)
	        {
	        	e.printStackTrace();
	        }
	    }
	}
	
	void reload()
	{
		try {
			
			String uriAPI = IPAddress + "getusertalk.php?touser=" + id;
			
			Log.i("TAG", uriAPI);
	        
	        URL url = null;
	        try{
	          url = new URL(uriAPI);
	          
	          SAXParserFactory spf = SAXParserFactory.newInstance();
	          SAXParser sp = spf.newSAXParser();
	          XMLReader xr = sp.getXMLReader();
	          MessageHandler2 myHandler = new MessageHandler2();
	          xr.setContentHandler(myHandler);
	          //open connection
	          xr.parse(new InputSource(url.openStream()));
	          ms = myHandler.getContainer().getListItems();
	        }
	        catch(Exception e){
	          e.printStackTrace();
	          return;
	        }
	        
	        if (ms != null)
	        {
	        	updatedata();
	        }
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}		
	}
	
	public void senddata(String content) 
	{
		HashMap<String, Object> map = new HashMap<String, Object>();

		Bitmap myBitmap = getexp(content);
		
		map.put("title",id + "(me): " + content);
		
		Date now = new Date(); // the current time
	    SimpleDateFormat sdf = new SimpleDateFormat();
	    sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
		map.put("info", sdf.format(now));
		mrlist.add(map);      
	}
	
	public void updatedata() 
	{
		HashMap<String, Object> map;
		  
	    //mrlist.clear();
		filelist = new ArrayList<String>();
	    for (int i=0; i<ms.size(); i++)
	    {
	    	if (ms.get(i).type.equals("1"))
	    	{
		      map = new HashMap<String, Object>();
		      
			  Bitmap myBitmap = getexp(ms.get(i).content);
				
			  if (myBitmap != null)
			  {
			      map.put("img", myBitmap);
			      map.put("title", " - " + id + "(me)");
			  }
			  else
			  {
				  map.put("title",ms.get(i).user + ": " +  ms.get(i).content);  
			  }
		      
		      map.put("info", ms.get(i).rdate);
		      mrlist.add(map);      
	    	}
	    	else
	    	{
	    		filelist.add(ms.get(i).content);
	    	}
	    }
	    
	    if (mrlist.size() !=0)
	    {
		    Message msg = new Message();
		    msg.what = MSG_UPDATE;
		    myHandler.sendMessage(msg);   
	    }
	    
	    if (filelist.size() !=0)
	    {
	    	for (int i = 0; i<ms.size(); i++)
        	{
        		if (ms.get(i).type.equals("2"))
        		{
        			message += ms.get(i).user + " ���ɮ� " + ms.get(i).content + "�O�_�n����? \n";
        		}        		
        	}
	    	
	    	Message msg = new Message();
		    msg.what = MSG_FILE_SHOW;
		    myHandler.sendMessage(msg);   
	    }
	    
	  }
	
	 public Bitmap getexp(String content)
	 {
			Bitmap myBitmap = null;
		 
			String str = "";
			
			if (content.equals(":)"))
			{
				str = IPAddress + "images/icon1.gif";
			}
			else if (content.equals(":("))
			{
				str = IPAddress + "images/icon12.gif";
			}
		
			
			Log.i("TAG", str);

			try {
				URL url = new URL(str);
			    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			    connection.setDoInput(true);
			    connection.connect();
				InputStream input = connection.getInputStream();
				BitmapFactory.Options opts = new BitmapFactory.Options();
				        
				opts.inSampleSize = 4;

				myBitmap = BitmapFactory.decodeStream(input, null, opts);
						
			} catch (Exception e) {
				e.printStackTrace();
				        
			}
		 
			return myBitmap;
		 
	 }

	
	  public Handler myHandler = new Handler(){
		    public void handleMessage(Message msg) {
		        switch(msg.what)
		        {
		          case MSG_UPDATE:
		        	//put in
		      	    //SimpleAdapter m = new SimpleAdapter(ChatRoom.this,
		      	      //        mrlist,
		      	        //      R.layout.mlistview,
		      	          //    new String[] {"ItemTitle", "ItemText"}, 
		      	            //  new int[] {R.id.ItemTitle,R.id.ItemText});
		        	  
		        	SimpleAdapter adapter = new SimpleAdapter(ChatRoom.this,mrlist,R.layout.plist,
		      				new String[]{"title","info","img"},
		      				new int[]{R.id.title,R.id.info,R.id.img});

		    		adapter.setViewBinder(new ViewBinder(){  
		  			  
		    	        public boolean setViewValue(View view, Object data,  
		    	                String textRepresentation) {  
		    	            if( (view instanceof ImageView) & (data instanceof Bitmap) ) {  
		    	                ImageView iv = (ImageView) view;  
		    	                Bitmap bm = (Bitmap) data;  
		    	                iv.setImageBitmap(bm);  
		    	               
		    	                return true;  
		    	                }  
		    	            
		    	            
		    	           
		    	                return false;  
		    	  
		    	        }  
		    	        
		    	      
		    	             
		    	       });  

		      	    onlinelist.setAdapter(adapter);
		      	    adapter.notifyDataSetChanged();
		            break;
		          case MSG_FILE_IN:
		        	for (int i = 0; i<ms.size(); i++)
		        	{
		        		if (ms.get(i).type.equals("2"))
		        		{
	        				ShowDetil(ms.get(i).content);
		        		}
		        	}
		        	  
		        	break;
		          case MSG_FILE_SHOW:
		        	  openFileOptionsDialog(message);
		        	break;
		        }
		    }
	  };
	  
	  public void openOptionsDialog(String info)
	  {
	    new AlertDialog.Builder(this)
	    .setTitle("message")
	    .setMessage(info)
	    .setPositiveButton("OK",
	        new DialogInterface.OnClickListener()
	        {
	         public void onClick(DialogInterface dialoginterface, int i)
	         {
	     
	         }
	         }
	        )
	    .show();
	  } 
	  
	 public void openFileOptionsDialog(String info)
	  {
	    new AlertDialog.Builder(this)
	    .setTitle("message")
	    .setMessage(info)
	    .setPositiveButton("OK",
	        new DialogInterface.OnClickListener()
	        {
	         public void onClick(DialogInterface dialoginterface, int i)
	         {
	        	Message msg = new Message();
	 		    msg.what = MSG_FILE_IN;
	 		    myHandler.sendMessage(msg);   
	         }
	         }
	        )
	    .show();
	  }
	 
		private void ShowDetil(String pic)
		{
			String picpath = IPAddress + "/upload/" + pic;
			
	        AlertDialog.Builder alert = new AlertDialog.Builder(this);

	        alert.setTitle("�Բ��ɮ�");
	        alert.setMessage(pic);
	        
	        ScrollView sv = new ScrollView(this);
	        LinearLayout ll = new LinearLayout(this);
	        ll.setOrientation(LinearLayout.VERTICAL);
	        sv.addView(ll);
	        
	        TextView sp = new TextView(this);
	        sp.setText(pic);
	        ImageView t1 = new ImageView(this);
	        
	        ll.addView(sp);
	        ll.addView(t1);

	        Bitmap myBitmap = null;
	        try {
	            URL url = new URL(picpath);
	            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	            connection.setDoInput(true);
	            connection.connect();
	            InputStream input = connection.getInputStream();
	            myBitmap = BitmapFactory.decodeStream(input);
	            
	        } catch (IOException e) {
	            e.printStackTrace();
	        }        
	       t1.setImageBitmap(myBitmap);

	        alert.setView(sv);
	        
	        alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
	            public void onClick(DialogInterface dialog, int whichButton) 
	            {
	            }
	        });
	      
	        alert.show();      
			
		}
		
		private InputStream OpenHttpConnection(String strURL) throws IOException{
			 InputStream inputStream = null;
			 URL url = new URL(strURL);
			 URLConnection conn = url.openConnection();

			 try{
			  HttpURLConnection httpConn = (HttpURLConnection)conn;
			  httpConn.setRequestMethod("GET");
			  httpConn.connect();

			  if (httpConn.getResponseCode() == HttpURLConnection.HTTP_OK) {
			   inputStream = httpConn.getInputStream();
			  }
			 }
			 catch (Exception ex)
			 {
			 }
			 return inputStream;
			}
			
		
		 private Bitmap LoadImage(String URL, BitmapFactory.Options options)
		   {       
		    Bitmap bitmap = null;
		    InputStream in = null;       
		       try {
		           in = OpenHttpConnection(URL);
		           bitmap = BitmapFactory.decodeStream(in, null, options);
		           in.close();
		       } catch (IOException e1) {
		       }
		       return bitmap;               
		   }

	
}