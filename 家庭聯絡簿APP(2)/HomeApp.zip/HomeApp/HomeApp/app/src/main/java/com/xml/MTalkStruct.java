package com.xml;


public class MTalkStruct 
{
	
  public String id;
  public String content;
  public String user;
  public String rdate;

  public MTalkStruct()
  {

  }
  
}