package com.xml;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.util.Log;

public class MessageContainer2
{

	private ArrayList<MessageStruct2> jlist_items;

	//item
	public ArrayList<MessageStruct2> getListItems() 
	{
	  return jlist_items;
	}
	
	public MessageStruct2 getoneJL(int index)
	{
		return jlist_items.get(index);
	}
	
	public MessageContainer2() 
	{
		jlist_items = new ArrayList<MessageStruct2>();
	}

	public void addRXMLItem(MessageStruct2 item) 
	{
		jlist_items.add(item);
	}
}
