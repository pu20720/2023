package com.xml;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.util.Log;

public class OnLineListContainer 
{

	private ArrayList<OnlineStruct> jlist_items;

	//item
	public ArrayList<OnlineStruct> getListItems() 
	{
	  return jlist_items;
	}
	
	public OnlineStruct getoneJL(int index)
	{
		return jlist_items.get(index);
	}
	
	public OnLineListContainer() 
	{
		jlist_items = new ArrayList<OnlineStruct>();
	}

	public void addRXMLItem(OnlineStruct item) 
	{
		jlist_items.add(item);
	}
}
