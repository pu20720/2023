package com.xml;


public class UserdataStruct 
{
	
	 public String id;
	 public String user;
	 public String lat;
	 public String lng;
}