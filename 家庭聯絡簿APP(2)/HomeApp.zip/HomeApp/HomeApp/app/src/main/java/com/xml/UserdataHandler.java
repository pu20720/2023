package com.xml;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import android.util.Log;

public class UserdataHandler extends DefaultHandler
{
	//tag
	private String TAG = "MessageHandler";
	
	private final static int ID = 1;
	private final static int USER = 2;
	private final static int LAT = 3;
	private final static int LNG = 4;

	private UserdataStruct jls;
	private UserdataContainer jlcs;
	
	private int type;

	public UserdataContainer getContainer() 
	{
		return jlcs;
	}

	public UserdataStruct getJListStruct() 
	{
		return jlcs.getoneJL(0);
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		
		String s = new String(ch, start, length);
		
		switch (type) 
		{
		case ID:
			jls.id = s;
			type = 0;
			break;
		case USER:
			jls.user = s;
			type = 0;
			break;
		case LAT:
			jls.lat = s;
			type = 0;
			break;
		case LNG:
			jls.lng = s;
			type = 0;
			break;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {

		if (localName.toLowerCase().equals("item")) 
		{
			jlcs.addRXMLItem(jls);	
		}
	}

	@Override
	public void startDocument() throws SAXException 
	{
		jlcs = new UserdataContainer();
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException 
	{
		if (localName.toLowerCase().equals("item")) 
		{
			jls = new UserdataStruct();
			return;
		}
		else if (localName.toLowerCase().equals("id")) 
		{
			type = ID;
			return;
		}
		else if (localName.toLowerCase().equals("user")) 
		{
			type = USER;
			return;
		}
		else if (localName.toLowerCase().equals("lat")) 
		{
			type = LAT;
			return;
		}		
		else if (localName.toLowerCase().equals("lng")) 
		{
			type = LNG;
			return;
		}		
		type = 0;
	}

}