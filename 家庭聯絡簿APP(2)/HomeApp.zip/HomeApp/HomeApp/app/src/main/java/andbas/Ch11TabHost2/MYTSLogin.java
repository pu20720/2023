package andbas.Ch11TabHost2;


import java.net.URL;


import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.xml.MYLHandler;
import com.xml.MYStruct;


public class MYTSLogin extends Activity 
{
	Button mylogin;
	Button myregister;
	Button abouts;
	EditText account;
	EditText mypwd;
	TextView loginErrorMsg;
	
	public static String IPAddress;
	
	public static MYTSLogin rent;

	String saccount, spwd, smail, sreg, sphone, sspwd;
	
	static String accountid;
	static String groupid;
	
	String myaccountid;

	MYStruct group;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.myts);

		rent = this;

		Resources res = getResources();
		IPAddress = (String) res.getText(R.string.url);
		if (android.os.Build.VERSION.SDK_INT > 9) {
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}

		account = (EditText) findViewById(R.id.account);
		mypwd = (EditText) findViewById(R.id.mypwd);

		mylogin = (Button) findViewById(R.id.mylogin);


		//check login
		mylogin.setOnClickListener(new View.OnClickListener() {

				public void onClick(View view)
				{

				if (account.getText().toString().equals("guest") && mypwd.getText().toString().equals("guest"))
				{
					Intent app = new Intent(MYTSLogin.this, MainActivity.class);
					Bundle ndata = new Bundle();
					ndata.putString("user", account.getText().toString());
					ndata.putString("myclass", "-1");
					app.putExtras(ndata);
					startActivity(app);

					return;
				}


				URL url = null;
				try{
					String str = IPAddress + "" +
							"/mlogin.php?myaccount=" + account.getText().toString() + "&mypwd=" +mypwd.getText().toString();

					Log.i("TAG", str);

					url = new URL(str);

					SAXParserFactory spf = SAXParserFactory.newInstance();
					SAXParser sp = spf.newSAXParser();
					XMLReader xr = sp.getXMLReader();
					//Using login handler for xml
					MYLHandler myHandler = new MYLHandler();
					xr.setContentHandler(myHandler);
					//open connection
					xr.parse(new InputSource(url.openStream()));
					//verify OK
					group = myHandler.getParsedData();
				}
				catch(Exception e){
					e.printStackTrace();
					return;
				}
				finally
				{
					if (group != null)
					{
						if (group.h_chilid.equals("fail"))
						{
							Toast.makeText(view.getContext(), "使用者帳號或錯誤", Toast.LENGTH_LONG).show();
						}
						else
						{
							Intent app = new Intent(MYTSLogin.this, MainActivity.class);
							Bundle ndata = new Bundle();
							ndata.putString("user", account.getText().toString());
							ndata.putString("type", group.h_chilid);
							app.putExtras(ndata);
							startActivity(app);
						}
					}
					else
					{
						Toast.makeText(view.getContext(), "使用者帳號或錯誤", Toast.LENGTH_LONG).show();
					}
				}
			}
		});

        Button mylogin2 = (Button) findViewById(R.id.mylogin2);

        //check login
        mylogin2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view)
            {
                Intent app = new Intent(MYTSLogin.this, MYTSRegister.class);
                startActivity(app);
            }
        });

	}
	
	//if press back, return to android code
    public boolean onKeyDown(int keyCode, KeyEvent event) 
    {
    	if(keyCode==KeyEvent.KEYCODE_BACK)
    	{  
    		android.os.Process.killProcess(android.os.Process.myPid());           
            finish();
    		return true;
    	}
		
		return super.onKeyDown(keyCode, event);  
    }
    
    
}
