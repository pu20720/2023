package com.xml;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.util.Log;

public class MTalkListContainer 
{

	private ArrayList<MTalkStruct> jlist_items;

	//item
	public ArrayList<MTalkStruct> getListItems() 
	{
	  return jlist_items;
	}
	
	public MTalkStruct getoneJL(int index)
	{
		return jlist_items.get(index);
	}
	
	public MTalkListContainer() 
	{
		jlist_items = new ArrayList<MTalkStruct>();
	}

	public void addRXMLItem(MTalkStruct item) 
	{
		jlist_items.add(item);
	}
}
