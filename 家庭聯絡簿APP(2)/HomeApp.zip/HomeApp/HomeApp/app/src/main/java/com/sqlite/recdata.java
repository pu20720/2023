package com.sqlite;

public class recdata 
{
	public static final String ID = "aid";
	public static final String NAME = "name";
  public static final String MODE = "mode";
  public static final String KL = "KL";
  public static final String STEP = "mstep";
  public static final String DISTANCE = "distance";
  public static final String DETAIL = "detail";
  public static final String DETAIL2 = "detail2";
  public static final String CTIME = "ctime";
	

	public String id;
	public String name;
  public String mode;
  public String kl;
  public String step;
  public String distance;
  public String detail;
  public String detail2;
  public String ctime;
 
}
