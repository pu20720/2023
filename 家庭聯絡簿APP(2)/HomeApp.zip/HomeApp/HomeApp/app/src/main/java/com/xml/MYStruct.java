 package com.xml;

public class MYStruct 
{
	  public String h_chilid;	  
}