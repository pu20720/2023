package com.xml;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import android.util.Log;

public class UserGroupHandler extends DefaultHandler
{
	//tag
	private String TAG = "MessageHandler";
	
	private final static int ID = 1;
	private final static int ARTICLEID = 2;
	private final static int USER = 3;
	private final static int RDATE = 4;

	private UserGroupStruct jls;
	private UserGroupContainer jlcs;
	
	private int type;

	public UserGroupContainer getContainer() 
	{
		return jlcs;
	}

	public UserGroupStruct getJListStruct() 
	{
		return jlcs.getoneJL(0);
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		
		String s = new String(ch, start, length);
		
		switch (type) 
		{
		case ID:
			jls.id = s;
			type = 0;
			break;
		case ARTICLEID:
			jls.aid = s;
			type = 0;
			break;
		case USER:
			jls.user = s;
			type = 0;
			break;
		case RDATE:
			jls.rdate = s;
			type = 0;
			break;
		}
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {

		if (localName.toLowerCase().equals("item")) 
		{
			jlcs.addRXMLItem(jls);	
		}
	}

	@Override
	public void startDocument() throws SAXException 
	{
		jlcs = new UserGroupContainer();
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException 
	{
		if (localName.toLowerCase().equals("item")) 
		{
			jls = new UserGroupStruct();
			return;
		}
		else if (localName.toLowerCase().equals("id")) 
		{
			type = ID;
			return;
		}
		else if (localName.toLowerCase().equals("aid")) 
		{
			type = ARTICLEID;
			return;
		}
		else if (localName.toLowerCase().equals("user")) 
		{
			type = USER;
			return;
		}
		else if (localName.toLowerCase().equals("rdate")) 
		{
			type = RDATE;
			return;
		}		
		type = 0;
	}

}