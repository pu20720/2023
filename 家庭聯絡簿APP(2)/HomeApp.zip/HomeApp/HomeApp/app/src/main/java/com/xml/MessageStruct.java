package com.xml;


public class MessageStruct 
{
	
	 public String id;
     public String title;
	 public String content;
	 public String pic;
	 public String address;
	 public String pnum;
	 public String type;
	 public String user;
	 public String rdate;
}