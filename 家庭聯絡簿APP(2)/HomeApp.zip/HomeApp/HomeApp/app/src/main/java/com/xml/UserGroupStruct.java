package com.xml;


public class UserGroupStruct 
{
	
	 public String id;
     public String aid;
	 public String user;
	 public String rdate;
}