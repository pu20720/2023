package com.xml;


public class DiscussStruct 
{
	
	 public String id;
     public String aid;
	 public String content;
	 public String user;
	 public String rdate;
}