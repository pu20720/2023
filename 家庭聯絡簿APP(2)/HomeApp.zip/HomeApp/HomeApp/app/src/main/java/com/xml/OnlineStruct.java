package com.xml;


public class OnlineStruct 
{
	
  public String id;
  public String name;
  public String lat;
  public String lng;

  public OnlineStruct()
  {

  }  
}