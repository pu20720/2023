package com.xml;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.util.Log;

public class DiscussContainer 
{

	private ArrayList<DiscussStruct> jlist_items;

	//item
	public ArrayList<DiscussStruct> getListItems() 
	{
	  return jlist_items;
	}
	
	public DiscussStruct getoneJL(int index)
	{
		return jlist_items.get(index);
	}
	
	public DiscussContainer() 
	{
		jlist_items = new ArrayList<DiscussStruct>();
	}

	public void addRXMLItem(DiscussStruct item) 
	{
		jlist_items.add(item);
	}
}
