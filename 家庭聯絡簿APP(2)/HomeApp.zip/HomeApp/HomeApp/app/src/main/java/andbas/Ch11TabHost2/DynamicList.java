package andbas.Ch11TabHost2;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import com.xml.LoginXMLHandler;
import com.xml.LoginXMLStruct;
import com.xml.MessageHandler;
import com.xml.MessageHandler2;
import com.xml.MessageStruct;
import com.xml.MessageStruct2;
import com.xml.UserGroupHandler;
import com.xml.UserGroupStruct;

import andbas.Ch11TabHost2.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import android.widget.SimpleAdapter.ViewBinder;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;

public class DynamicList extends Activity {
	TextView textView1;
	TextView textView2;
	ListView lv;
	ImageView iv;


	String title, context = "", img, pnum, article_id, phone, address;
	int type;
	String IPAddress = "";

	Button account, chatroom, attend, saleinfo;

	private ArrayList<UserGroupStruct> query_data = new ArrayList<UserGroupStruct>();

	LoginXMLStruct data;

	String user;

	int private_recieve_type;

	int cop = 0;

	private ArrayList<MessageStruct2> mydata;

	int flags = 0;

	String auser;

	int mea = 0;

	String id = "";

	int admin;

	Button mapbutton;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.dynamiclist);

		Bundle bData = this.getIntent().getExtras();

		id = bData.getString("id");
		title = bData.getString("title");
		context = bData.getString("content");
		img = bData.getString("img");
		pnum = bData.getString("pnum");
		article_id = bData.getString("article_id");
		phone = bData.getString("phone");
		address = bData.getString("address");
		user = getIntent().getExtras().getString("user");
		admin = Integer.valueOf(getIntent().getExtras().getString("admin"));

		IPAddress = (String) this.getResources().getText(R.string.url);
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);

		buildViews();  //user define
	}


	private void buildViews() {
		int idx1, idx2, idx3;

		textView1 = (TextView) findViewById(R.id.textView1);
		textView2 = (TextView) findViewById(R.id.textView2);

		account = (Button) findViewById(R.id.button2);

		textView1.setText(title);
		textView2.setText(context);

		account.setOnClickListener(listener);
		reload();

	}

	private Button.OnClickListener listener = new Button.OnClickListener() {

		@Override
		public void onClick(View v) {
			switch (v.getId()) {
				case R.id.button2:
					//phone
					Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phone));
					if (ActivityCompat.checkSelfPermission(DynamicList.this, android.Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
						// TODO: Consider calling
						//    ActivityCompat#requestPermissions
						// here to request the missing permissions, and then overriding
						//   public void onRequestPermissionsResult(int requestCode, String[] permissions,
						//                                          int[] grantResults)
						// to handle the case where the user grants the permission. See the documentation
						// for ActivityCompat#requestPermissions for more details.
						return;
					}
					startActivity(intent);
				break;
		}

		}
	};

	
	void reload()
	{
		if (!user.equals("guest"))
			getusergroup();

		if (admin==1)
		{
			attend.setText("管理者");
			attend.setEnabled(false);
			chatroom.setEnabled(true);
		}
	}
	
	 void getusergroup()
	 {
	        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
	        StrictMode.setThreadPolicy(policy); 
	        String uriAPI ="";
	        try
	        {
	        	//String s = URLEncoder.encode(k, "utf-8");
	        	uriAPI = IPAddress + "getgroupuser.php?aid=" + article_id;
	        	Log.i("TAG", uriAPI);
	        }
	        catch (Exception e)
	        {
	        	e.printStackTrace();
	        }
	        
			Log.i("TAG", uriAPI);
			
			URL url = null;
			try{
				url = new URL(uriAPI);
				
				SAXParserFactory spf = SAXParserFactory.newInstance();
				SAXParser sp = spf.newSAXParser();
				XMLReader xr = sp.getXMLReader();
				//Using login handler for xml
				UserGroupHandler myHandler = new UserGroupHandler();
				xr.setContentHandler(myHandler);
				//open connection
				xr.parse(new InputSource(url.openStream()));
				//verify OK
				query_data = myHandler.getContainer().getListItems();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
			
			for (int i = 0; i<query_data.size(); i++)
			{
				if (admin == 0) {
					if (query_data.get(i).user.equals(user)) {
						attend.setText("己加入");
						attend.setEnabled(false);
						chatroom.setEnabled(true);
						break;
					}
				}
			}
	 }

	 
	void senddata()
	{
    	  try
    	  {
	    	  String uriAPI = IPAddress + "sendattendgroup.php?aid=" + article_id + "&user=" + user;
	    	  
	    	  Log.i("TAG", uriAPI);
	
				URL url = null;
				try{
					url = new URL(uriAPI);
					
					SAXParserFactory spf = SAXParserFactory.newInstance();
					SAXParser sp = spf.newSAXParser();
					XMLReader xr = sp.getXMLReader();
					//Using login handler for xml
					LoginXMLHandler myHandler = new LoginXMLHandler();
					xr.setContentHandler(myHandler);
					//open connection
					xr.parse(new InputSource(url.openStream()));
					//verify OK
					data = myHandler.getParsedData();
				}
				catch(Exception e){
					e.printStackTrace();
					return;
				}				
    	  }
    	  catch (Exception e)
    	  {
    		  e.printStackTrace();
    	  }
    	  
    	  reload();
	}	
	
	
	
	public void openOptionsDialog(String title, String info)
	{
	    new AlertDialog.Builder(this)
	    .setTitle(title)
	    .setMessage(info)
	    .setPositiveButton("OK",
	        new DialogInterface.OnClickListener()
	        {
	         public void onClick(DialogInterface dialoginterface, int i)
	         {
	        	
	         }
	         }
	        )
	    .show();
	}


}
