package com.xml;


public class MessageStruct2
{
	
  public String id;
  public String content;
  public String user;
  public String rdate;
  public String type;

}