<?php

include 'db.php';

$user=$_GET["user"];
$status=$_GET["status"];
$rdate=date("Y-m-d H:i:s");
$group="0";

$sql="INSERT INTO flist(user, status, rdate, mygroup) VALUES ('$user','$status','$rdate', '$group')";
if (!mysql_query($sql, $con))
{
 die('Error: ' . mysql_error());
} 

mysql_close($con);
?>

