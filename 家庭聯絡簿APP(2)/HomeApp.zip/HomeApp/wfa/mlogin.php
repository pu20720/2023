<?php

include 'db.php';

$username=$_GET["myaccount"];
$pwd=$_GET["mypwd"];

header('Content-type: text/xml');
$us = mysql_query("select * from member_table where username='$username'", $con);
$rows_num = mysql_num_rows($us);

// create a new XML document
$doc = new DomDocument('1.0', 'UTF-8');

// add root node
$root = $doc->createElement('login');
$root = $doc->appendChild($root);

$flag=1;

while($data=mysql_fetch_row($us))
{
    $flag=0;
    // add a child node for each field
    $child = $doc->createElement('result');
    $child = $root->appendChild($child);

    if ($pwd == $data[2] )
    {
        $str=$data[3];
		$value = $doc->createTextNode($str);
    }
    else
    {
	    $value = $doc->createTextNode('fail');
    }

    $value =  $child->appendChild($value);
    break;

}

if ($flag == 1)
{
    $child = $doc->createElement('result');
    $child = $root->appendChild($child);
    $value = $doc->createTextNode('fail');
    $value =  $child->appendChild($value);

}

$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>

