<?php

include 'db.php';

$content=$_GET["content"];
$user=$_GET["user"];
$rdate=$_GET["rdate"];

    $sql="INSERT INTO main_chatroomt(content, user, rdate) VALUES ('$content','$user','$rdate')";
    if (!mysql_query($sql, $con))
    {
     die('Error: ' . mysql_error());
    } 

mysql_close($con);
?>

