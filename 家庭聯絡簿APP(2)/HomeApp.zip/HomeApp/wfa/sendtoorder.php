<?php

include 'db.php';

header('Content-type: text/xml');

$user=$_GET["user"];

// create a new XML document
$doc = new DomDocument('1.0', 'UTF-8');

// add root node
$root = $doc->createElement('talk');
$root = $doc->appendChild($root);

$sql = mysql_query("select * from attend where user='$user'", $con);
$rows_num = mysql_num_rows($sql);

$aid="";
while($mdata=mysql_fetch_row($sql))
{
    $aid = $aid + "," + $mdata[2];
}	

$sql="INSERT INTO sorder(user, aid, rdate) VALUES ('$user','$aid','$rdate')";

mysql_query($sql, $con);

$sql="Delete from attend where user='$user'";

mysql_query($sql, $con);

$child = $doc->createElement('login');
$child = $inner->appendChild($child);
$value = $doc->createTextNode("1");
$value = $child->appendChild($value);

$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>