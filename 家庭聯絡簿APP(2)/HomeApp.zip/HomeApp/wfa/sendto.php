<?php

include 'db.php';

$user=$_GET["user"];
$touser=$_GET["touser"];
$content=$_GET["content"];
$type=$_GET["type"];
$flag=0;

header('Content-type: text/xml');

mysql_query("SET NAMES 'utf8'");

// create a new XML document
	$doc = new DomDocument('1.0', 'UTF-8');

// add root node
	$root = $doc->createElement('login');
	$root = $doc->appendChild($root);

 
	$rdate =date("Y-m-d H:i:s");
    $sql="INSERT INTO onetoone(user, touser, content, type, rdate, isread) VALUES ('$user','$touser','$content', '$type','$rdate','0')";
    if (!mysql_query($sql, $con) == -1)
    {
		 $child = $doc->createElement('result');
		 $child = $root->appendChild($child);

		 $value = $doc->createTextNode('-1');
		 $value =  $child->appendChild($value);
    } 
	else
	{
		if ($type == "3")
		{
			$sql="UPDATE list SET vstatus='1' where user = '$touser'";
			mysql_query($sql, $con);
		}
	
		   // add a child node for each field
		$child = $doc->createElement('result');
		$child = $root->appendChild($child);

		$value = $doc->createTextNode('1');
		$value =  $child->appendChild($value);
	}



$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>

