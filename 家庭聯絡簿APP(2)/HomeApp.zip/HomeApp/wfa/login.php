<?php
    //手機程式登入檢查之用
    //傳username和pwd就能查到是否有權限登入
?>
<?

include 'db.php';

$username=$_GET["username"];
$pwd=$_GET["pwd"];

header('Content-type: text/xml');
$us = mysql_query("select * from member_table where username='$username'", $con);
$rows_num = mysql_num_rows($us);

// create a new XML document
$doc = new DomDocument('1.0', 'UTF-8');

// add root node
$root = $doc->createElement('login');
$root = $doc->appendChild($root);

$flag=1;

while($data=mysql_fetch_row($us))
{
    $flag=0;
    // add a child node for each field
    $child = $doc->createElement('result');
    $child = $root->appendChild($child);

    if ($pwd == $data[2])
    {
	    $value = $doc->createTextNode($data[6]);
    }
    else
    {
	    $value = $doc->createTextNode('000');
    }

    $value =  $child->appendChild($value);
    break;

}

if ($flag == 1)
{
    $child = $doc->createElement('result');
    $child = $root->appendChild($child);
    $value = $doc->createTextNode('000');
    $value =  $child->appendChild($value);

}

$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>

