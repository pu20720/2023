<?php

include 'db.php';

$user=$_GET["user"];
$sd=$_GET["sd"];

header('Content-type: text/xml');

mysql_query("SET NAMES 'utf8'");

// create a new XML document
$doc = new DomDocument('1.0', 'UTF-8');

// add root node
$root = $doc->createElement('login');
$root = $doc->appendChild($root);

$rdate =date("Y-m-d H:i:s");
$sql="UPDATE userdata SET sd='$sd' where user='$user'";
if (!mysql_query($sql, $con) == -1)
{
	 $child = $doc->createElement('result');
	 $child = $root->appendChild($child);

	 $value = $doc->createTextNode('-1');
	 $value =  $child->appendChild($value);
} 
else
{
	// add a child node for each field
	$child = $doc->createElement('result');
	$child = $root->appendChild($child);

	$value = $doc->createTextNode('1');
	$value =  $child->appendChild($value);
}

$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>
