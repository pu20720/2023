<?php

include 'db.php';

header('Content-type: text/xml');

$user=$_GET["user"];

$us = mysql_query("select * from article where user='$user' or type='$user'", $con);
$rows_num = mysql_num_rows($us);

while($data=mysql_fetch_row($us))
{   
    $us = mysql_query("select * from attend where aid='$data[0]' and rdate='1'", $con);
    $rows_num = mysql_num_rows($us);

    // create a new XML document
    $doc = new DomDocument('1.0', 'UTF-8');

    // add root node
    $root = $doc->createElement('talk');
    $root = $doc->appendChild($root);

    while($attend=mysql_fetch_row($us))
    {
        $inner = $doc->createElement('item');
        $inner = $root->appendChild($inner);

        // add a child node for each field
        $child = $doc->createElement('id');
        $child = $inner->appendChild($child);
        $value = $doc->createTextNode("$data[1]");	//社團title
        $value = $child->appendChild($value);

        $child = $doc->createElement('aid');
        $child = $inner->appendChild($child);
        $value = $doc->createTextNode("$attend[1]");	//attend id
        $value = $child->appendChild($value);

        $child = $doc->createElement('user');
        $child = $inner->appendChild($child);
        $value = $doc->createTextNode("$attend[2]");	//申請者		
        $value = $child->appendChild($value);
    	
    	$child = $doc->createElement('rdate');
        $child = $inner->appendChild($child);
        $value = $doc->createTextNode("$attend[3]");	//狀態
        $value = $child->appendChild($value);	
    }
}

$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>

