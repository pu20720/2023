<?php

include 'db.php';

$title=$_GET["title"];
$content=$_GET["content"];
$pic=$_GET["pic"];
$address=$_GET["address"];
$type=$_GET["type"];
$pnum=$_GET["pnum"];
$user=$_GET["user"];
$area=$_GET["area"];
$flag=0;

header('Content-type: text/xml');

mysql_query("SET NAMES 'utf8'");

// create a new XML document
	$doc = new DomDocument('1.0', 'UTF-8');

// add root node
	$root = $doc->createElement('login');
	$root = $doc->appendChild($root);
	date_default_timezone_set("Asia/Taipei");
	$rdate =date("Y-m-d H:i:s");
    $sql="INSERT INTO article(title,content,pic,address,pnum,type,user,rdate, area) VALUES ('$title','$content','$pic', '$address','$pnum','$type','$user','$rdate','$area')";
    if (!mysql_query($sql, $con) == -1)
    {
		 $child = $doc->createElement('result');
		 $child = $root->appendChild($child);

		 $value = $doc->createTextNode('-1');
		 $value =  $child->appendChild($value);
    } 
	else
	{
	
		   // add a child node for each field
		$child = $doc->createElement('result');
		$child = $root->appendChild($child);

		$value = $doc->createTextNode('1');
		$value =  $child->appendChild($value);
	}



$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>

