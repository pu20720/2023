<?php

$base=$_REQUEST['image'];
$filename=$_REQUEST['filename'];

echo $filename;

// base64 encoded utf-8 string

$binary=base64_decode($base);

// binary, utf-8 bytes

//header('Content-Type: bitmap; charset=utf-8');

// print($binary);

//$theFile = base64_decode($image_data);

$file = fopen("./upload/".$filename, 'wb');

fwrite($file, $binary);

fclose($file);

//echo '<img src=test.jpg>';

?>