<?php

include 'db.php';

$user2=$_GET["user2"];
$content=$_GET["content"];
$id=$_GET["id"];
$user=$_GET["user"];
$flag=0;

header('Content-type: text/xml');

mysql_query("SET NAMES 'utf8'");

// create a new XML document
	$doc = new DomDocument('1.0', 'UTF-8');

// add root node
	$root = $doc->createElement('login');
	$root = $doc->appendChild($root);
	date_default_timezone_set("Asia/Taipei");
	$rdate =date("Y-m-d H:i:s");
    $sql="UPDATE article SET content='$content', type='$user2' WHERE id='$id'";
    if (!mysql_query($sql, $con) == -1)
    {
		 $child = $doc->createElement('result');
		 $child = $root->appendChild($child);

		 $value = $doc->createTextNode('-1');
		 $value =  $child->appendChild($value);
    } 
	else
	{
	
		   // add a child node for each field
		$child = $doc->createElement('result');
		$child = $root->appendChild($child);

		$value = $doc->createTextNode('1');
		$value =  $child->appendChild($value);
	}



$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>

