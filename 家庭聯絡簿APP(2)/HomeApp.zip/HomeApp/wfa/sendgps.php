<?php

include 'db.php';

$user=$_GET["user"];
$lat=$_GET["lat"];
$lng=$_GET["lng"];

header('Content-type: text/xml');

mysql_query("SET NAMES 'utf8'");

// create a new XML document
	$doc = new DomDocument('1.0', 'UTF-8');

// add root node
	$root = $doc->createElement('login');
	$root = $doc->appendChild($root);

	$us = mysql_query("select * from userdata where gid='$user'", $con);
	$rows_num = mysql_num_rows($us);

	if ($rows_num != 0)
	{
		$rdate =date("Y-m-d H:i:s");
		$sql="UPDATE userdata SET lat='$lat', lng='$lng' where gid='$user'";
		if (!mysql_query($sql, $con) == -1)
		{
			 $child = $doc->createElement('result');
			 $child = $root->appendChild($child);

			 $value = $doc->createTextNode('-1');
			 $value =  $child->appendChild($value);
		} 
		else
		{
			   // add a child node for each field
			$child = $doc->createElement('result');
			$child = $root->appendChild($child);

			$value = $doc->createTextNode('1');
			$value =  $child->appendChild($value);
		}
	}
	else
	{
		$rdate =date("Y-m-d H:i:s");
		$sql="INSERT INTO userdata(user,lat,lng,gid) VALUES ('$user','$lat','$lng','-1')";
		if (!mysql_query($sql, $con) == -1)
		{
			 $child = $doc->createElement('result');
			 $child = $root->appendChild($child);

			 $value = $doc->createTextNode('-1');
			 $value =  $child->appendChild($value);
		} 
		else
		{
			   // add a child node for each field
			$child = $doc->createElement('result');
			$child = $root->appendChild($child);

			$value = $doc->createTextNode('1');
			$value =  $child->appendChild($value);
		}
	}
	



$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>

