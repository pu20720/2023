<?php
$con=mysql_connect('localhost', 'root','123456');
mysql_select_db('wfa',$con);
mysql_query("SET NAMES 'utf8'");
?>
