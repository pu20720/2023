<?php

include 'db.php';

$aid=$_GET["aid"];
$user=$_GET["user"];
$flag=0;

header('Content-type: text/xml');

mysql_query("SET NAMES 'utf8'");

// create a new XML document
	$doc = new DomDocument('1.0', 'UTF-8');

// add root node
	$root = $doc->createElement('login');
	$root = $doc->appendChild($root);
	date_default_timezone_set("Asia/Taipei");
	$rdate =date("Y-m-d H:i:s");
	
	$sql = mysql_query("select * from attend where article_id = '$aid' and user='$user'", $con);
	$rows_num = mysql_num_rows($sql);

	if ($rows_num == 0)
	{
			 $child = $doc->createElement('result');
			 $child = $root->appendChild($child);

			 $value = $doc->createTextNode('-1');
			 $value =  $child->appendChild($value);	
	}
	else
	{
	
		$sql="Delete from attend where article_id = '$aid' and user = '$user'";
		if (!mysql_query($sql, $con) == -1)
		{
			 $child = $doc->createElement('result');
			 $child = $root->appendChild($child);

			 $value = $doc->createTextNode('-1');
			 $value =  $child->appendChild($value);
		} 
		else
		{
			// add a child node for each field
			$child = $doc->createElement('result');
			$child = $root->appendChild($child);

			$value = $doc->createTextNode('1');
			$value =  $child->appendChild($value);
		}
	}

$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>

