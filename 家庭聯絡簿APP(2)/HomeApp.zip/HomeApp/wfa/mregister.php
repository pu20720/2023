<?php

include 'db.php';

$username=$_GET["myaccount"];
$pwd=$_GET["mypwd"];
$myid=$_GET["myid"];

header('Content-type: text/xml');
$us = mysql_query("select * from member_table where username='$username'", $con);
$rows_num = mysql_num_rows($us);

// create a new XML document
$doc = new DomDocument('1.0', 'UTF-8');

// add root node
$root = $doc->createElement('login');
$root = $doc->appendChild($root);

$flag=0;

while($data=mysql_fetch_row($us))
{
    $flag=1;
    $child = $doc->createElement('result');
    $child = $root->appendChild($child);
    $value = $doc->createTextNode('-1');
    $value =  $child->appendChild($value);

    break;

}

if ($flag == 0)
{
    // add a child node for each field
    $child = $doc->createElement('result');
    $child = $root->appendChild($child);

    $value = $doc->createTextNode($username);
    $value =  $child->appendChild($value);

    $sql="INSERT INTO member_table(username, pwd, type) VALUES ('$username','$pwd', '$myid')";
    if (!mysql_query($sql, $con))
    {
      $child = $doc->createElement('result');
    $child = $root->appendChild($child);
    $value = $doc->createTextNode('-1');
    $value =  $child->appendChild($value);
    } 

}

$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>

