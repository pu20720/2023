<?php

include 'db.php';

header('Content-type: text/xml');

$user=$_GET["user"];

$us = mysql_query("select * from userdata where user='$user'", $con);
$rows_num = mysql_num_rows($us);

if ($rows_num == 0)
{
$us = mysql_query("select * from userdata where gid='$user'", $con);
}

// create a new XML document
$doc = new DomDocument('1.0', 'UTF-8');

// add root node
$root = $doc->createElement('talk');
$root = $doc->appendChild($root);

while($data=mysql_fetch_row($us))
{
    $inner = $doc->createElement('item');
    $inner = $root->appendChild($inner);

    // add a child node for each field
    $child = $doc->createElement('id');
    $child = $inner->appendChild($child);
    $value = $doc->createTextNode("$data[0]");
    $value = $child->appendChild($value);

    $child = $doc->createElement('user');
    $child = $inner->appendChild($child);
    $value = $doc->createTextNode("$data[5]");
    $value = $child->appendChild($value);
	
	$child = $doc->createElement('lat');
    $child = $inner->appendChild($child);
    $value = $doc->createTextNode("$data[2]");
    $value = $child->appendChild($value);	
	
	$child = $doc->createElement('lng');
    $child = $inner->appendChild($child);
    $value = $doc->createTextNode("$data[3]");
    $value = $child->appendChild($value);	
}

$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>

