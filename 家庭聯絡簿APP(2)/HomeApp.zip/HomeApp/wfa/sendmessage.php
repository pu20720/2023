<?php

include 'db.php';

$name=$_GET["name"];
$content=$_GET["content"];
$flag=0;

header('Content-type: text/xml');

mysql_query("SET NAMES 'utf8'");


$us = mysql_query("select * from article where title = '$name'", $con);
$rows_num = mysql_num_rows($us);
$data=mysql_fetch_row($us);

// create a new XML document
	$doc = new DomDocument('1.0', 'UTF-8');

// add root node
	$root = $doc->createElement('login');
	$root = $doc->appendChild($root);
	date_default_timezone_set("Asia/Taipei");

 if ($rows_num != 0)
 {
 	$aid=$data[0];			//find article id
 	$user="guest";
	$rdate =date("Y-m-d H:i:s");
    $sql="INSERT INTO discuss(aid,content,user,rdate) VALUES ('$aid','$content','$user','$rdate')";
    if (!mysql_query($sql, $con) == -1)
    {
		 $child = $doc->createElement('result');
		 $child = $root->appendChild($child);

		 $value = $doc->createTextNode('-1');
		 $value =  $child->appendChild($value);
    } 
	else
	{
		   // add a child node for each field
		$child = $doc->createElement('result');
		$child = $root->appendChild($child);

		$value = $doc->createTextNode('1');
		$value =  $child->appendChild($value);
	}
 }
 else
 {
		$child = $doc->createElement('result');
		 $child = $root->appendChild($child);

		 $value = $doc->createTextNode('-1');
		 $value =  $child->appendChild($value);

 }

$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>

