<?php

include 'db.php';

header('Content-type: text/xml');

$touser=$_GET["touser"];

$us = mysql_query("select * from onetoone where touser='$touser' and isread='0'", $con);
$rows_num = mysql_num_rows($us);

// create a new XML document
$doc = new DomDocument('1.0', 'UTF-8');

// add root node
$root = $doc->createElement('talk');
$root = $doc->appendChild($root);

while($data=mysql_fetch_row($us))
{
    $inner = $doc->createElement('item');
    $inner = $root->appendChild($inner);

    // add a child node for each field
    $child = $doc->createElement('id');
    $child = $inner->appendChild($child);
    $value = $doc->createTextNode("$data[0]");
    $value = $child->appendChild($value);

    $child = $doc->createElement('content');
    $child = $inner->appendChild($child);
    $value = $doc->createTextNode("$data[3]");
    $value = $child->appendChild($value);

    $child = $doc->createElement('user');
    $child = $inner->appendChild($child);
    $value = $doc->createTextNode("$data[1]");
    $value = $child->appendChild($value);
	
	$child = $doc->createElement('type');
    $child = $inner->appendChild($child);
    $value = $doc->createTextNode("$data[4]");
    $value = $child->appendChild($value);
	

    $child = $doc->createElement('rdate');
    $child = $inner->appendChild($child);
    $value = $doc->createTextNode("$data[5]");
    $value = $child->appendChild($value);
	
	
	$sql="UPDATE onetoone SET isread='1' where id='$data[0]'";
    if (!mysql_query($sql, $con))
    {
     die('Error: ' . mysql_error());
    } 


}

$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>

