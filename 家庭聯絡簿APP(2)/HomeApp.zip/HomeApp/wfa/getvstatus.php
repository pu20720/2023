<?php

include 'db.php';

$username=$_GET["username"];

header('Content-type: text/xml');
$us = mysql_query("select * from list where user='$username'", $con);
$rows_num = mysql_num_rows($us);

$data=mysql_fetch_row($us);

// create a new XML document
$doc = new DomDocument('1.0', 'UTF-8');

// add root node
$root = $doc->createElement('login');
$root = $doc->appendChild($root);

$child = $doc->createElement('result');
$child = $root->appendChild($child);
$value = $doc->createTextNode("$data[5]");
$value =  $child->appendChild($value);

$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>

