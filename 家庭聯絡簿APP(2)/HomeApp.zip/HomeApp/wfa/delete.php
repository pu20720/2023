<?php
    //�޲z����, �R���ӫ~
?>
<html>
<head>
<meta http-equiv="Content-Language" content="zh-tw">
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title></title>
<style type="text/css">
a:link   {text-decoration:underline;color:blue;}
a:visited  {text-decoration:underline;color:blue;}
a:hover  {text-decoration:none;color:red;background-color: #00ff00;}
td, input, select, div   {font-size:9pt;}
</style>
    <style type="text/css">
      #map {
        width: 800px;
        height: 500px;
      }
    </style>
<head>

</head>


<?
       include("db.php");       
       $id = $_GET['id'];
       $sql = "Delete FROM aboutarticle where id = '$id'";
       $result = mysql_query($sql);
        echo '���\!';
        echo "<meta http-equiv=REFRESH CONTENT=1;url=carlist.php>";
?>


</body>
</html>

