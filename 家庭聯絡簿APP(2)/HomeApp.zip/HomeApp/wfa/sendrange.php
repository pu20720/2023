<?php

include 'db.php';

$lat1=$_GET["lat1"];
$lng1=$_GET["lng1"];
$radius=$_GET["radius"];
$status=$lat1.",".$lng1.",".$radius;
$group=$_GET["group"];

$us = mysql_query("select * from gpsrange where mygroup='$group'", $con);
$rows_num = mysql_num_rows($us);

if ($rows_num == 0 )
{
    $sql="INSERT INTO gpsrange(lat1, lng1, raidus, mygroup) VALUES ('$lat1', '$lng1', '$radius', '$group')";
    if (!mysql_query($sql, $con))
    {
     die('Error: ' . mysql_error());
    } 
}
else
{
    $sql="Updata gpsrange set lat1='$lat1', lng1='$lng1', raidus='$raidus' where mygroup = '$group'";
    if (!mysql_query($sql, $con))
    {
     die('Error: ' . mysql_error());
    } 	
}

mysql_close($con);
?>

