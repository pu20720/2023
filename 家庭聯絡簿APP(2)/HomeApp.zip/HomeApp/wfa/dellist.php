<?php

include 'db.php';

$user=$_GET["user"];

$sql="Delete from list where user= '$user'";
if (!mysql_query($sql, $con))
{
 die('Error: ' . mysql_error());
} 

mysql_close($con);

?>

