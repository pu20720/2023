<?php

include 'db.php';

$user=$_GET["user"];
$content=$_GET["content"];
$group=$_GET["group"];
$type=$_GET["type"];
$flag=0;

header('Content-type: text/xml');

mysql_query("SET NAMES 'utf8'");

// create a new XML document
	$doc = new DomDocument('1.0', 'UTF-8');

// add root node
	$root = $doc->createElement('login');
	$root = $doc->appendChild($root);

 
	$rdate =date("Y-m-d H:i:s");
    $sql="INSERT INTO main_chatroom(user, touser, content, type, rdate, mygroup) VALUES ('$user','all','$content', '$type','$rdate','$group')";
    if (!mysql_query($sql, $con) == -1)
    {
		 $child = $doc->createElement('result');
		 $child = $root->appendChild($child);

		 $value = $doc->createTextNode('-1');
		 $value =  $child->appendChild($value);
    } 
	else
	{
		if ($type == "3")
		{
			$sql="UPDATE list SET vstatus='1' where user = '$touser'";
			mysql_query($sql, $con);
		}
	
		   // add a child node for each field
		$child = $doc->createElement('result');
		$child = $root->appendChild($child);

		$value = $doc->createTextNode('1');
		$value =  $child->appendChild($value);
	}



$xml_string = $doc->saveXML();
echo $xml_string;

mysql_close($con);
?>

