<?php

include 'db.php';

$user=$_GET["user"];
$status=$_GET["status"];
$rdate=$_GET["rdate"];
$group=$_GET["group"];

$us = mysql_query("select * from list where user='$user'", $con);
$rows_num = mysql_num_rows($us);

if ($rows_num == 0 )
{
    $sql="INSERT INTO list(user, status, rdate, mygroup) VALUES ('$user','$status','$rdate', '$group')";
    if (!mysql_query($sql, $con))
    {
     die('Error: ' . mysql_error());
    } 
}

mysql_close($con);
?>

