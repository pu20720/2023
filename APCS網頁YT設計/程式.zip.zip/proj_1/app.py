from flask import Flask, render_template, redirect, url_for, request, session, flash
from methods import get_user, get_videos, get_video, check_email, check_login, check_name, get_msg
import sqlite3
from back import db_infomation
from datetime import datetime as dt
from add_video import add_v
app = Flask(__name__)
app.config['SECRET_KEY'] ='SECRET_KEY'

conn = sqlite3.connect('db.sqlite', check_same_thread=False)
cursor = conn.cursor()


# 首頁
@app.route('/')
def home():
    videos = get_videos()
    return render_template('view.html')
##################################################
# 登入
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        email = request.values['email']
        pwd = request.values['pwd']
        print(email,pwd)
        if check_login(email,pwd):
            session['user'] = get_user(email)
            session['email'] = email
            return redirect(url_for('home'))
        else:
            error = '信箱或密碼錯誤!'
            print(error)
        return render_template('login.html',error = error)
    return render_template('login.html', error = error)

# 註冊
@app.route('/register', methods=['GET', 'POST'])
def register():
    error = False
    if request.method == 'POST':
        email = request.values['email']
        name = request.values['name']
        pwd = request.values['pwd']
        che_pwd = request.values['che_pwd']
        print(email,name,pwd,che_pwd)
        if check_email(email):
            if check_name(name):
                if che_pwd == pwd:
                    cursor.execute("INSERT INTO users (name, email, password) VALUES (?, ?, ?)", (name, email, pwd))
                    conn.commit()
                    return redirect(url_for('login'))
                else:
                    error = '密碼錯誤!'
            else:
                error = '名字已註冊'
        else:
            error = '信箱已註冊!'
            print(error)
        return render_template('register.html',error = error)
    return render_template('register.html',error = error)

# 登出
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))
##################################################
# 用戶
@app.route('/author/<string:user>', methods=['GET', 'POST'])
def author(user):
    uid = cursor.execute("select id from users where name = ?", (session['user'],)).fetchone()
    if request.method == 'POST':
        t = request.form['title']
        c = request.form['content']
        cursor.execute("INSERT INTO notes (uid, content, title) VALUES (?, ?, ?)", (uid[0],c,t))
        conn.commit()
        return redirect(url_for('author', user = user))
    else:
        notes = cursor.execute("select * from notes where uid = ?", (uid[0],)).fetchall()
        return render_template('author.html', user = user, notes = notes)

# 影片
@app.route('/video/<int:video_id>')
def video(video_id):

    video = get_video(video_id)
    msg = get_msg(video_id)
    mlist = []
    for m in msg:
        u = cursor.execute("select * from users where id = ?", (m[3],)).fetchone()
        li = (m[1], u[1], m[4])
        mlist.append(li)
    print(mlist)
    return render_template('video.html', video = video, msg = mlist)

# 分類
@app.route('/video/<string:clas>')
def vc(clas):
    videos = cursor.execute(f"SELECT * FROM videos where class = ?", (clas,)).fetchall()
    return render_template('home.html', videos = videos)
##################################################
# 留言
@app.route('/vmsg', methods=['GET', 'POST'])
def v_msg():
    msg = request.form['msg']
    vid = request.form['video']
    try:
        uid = cursor.execute(f"SELECT id FROM 'users' where name = ?", (session['user'],)).fetchone()
        cursor.execute("INSERT INTO comments (updated_at, video_id, user_id, content) VALUES (?, ?, ?, ?)", (dt.now(), vid, uid[0], msg))
        conn.commit()
        return redirect(url_for('video' ,video_id = vid))
    except:
        flash('請先登入再留言！ ')
        return redirect(url_for('video' ,video_id = vid))

# 搜尋
@app.route('/sel', methods=['GET', 'POST'])
def sel():
    s = request.form['sel']
    sele = cursor.execute("SELECT * FROM videos where title LIKE ?", (f"%{s}%",)).fetchall()
    for sel in sele:
        print(sel)
    return render_template('select.html', videos = sele)

# note 處理
@app.route('/note/up/<int:nid>', methods=['GET', 'POST'])
def n_update(nid):
    note = cursor.execute("select * from notes where id = ?",(nid,)).fetchone()
    if request.method == "POST":
        cursor.execute("UPDATE notes SET content = ?, title = ? WHERE id = ?", (request.form['content'], request.form['title'], nid))
        conn.commit()
        return redirect(url_for('author', user = session['user']))
    return render_template('note.html', note = note)

@app.route('/note/del/<int:nid>')
def n_del(nid):
    cursor.execute("DELETE FROM notes WHERE id = ?", (nid,))
    conn.commit()
    return redirect(url_for('author', user = session['user']))
##################################################
# 後台管理
@app.route('/back-admin', methods=['GET', 'POST'])
def back_login():
    if request.method == 'POST':
        ad = request.form['admin']
        pwd = request.form['pwd']
        admin = cursor.execute("select * from admin where email = ? and pwd = ?", (ad, pwd)).fetchone()
        print(admin)
        if admin:
            session['admin'] = admin[1]
            return redirect(url_for('back'))
        return render_template('b_login.html')
    return render_template('b_login.html')

@app.route('/back', methods=['GET', 'POST'])
def back():
    # try:
        if session['admin']:
            uvc = []
            db_info = db_infomation()
            return render_template('back.html', db_info = db_info, uvc = uvc)
    # except:
    #     return redirect(url_for('home'))

# 刪除帳號
@app.route('/back/delacc/<int:uid>')
def delacc(uid):
    cursor.execute("delete from users where id = ?", (uid,))
    conn.commit()
    db_info = db_infomation()
    return render_template('back.html', db_info = db_info)
# 查看留言
@app.route('/back/selacc/<int:uid>')
def selacc(uid):
    uvc = cursor.execute("select * from comments where user_id = ?", (uid,))
    conn.commit()
    db_info = db_infomation()
    return render_template('back.html', db_info = db_info, uvc = uvc)
# 新增影片
@app.route('/add/video', methods = ['POST'])
def addv():
    if request.method == 'POST':

        video_url = request.form['vurl']
        video_class = request.form['clas']
        u = "https://www.youtube.com/embed/"+video_url[17:28]
        
        re = add_v(video_url)
        cursor.execute("insert into videos (title, decsription, url, cover, class) VALUES (?, ?, ?, ?, ?)", (re[0], re[1], u, re[2], video_class))
        conn.commit()


        return redirect(url_for('back'))
    return redirect(url_for('back'))
###########################################################################
# 討論區
@app.route('/post')
def post():
    posts = cursor.execute("select * from posts").fetchall()
    return render_template('post.html', posts = posts)
@app.route('/ppost', methods=["POST"])
def pp():
    tit = request.form['tit']
    con = request.form['con']
    u_in = cursor.execute("select * from users where name = ?", (session['user'],)).fetchone()
    cursor.execute("insert into posts (title, updated_at, user_id, user_name, content) VALUES (?, ?, ?, ?, ?)", (tit, dt.now(), u_in[0], u_in[1] ,con))
    conn.commit()
    return redirect(url_for('post'))
@app.route('/post/<int:id>')
def viewp(id):
    post = cursor.execute("select * from posts where id = ?", (id,)).fetchone()
    pms = cursor.execute("select * from post_msgs where post_id = ?", (id,)).fetchall()
    return render_template('viewp.html',post = post, pms = pms)
@app.route('/post/msg/<int:id>', methods=["POST"])
def msgp(id):
    msg = request.form['msg']
    u_in = cursor.execute("select * from users where name = ?", (session['user'],)).fetchone()
    cursor.execute("insert into post_msgs ( updated_at, post_id, user_id, user_name, msg) VALUES (?, ?, ?, ?, ?)", (dt.now(), id, u_in[0], u_in[1] ,msg))
    conn.commit()
    return redirect(url_for('viewp', id = id))
if __name__ == '__main__':
    app.run(debug=True, port=5500)