# https://developers.google.com/explorer-help/code-samples#python

from googleapiclient.discovery import build

def add_v(url):
    
    api_key = "AIzaSyAwuJ4KvWu6yl-5CjgIs5yj5hlbcnXthHM"
    api_service_name = "youtube"
    api_version = "v3"
    youtube = build(api_service_name, api_version, developerKey=api_key)
    
    request = youtube.videos().list(
        part="snippet",
        id=url[17:28]
    )
    response = request.execute()
    return (response['items'][0]['snippet']['title'], response['items'][0]['snippet']['description'], response['items'][0]['snippet']['thumbnails']['medium']['url'])
