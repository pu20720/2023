import sqlite3


def db_infomation():
    
    conn = sqlite3.connect('db.sqlite', check_same_thread=False)
    cursor = conn.cursor()
    sqli = cursor.execute("select * from sqlite_sequence").fetchall()
    users = cursor.execute("select * from users").fetchall()
    videos = cursor.execute("select * from videos").fetchall()
    
    return {"sqlite_sequence":sqli, "users":users, "videos":videos}
