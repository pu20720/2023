from yolov7_onnx import Yolov7Onnx
import cv2
import numpy as np




def process_result(image, result):
    for box in result['bboxes']:
        label = box['label']
        xmin = int(box['x'] * image.shape[1] + 1)
        ymin = int(box['y'] * image.shape[0] + 1)
        xmax = int(xmin + box['width'] * image.shape[1])
        ymax = int(ymin + box['height'] * image.shape[0])

        xmin = max(1, xmin)
        ymin = max(1, ymin)
        xmax = min(image.shape[1], xmax)
        ymax = min(image.shape[0], ymax)

        confidence = box['score']

        print(f"RESULT: {label}\t{xmin}\t{ymin}\t{xmax}\t{ymax}\t{confidence}")
        cv2.rectangle(image, (xmin, ymin), (xmax, ymax), (0, 255, 0), 1, 1, 0)

def main():
    import sys
    '''
    if len(sys.argv) < 3:
        print(f"usage: {sys.argv[0]} <model_name> <image_file_url>")
        sys.exit(-1)
    '''
    image = cv2.imread('/home/necros/Downloads/2253152.jpg')
    if image is None:
        print(f"cannot load {sys.argv[2]}")
        sys.exit(-1)

    model = Yolov7Onnx.create('/home/necros/pt_yolov7_3.5/quantized/yolov7_onnx_pt.onnx', 0.5)  # Assuming Yolov7Onnx is implemented in Python
    if model is None:
        print("failed to create model")
        sys.exit(-1)

    #batch = model.get_input_batch()
    #images = [image.copy() for _ in range(batch)]

    print("ONNX_RUN")
    results = model.run(image)
    print("ONNX_RUN completed")

    for i, result in enumerate(results):
        print(f"batch {i}")
        process_result(image[i], result)
        out_file = f"{i}_result.jpg"
        cv2.imwrite(out_file, image[i])

if __name__ == "__main__":
    main()