from typing import List
import cv2
import numpy as np
import onnxruntime as ort

def overlap(x1, w1, x2, w2):
    left = max(x1 - w1 / 2.0, x2 - w2 / 2.0)
    right = min(x1 + w1 / 2.0, x2 + w2 / 2.0)
    return right - left

def cal_iou(box, truth):
    w = overlap(box[0], box[2], truth[0], truth[2])
    h = overlap(box[1], box[3], truth[1], truth[3])
    
    if w < 0 or h < 0:
        return 0
    
    inter_area = w * h
    union_area = box[2] * box[3] + truth[2] * truth[3] - inter_area
    
    return inter_area * 1.0 / union_area

def apply_nms(boxes, scores, nms, conf):

    count = len(boxes)
    order = [(scores[i], i) for i in range(count)]
    order.sort(key=lambda x: x[0], reverse=True)
    ordered = [item[1] for item in order]
    exist_box = [True] * count
    res = []

    for _i in range(count):
        i = ordered[_i]
        if not exist_box[i]:
            continue
        if scores[i] < conf:
            exist_box[i] = False
            continue
        res.append(i)
        for _j in range(_i + 1, count):
            j = ordered[_j]
            if not exist_box[j]:
                continue
            ovr = cal_iou(boxes[j], boxes[i])
            if ovr >= nms:
                exist_box[j] = False

    return res

def letterbox(im, w, h):
    scale = min(w / im.shape[1], h / im.shape[0])
    new_w = int(im.shape[1] * scale)
    new_h = int(im.shape[0] * scale)
    
    img_res = cv2.resize(im, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
    
    x = (w - new_w) // 2
    y = (h - new_h) // 2
    om = im.copy()
    om[y:y+new_h, x:x+new_w] = img_res
    
    return om

def correct_region_boxes(boxes, n, w, h, netw, neth):
    new_w = 0
    new_h = 0

    if (netw / w) < (neth / h):
        new_w = netw
        new_h = int((h * netw) / w)
    else:
        new_h = neth
        new_w = int((w * neth) / h)

    for i in range(n):
        boxes[i][0] = (boxes[i][0] - (netw - new_w) / 2.0 / netw) / (new_w / netw)
        boxes[i][1] = (boxes[i][1] - (neth - new_h) / 2.0 / neth) / (new_h / neth)
        boxes[i][2] *= netw / new_w
        boxes[i][3] *= neth / new_h

class Yolov7OnnxResult:
    class BoundingBox:
        def __init__(self, label, score, x, y, width, height):
            self.label = label
            self.score = score
            self.x = x
            self.y = y
            self.width = width
            self.height = height

    def __init__(self, bboxes):
        self.bboxes = bboxes

class Yolov7Onnx:
    def __init__(self, model_name, conf_thresh_):
        # Initialize the model
        self.session = ort.InferenceSession(model_name)
        self.input_tensor_values = []
        self.input_tensors = []
        self.output_tensors = []
        self.input_tensor_ptr = [None]
        self.output_tensor_ptr = [None] * 3
        self.real_batch = 0
        self.batch_size = 0
        self.channel = 0
        self.sHeight = 0
        self.sWidth = 0
        self.conf_thresh = conf_thresh_
        self.conf_desigmoid = -np.log(1.0 / self.conf_thresh - 1.0)
        self.nms_thresh = 0.65
        self.num_classes = 80
        self.anchor_cnt = 3
        self.biases = [12, 16, 19, 36, 40, 28, 36, 75, 76,
                       55, 72, 146, 142, 110, 192, 243, 459, 401]
        self.ws = []
        self.hs = []

    @staticmethod
    def create(model_name, conf_thresh):
        return Yolov7Onnx(model_name, conf_thresh)

    def preprocess_single(self, image, idx):
        resized_image = cv2.resize(image, (self.sWidth, self.sHeight))
        resized_image = cv2.cvtColor(resized_image, cv2.COLOR_BGR2RGB)
        resized_image = resized_image.astype(np.float32)
        resized_image /= 255.0
        resized_image -= [0.00392156, 0.00392156, 0.00392156]

        self.input_tensor_values.extend(resized_image.flatten())
        return

    def preprocess(self, mats):
        self.real_batch = min(self.input_shapes_[0][0], len(mats))
        self.ws = [0] * self.real_batch
        self.hs = [0] * self.real_batch

        for index in range(self.real_batch):
            self.preprocess_single(mats[index], index)
            self.ws[index] = mats[index].shape[1]
            self.hs[index] = mats[index].shape[0]
        return

    @staticmethod
    def sigmoid(src):
        return 1.0 / (1.0 + np.exp(-src))

    def postprocess_single(self, idx):
        boxes = []

        conf_box = 5 + self.num_classes

        for i in range(self.output_tensor_size):
            ch = self.output_shapes_[i][1]
            ha = self.output_shapes_[i][2]
            wa = self.output_shapes_[i][3]
            output_batch = ch * ha * wa

            for h in range(ha):
                for w in range(wa):
                    for c in range(self.anchor_cnt):
                        score = self.output_tensor_ptr[i][c * conf_box + 4 + idx * output_batch]
                        if score < self.conf_desigmoid:
                            continue

                        box = []

                        obj_score = self.sigmoid(score)
                        out = [self.output_tensor_ptr[i][c * conf_box + index + idx * output_batch] for index in range(4)]
                        box.append((w - 0.5 + 2 * self.sigmoid(out[0])) / wa)
                        box.append((h - 0.5 + 2 * self.sigmoid(out[1])) / ha)
                        box.append(np.power(2 * self.sigmoid(out[2]), 2) * self.biases[2 * c + 2 * self.anchor_cnt * i] / float(self.sWidth))
                        box.append(np.power(2 * self.sigmoid(out[3]), 2) * self.biases[2 * c + 2 * self.anchor_cnt * i + 1] / float(self.sHeight))
                        box.append(-1)
                        box.append(obj_score)
                        for p in range(self.num_classes):
                            box.append(obj_score * self.sigmoid(self.output_tensor_ptr[i][c * conf_box + 5 + p + idx * output_batch]))

                        boxes.append(box)

        correct_region_boxes(boxes, len(boxes), self.ws[idx], self.hs[idx], self.sWidth, self.sHeight)

        # Apply NMS
        res = []
        scores = [box[6] for box in boxes]

        for k in range(self.num_classes):
            result_k = apply_nms(boxes, scores, self.nms_thresh, self.conf_thresh)
            res.extend([boxes[k] for k in result_k])

        results = [Yolov7OnnxResult.BoundingBox(
            label=int(box[4]),
            score=box[5],
            x=box[0] - box[2] / 2.0,
            y=box[1] - box[3] / 2.0,
            width=box[2],
            height=box[3]
        ) for box in res]

        return Yolov7OnnxResult(results)

    def postprocess(self):
        ret = [self.postprocess_single(index) for index in range(self.real_batch)]
        return ret

    def run(self, mats):
        self.preprocess(mats)

        if self.input_tensors:
            self.input_tensors[0] = ort.experimental.tensor.from_numpy(np.array(self.input_tensor_values, dtype=np.float32))
        else:
            self.input_tensors.append(ort.experimental.tensor.from_numpy(np.array(self.input_tensor_values, dtype=np.float32)))

        self.run_task(self.input_tensors, self.output_tensors)

        for i in range(self.output_tensor_size):
            self.output_tensor_ptr[i] = ort.experimental.tensor.to_numpy(self.output_tensors[i])

        ret = self.postprocess()
        return ret