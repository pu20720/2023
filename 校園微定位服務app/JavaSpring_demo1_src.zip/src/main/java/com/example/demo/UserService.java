package com.example.demo;

import org.springframework.stereotype.Service;

@Service
public class UserService {
    private final UserRepository repository;

    public UserService(UserRepository repository) {
        this.repository = repository;
    }

    public boolean exists(UserModel user){
        return repository.existsByPhoneNumber(user.getPhoneNumber());
    }
    public UserModel findByPhoneName(UserModel user){
        return repository.findByPhoneNumber(user.getPhoneNumber());
    }
    public boolean insert(UserModel user){
        repository.save(user);
        return true;
    }
    public boolean update(UserModel user){
        if(repository.findById(user.getId()).isEmpty()) return false;
        repository.save(user);
        return true;
    }
    public boolean deleteById(Integer id){
        if(!repository.existsById(id)) return false;
        repository.deleteById(id);
        return true;
    }
}