package com.example.demo;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/")
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class UserController {
    private final UserService service;

//    public UserController(UserService service) {
//        this.service = service;
//    }

    //@RequestMapping("/userphone")
    @PostMapping("/setPhoneNum")
    public ResponseBody SetPhoneNum(@RequestBody UserModel user){
        if(service.exists(user)){
            UserModel u = service.findByPhoneName(user);
            return new ResponseBody(u != null ? ResponseCode.SIGN_IN_SUCCESS : ResponseCode.SIGN_IN_FAILED, u != null ? u.getId() : "");
        }
        return new ResponseBody(service.insert(user) ? ResponseCode.SIGN_UP_SUCCESS : ResponseCode.SIGN_UP_FAILED, "");
    }
    @PutMapping("/update")
    public ResponseBody update(@RequestBody UserModel user){
        return new ResponseBody(service.update(user) ? ResponseCode.UPDATE_SUCCESS : ResponseCode.UPDATE_FAILED, "");
    }
    @DeleteMapping("/delete")
    public ResponseBody deleteByPhoneNum(@RequestBody int id){
        return new ResponseBody(service.deleteById(id) ? ResponseCode.DELETE_SUCCESS : ResponseCode.DELETE_FAILED, "");
    }
    @GetMapping("/TestCase")
    public String test(){
        return "Test";
    }
}