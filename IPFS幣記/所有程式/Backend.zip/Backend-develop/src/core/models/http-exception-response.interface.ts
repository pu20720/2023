export interface CustomHttpExceptionResponse {
  statusCode: number;
  error: string;
}
