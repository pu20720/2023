export interface JwtUser {
  id: number;
}
