export default () => ({
  ipfsHost: process.env.IPFS_HOST,
});
