<?php

namespace Lab515\Lib;

use Exception;
use GuzzleHttp\Client;
use Lab515\Config\Config;

class Openwrt
{
    // 預設的 session
    private $section = Config::WRT['api']['section'];

    // 呼叫的客戶端
    private $client;
    /**
     * 共用呼叫 client
     */
    public function __construct()
    {
        $this->client = new Client([
            'base_uri' => Config::WRT['api']['uri'],
            'timeout' => Config::WRT['api']['timeout'],
        ]);
    }

    
    public function monitorTraffic()
    {
        $token = $this->auth();
        $data = [
            "method" => "net.conntrack"
        ];
        $request = $this->client->post('sys', [
            'query' => ['auth' => $token],
            'json' => $data
        ]);

        $contents = $request->getBody()->getContents();
        $req = json_decode($contents, true);
        return $req['result'];
    }
    /**
     * 登入獲取 token
     * @return  string   token     身份通行證
     */
    public function auth()
    {
        $data = [
            "method" => "login",
            "params" => [
                Config::WRT['admin']['account'],
                Config::WRT['admin']['password']
            ]
        ];
        $request = $this->client->request('POST', 'auth', [
            'json' => $data
        ]);

        $contents = $request->getBody()->getContents();
        $req = json_decode($contents, true);
        return $req['result'];
    }

    /**
     * 防火牆目前政策
     * @return  array   防火牆 IP
     */
    public function fireWareList()
    {
        $token = $this->auth();
        $section = $this->section;
        $data = [
            "method" => "get",
            "params" => [
                "firewall", $section, "src_ip"
            ]
        ];
        $request = $this->client->post('uci', [
            'query' => ['auth' => $token],
            'json' => $data
        ]);

        $contents = $request->getBody()->getContents();
        $req = json_decode($contents, true);
        return $req['result'];
    }

    /**
     * 新增黑名單 IP
     * @param   string      $ipAddress  黑名單 IP
     * @throws  Exception   addDelIp    失敗回應
     * @return  void
     */
    public function addDelIP(string $ipAddress)
    {
        $IPs = $this->fireWareList();
        if (Config::WRT['api']['ip'] == $ipAddress) {
            throw new Exception("不能將 OpenWRT 主機 IP 設為黑名單");
        }
        $key = array_search($ipAddress, $IPs);
        if ($key === true) {
            throw new Exception("不能重複新增已變成黑名單的 IP");
        }
        array_push($IPs, $ipAddress);
        // file_put_contents('test3.json', json_encode($IPs));
        $token = $this->auth();
        $section = $this->section;
        $data = [
            "method" => "set",
            "params" => [
                "firewall",
                $section,
                "src_ip",
                $IPs
            ]
        ];
        $request = $this->client->post('uci', [
            'query' => ['auth' => $token],
            'json' => $data
        ]);
        $this->commit($token);
        $contents = $request->getBody()->getContents();
        $req = json_decode($contents, true);
        if (!$req['result']) {
            throw new Exception("addDelIp error");
        }
    }

    // /**
    //  * 刪除防火牆 IP
    //  * 
    //  * @param   string       $ipAddress     預刪除的 IP
    //  * @throws  Exception    回應錯誤對應訊息
    //  * @return void
    //  */
    // public function delWhiteIP(string $ipAddress)
    // {
    //     $token = $this->auth();
    //     // $section = $this->addWhiteIPSection($token);
    //     $section = $this->section;
    //     try {
    //         $this->setName($token, $section);
    //         $this->delSrcIP($token, $section, $ipAddress);
    //         $this->setSrc($token, $section);
    //         $this->setDestIP($token, $section);
    //         $this->setDestLan($token, $section);
    //         $this->setTargetAccept($token, $section);
    //         $this->commit($token);
    //     } catch (Exception $e) {
    //         throw new Exception($e->getMessage());
    //     }
    // }

    // /**
    //  * 新增防火牆 IP
    //  * 
    //  * @param   string       $ipAddress     預新增的 IP
    //  * @throws  Exception    回應錯誤對應訊息
    //  * @return void
    //  */
    // public function addWhiteIP(string $ipAddress)
    // {
    //     $token = $this->auth();
    //     // $section = $this->addWhiteIPSection($token);
    //     $section = $this->section;
    //     try {
    //         $this->setName($token, $section);
    //         $this->setSrcIP($token, $section, $ipAddress);
    //         $this->setSrc($token, $section);
    //         $this->setDestIP($token, $section);
    //         $this->setDestLan($token, $section);
    //         $this->setTargetAccept($token, $section);
    //         $this->commit($token);
    //     } catch (Exception $e) {
    //         throw new Exception($e->getMessage());
    //     }
    // }

    // /**
    //  * 新增 section ，做為通行證用於處理防火牆資料
    //  * @param   string   $token     身份通行證
    //  * @return  string   section   新增的 section 名稱
    //  */
    // public function addWhiteIPSection(string $token)
    // {
    //     $data = [
    //         "method" => "add",
    //         "params" => [
    //             "firewall",
    //             "rule"
    //         ]
    //     ];
    //     $request = $this->client->post('uci', [
    //         'query' => ['auth' => $token],
    //         'json' => $data
    //     ]);
    //     $contents = $request->getBody()->getContents();
    //     $req = json_decode($contents, true);
    //     return $req['result'];
    // }

    // /**
    //  * 設定 rule 名字
    //  * @param   string      $token      身份通行證
    //  * @param   string      $section    section 名稱
    //  * @throws  Exception   setName     失敗回應
    //  * @return  void
    //  */
    // public function setName(string $token, string $section)
    // {
    //     $data = [
    //         "method" => "set",
    //         "params" => [
    //             "firewall",
    //             $section,
    //             "name",
    //             "white_ip"
    //         ]
    //     ];
    //     $request = $this->client->post('uci', [
    //         'query' => ['auth' => $token],
    //         'json' => $data
    //     ]);
    //     $contents = $request->getBody()->getContents();
    //     $req = json_decode($contents, true);
    //     if (!$req['result']) {
    //         throw new Exception("setName error");
    //     }
    // }

    // /**
    //  * 刪除來源端IP
    //  * @param   string      $token      身份通行證
    //  * @param   string      $section    section 名稱
    //  * @param   string      $ip         刪除的防火牆 IP
    //  * @throws  Exception   setSrcIP    失敗回應
    //  * @return  void
    //  */
    // public function delSrcIP(string $token, string $section, string $ip)
    // {
    //     $IPs = $this->fireWareList();
    //     if (Config::WRT['api']['ip'] == $ip) {
    //         throw new Exception("不能刪除 OpenWRT 主機 IP");
    //     }
    //     $key = array_search($ip, $IPs);
    //     $IPsResult = [];
    //     if ($key !== false) {
    //         unset($IPs[$key]);
    //         foreach ($IPs as $ip) {
    //             array_push($IPsResult, $ip);
    //         }
    //     } else {
    //         throw new Exception("不存在此 IP");
    //     }
    //     file_put_contents('test3.json', json_encode($IPsResult));
    //     $data = [
    //         "method" => "set",
    //         "params" => [
    //             "firewall",
    //             $section,
    //             "src_ip",
    //             $IPsResult
    //         ]
    //     ];
    //     $request = $this->client->post('uci', [
    //         'query' => ['auth' => $token],
    //         'json' => $data
    //     ]);
    //     $contents = $request->getBody()->getContents();
    //     $req = json_decode($contents, true);
    //     if (!$req['result']) {
    //         throw new Exception("delSrcIP error");
    //     }
    // }

    // /**
    //  * 設定來源端IP
    //  * @param   string      $token      身份通行證
    //  * @param   string      $section    section 名稱
    //  * @param   string      $ip         新增的防火牆 IP
    //  * @throws  Exception   setSrcIP    失敗回應
    //  * @return  void
    //  */
    // public function setSrcIP(string $token, string $section, string $ip)
    // {
    //     $IPs = $this->fireWareList();
    //     array_push($IPs, $ip);
    //     $data = [
    //         "method" => "set",
    //         "params" => [
    //             "firewall",
    //             $section,
    //             "src_ip",
    //             $IPs
    //         ]
    //     ];
    //     $request = $this->client->post('uci', [
    //         'query' => ['auth' => $token],
    //         'json' => $data
    //     ]);
    //     $contents = $request->getBody()->getContents();
    //     $req = json_decode($contents, true);
    //     if (!$req['result']) {
    //         throw new Exception("setSrcIP error");
    //     }
    // }

    // /**
    //  * 設定來源端設備位置
    //  * @param   string      $token      身份通行證
    //  * @param   string      $section    section 名稱
    //  * @throws \Exception   setSrc      失敗回應
    //  * @return void
    //  */
    // public function setSrc(string $token, string $section)
    // {
    //     $data = [
    //         "method" => "set",
    //         "params" => [
    //             "firewall",
    //             $section,
    //             "src",
    //             "wan"
    //         ]
    //     ];
    //     $request = $this->client->post('uci', [
    //         'query' => ['auth' => $token],
    //         'json' => $data
    //     ]);
    //     $contents = $request->getBody()->getContents();
    //     $req = json_decode($contents, true);

    //     if (!$req['result']) {
    //         throw new Exception("setSrc error");
    //     }
    // }

    // /**
    //  * 設定目的端IP
    //  * @param   string      $token      身份通行證
    //  * @param   string      $section    section 名稱
    //  * @throws  Exception   setDestIP   失敗回應
    //  * @return  void
    //  */
    // public function setDestIP(string $token, string $section)
    // {
    //     $data = [
    //         "method" => "set",
    //         "params" => [
    //             "firewall",
    //             $section,
    //             "dest_ip",
    //             Config::WRT['api']['ip']
    //         ]
    //     ];
    //     $request = $this->client->post('uci', [
    //         'query' => ['auth' => $token],
    //         'json' => $data
    //     ]);
    //     $contents = $request->getBody()->getContents();
    //     $req = json_decode($contents, true);

    //     if (!$req['result']) {
    //         throw new Exception("setDestIP error");
    //     }
    // }

    // /**
    //  * 設定目的端設備位置
    //  * @param   string      $token      身份通行證
    //  * @param   string      $section    section 名稱
    //  * @throws  Exception   setDestLan  失敗回應
    //  * @return  void
    //  */
    // public function setDestLan(string $token, string $section)
    // {
    //     $data = [
    //         "method" => "set",
    //         "params" => [
    //             "firewall",
    //             $section,
    //             "dest",
    //             "lan"
    //         ]
    //     ];
    //     $request = $this->client->post('uci', [
    //         'query' => ['auth' => $token],
    //         'json' => $data
    //     ]);
    //     $contents = $request->getBody()->getContents();
    //     $req = json_decode($contents, true);

    //     if (!$req['result']) {
    //         throw new Exception("setDestLan error");
    //     }
    // }

    // /**
    //  * 設定目標 IP
    //  * @param   string      $token      身份通行證
    //  * @param   string      $section    section 名稱
    //  * @throws  Exception   setTargetAccept 失敗回應
    //  * @return  void
    //  */
    // public function setTargetAccept(string $token, string $section)
    // {
    //     $data = [
    //         "method" => "set",
    //         "params" => [
    //             "firewall",
    //             $section,
    //             "target",
    //             "ACCEPT"
    //         ]
    //     ];
    //     $request = $this->client->post('uci', [
    //         'query' => ['auth' => $token],
    //         'json' => $data
    //     ]);
    //     $contents = $request->getBody()->getContents();
    //     $req = json_decode($contents, true);

    //     if (!$req['result']) {
    //         throw new Exception("setTargetAccept error");
    //     }
    // }

    /**
     * 設置 rule 確認
     * @param   string      $token      身份通行證
     * @throws  Exception   commit      失敗回應
     * @return  void
     */
    public function commit(string $token)
    {
        $data = [
            "method" => "commit",
            "params" => [
                "firewall"
            ]
        ];
        $request = $this->client->post('uci', [
            'query' => ['auth' => $token],
            'json' => $data
        ]);
        $contents = $request->getBody()->getContents();
        $req = json_decode($contents, true);

        if (!$req['result']) {
            throw new Exception("commit error");
        }
    }
}
