<?php

require_once __DIR__ . '/../vendor/autoload.php';

use Lab515\Lib\Common;
use LINE\LINEBot\MessageBuilder\TemplateBuilder;
use LINE\LINEBot\MessageBuilder\TemplateBuilder\ButtonTemplateBuilder;
use LINE\LINEBot\MessageBuilder\TemplateBuilder\CarouselColumnTemplateBuilder;
use LINE\LINEBot\MessageBuilder\TemplateBuilder\CarouselTemplateBuilder;
use LINE\LINEBot\MessageBuilder\TemplateBuilder\ConfirmTemplateBuilder;
use LINE\LINEBot\MessageBuilder\TemplateMessageBuilder;
use LINE\LINEBot\MessageBuilder\TextMessageBuilder;
use LINE\LINEBot\TemplateActionBuilder\MessageTemplateActionBuilder;
use LINE\LINEBot\TemplateActionBuilder\PostbackTemplateActionBuilder;
use LINE\LINEBot\Event\MessageEvent\TextMessage;

use Lab515\Config\Config;

$common = new Common();
$bot = $common->init();

$HttpRequestBody = file_get_contents('php://input');
//先判斷存不存在此 Header 資訊，這是 Line 官方自訂的 Header
if (!isset($_SERVER['HTTP_X_LINE_SIGNATURE'])) {
    //並不是LINE官方伺服器發送的請求，轉送到靜宜校網
    header('Location: https://www.pu.edu.tw/');
    exit;
} else {
    //驗證來源是否是LINE官方伺服器
    $common->checkSource($HttpRequestBody, $_SERVER['HTTP_X_LINE_SIGNATURE']);
}

$data = json_decode($HttpRequestBody, true);

//取得事件類型
try {
    foreach ($data['events'] as $Event) {
        $groupId = $Event['source']['groupId'];
        if ($Event['message']['text'] == '/group') {
            $textMessageBuilder = new TextMessageBuilder("群組ID：" . $groupId);
            $bot->replyMessage(
                $Event['replyToken'],
                $textMessageBuilder
            );
        }

        if (!in_array($groupId, Config::SUPER['groups'])) {
            $textMessageBuilder = new TextMessageBuilder("此群組不具控制防火牆權限，請通知管理員");
            $bot->replyMessage(
                $Event['replyToken'],
                $textMessageBuilder
            );
        }

        //當bot收到任何訊息
        if ($Event['type'] == 'message') {
            // 拆分指令與參數
            // /add 1.1.1.1
            // 將會拆成
            // /add    ，也就是 $parts[0]
            // 1.1.1.1 ，也就是 $parts[1]
            $parts = explode(' ', $Event['message']['text']);
            $command = $parts[0];
            if ($command == '/add') {
                $ipAddress = $parts[1];
                $textMessageBuilder = new TextMessageBuilder("以新增 IP 為 $ipAddress");
                $bot->replyMessage(
                    $Event['replyToken'],
                    $textMessageBuilder
                );
            } elseif ($command == '/del') {
                $ipAddress = $parts[1];
                $textMessageBuilder = new TextMessageBuilder("已刪除 IP 為$ipAddress");
                $bot->replyMessage(
                    $Event['replyToken'],
                    $textMessageBuilder
                );
            } elseif ($command == '/list') {
                $textMessageBuilder = new TextMessageBuilder("以上是目前防火牆以新增的 IP 清單");
                $bot->replyMessage(
                    $Event['replyToken'],
                    $textMessageBuilder
                );
            } else {
                $textMessageBuilder = new TextMessageBuilder("無效指令");
                $bot->replyMessage(
                    $Event['replyToken'],
                    $textMessageBuilder
                );
            }
            // file_put_contents('a333.json', json_encode($parts, FILE_APPEND));
            // if ($Event['message']["text"] == '?') {
            //     $textMessageBuilder = new TextMessageBuilder('這是文字測試');
            //     $bot->replyMessage(
            //         $Event['replyToken'],
            //         $textMessageBuilder
            //     );
            // } elseif ($Event['message']['text'] == '+') {
            //     $buttonTemplateBuilder = new ButtonTemplateBuilder(
            //         "是否開工防火牆?",
            //         "Please select an action:",
            //         "https://i.imgur.com/shVGdJR.png",
            //         [
            //             new PostbackTemplateActionBuilder("Postback Action", "action=buy&itemid=1"),
            //             new MessageTemplateActionBuilder("Message Action", "You have selected Message Action"),
            //             new MessageTemplateActionBuilder("Open URL", "./img/fireware.jpg"),
            //         ]
            //     );
            //     $templateMessageBuilder = new TemplateMessageBuilder("Buttons Template", $buttonTemplateBuilder);
            //     $groupId = $Event['source']['groupId'];// 將這裡的YOUR_GROUP_ID替換為您的群組ID

            //     $response = $bot->pushMessage($groupId, $templateMessageBuilder);
            //     file_put_contents('123.json',
            //         $response); //錯誤內容

            //     echo $response->getHTTPStatus() . ' ' . $response->getRawBody();
            // } else if ($Event['message']['text'] == '-'){
            //     $confirmTemplateBuilder = new ConfirmTemplateBuilder(
            //         "是否要開通防火牆",
            //         [
            //             new PostbackTemplateActionBuilder("Yes", "action=open&step=yes"),
            //             new PostbackTemplateActionBuilder("No", "action=open&step=no"),
            //         ]);
            //     $templateMessageBuilder = new TemplateMessageBuilder("Confirm Template", $confirmTemplateBuilder);
            //     $bot->replyMessage(
            //         $Event['replyToken'],
            //         $templateMessageBuilder
            //     );
            // }
        } elseif ($Event['type'] == 'postback') {
            file_put_contents('postback.json', json_encode($Event, true));
        }
    }
} catch (Exception $e) {
    file_put_contents('error.log', json_encode($e->getMessage()), FILE_APPEND); //錯誤內容
}
file_put_contents('alldata.json', $HttpRequestBody);
