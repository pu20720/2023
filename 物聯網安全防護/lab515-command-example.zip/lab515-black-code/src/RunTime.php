<?php

require_once __DIR__ . '/../vendor/autoload.php';

use Lab515\Lib\Common;
use Lab515\Lib\Openwrt;
use Lab515\Config\Config;
use LINE\LINEBot\MessageBuilder\TextMessageBuilder;

$common = new Common();
$bot = $common->init();

ignore_user_abort(); //關閉瀏覽器後，繼續執行php程式碼
set_time_limit(0); //程式執行時間無限制
$sleep_time = Config::WRT['sleep']; //多長時間執行一次
$switch = true;
$wrt = new Openwrt();
while ($switch) {
    $msg = date("Y-m-d H:i:s") . $switch;
    $IPs = $wrt->monitorTraffic();
    for ($i = 0; $i < count($IPs); $i++) {
        if ($IPs[$i]['bytes'] > Config::WRT['limit']) {
            $groupId = Config::ADMIN['groupId'];
            $limit = Config::WRT['limit'];
            $src = $IPs[$i]['src'];
            $dport = $IPs[$i]['dport'];
            $bytes = $IPs[$i]['bytes'];
            $message =  "流量超過指定 bytes：$limit\r\n" .
                "src：$src\r\n" .
                "dport：$dport\r\n" .
                "bytes：$bytes\r\n";
            file_put_contents("log/record.log", $message . "\r\n", FILE_APPEND);
            $textMessageBuilder = new TextMessageBuilder($message);
            $response = $bot->pushMessage($groupId, $textMessageBuilder);
            $res =  json_encode($IPs[$i]);
            file_put_contents("log/req.log", $res . "\r\n", FILE_APPEND);
        }
    }
    $msg = date("Y-m-d H:i:s") . "\r\n";
    file_put_contents("log/req.log", $msg . "睡眠5秒\r\n", FILE_APPEND);
    sleep($sleep_time); //等待時間，進行下一次操作。
}
exit();
