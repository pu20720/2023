# lab515
專題
## 目前指令
指令必須加一個 /
不然都會認定為一般訊息
```bash

# 新增防火牆黑名單 IP
## 要為合法的 IP，
## 合法的 IPv4
## 要求值不在 RFC 指定的私有範圍 IP 內
## 不符合即回應 "IP 輸入不正確"
## https://www.runoob.com/php/filter-validate-ip.html
/block ip

# 觀看目前防火牆 IP 清單
/list

# 查看群組 ID
/showGroupId

# 剩餘皆會回應 無效指令
```

## 初始化
```php
# 專案安裝
composer install

# 複製設定檔
cp src\Config\Config.php.example src\Config\Config.php

# 修改設定檔
# ChannelSecret
# Line 的 Channel secret 
# TOP->{YourId}->{BotName}-> Basic settings

# ChannelAccessToken
# Line 的 Channel access token
# TOP->{YourId}->{BotName}->Messaging API

# ADMIN 群組 ID，此群組才能夠控制機器人
# 下 /showGroupId 查看群組 ID

# WRT API資訊
## OpenWRT 主機資訊 api
## OpenWRT 帳號密碼 admin
## OpenWRT 主機輪尋間隔 sleep
## OpenWRT 主機 bytes 警報線 limit
```
## 設置警報
```bash
# 進入到檔案位置
cd 515/src
# 背景執行
php Runtime.php &

# 要終止它，把叫到前景終止它
fg
# 下 ctrl + c
```
## 設定網頁伺服器
### 設定掛勾 webhook
## 祝你有美好的一天
