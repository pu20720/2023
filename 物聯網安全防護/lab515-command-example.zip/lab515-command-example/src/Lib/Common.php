<?php

namespace Lab515\Lib;

use LINE\LINEBot;
use LINE\LINEBot\HTTPClient\CurlHTTPClient;
use Lab515\Config\Config;

class Common
{
    public function init()
    {
        $httpClient = new CurlHTTPClient(Config::Token);
        $bot = new LINEBot($httpClient, ['channelSecret' => Config::SECRET]);
        return $bot;
    }
    //檢查是否是Line 官方 API 請求
    public function checkSource($HttpRequestBody, $HeaderSignature)
    {
        $Hash = hash_hmac('sha256', $HttpRequestBody, Config::SECRET, true);
        $HashSignature = base64_encode($Hash);
        if ($HashSignature != $HeaderSignature) {
            //偉造LINE官方伺服器發送的請求，轉送到靜宜校網
            header('Location: https://www.pu.edu.tw/');
            exit;
        }
    }
}
