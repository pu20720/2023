<?php

require_once __DIR__ . '/../vendor/autoload.php';

use Lab515\Lib\Common;
use Lab515\Events\ManageIP;
use Lab515\Events\Access;

$common = new Common();
$bot = $common->init();

$manageIP = new ManageIP();
$access = new Access();

$HttpRequestBody = file_get_contents('php://input');
//先判斷存不存在此 Header 資訊，這是 Line 官方自訂的 Header
if (!isset($_SERVER['HTTP_X_LINE_SIGNATURE'])) {
    //並不是LINE官方伺服器發送的請求，轉送到靜宜校網
    header('Location: https://www.pu.edu.tw/');
    exit;
} else {
    //驗證來源是否是LINE官方伺服器
    $common->checkSource($HttpRequestBody, $_SERVER['HTTP_X_LINE_SIGNATURE']);
}

$data = json_decode($HttpRequestBody, true);

//取得事件類型
try {
    foreach ($data['events'] as $Event) {
        $userId = $Event['source']['userId'];
        if (substr($Event['message']['text'], 0, 1) !== '/') {
            return;
        }

        // 如果有新增使用者，先處理
        // 拆分指令與參數
        // /add 1.1.1.1
        // 將會拆成
        // /useradd       ，也就是 $parts[0]
        // admin,password ，也就是 $parts[1]
        $parts = explode(' ', $Event['message']['text']);
        $command = $parts[0];
        if ($command == '/useradd') {
            $access->userAdd($Event['replyToken'], $parts[1], $userId);
        }

        // 檢查是否有權限
        $access->checkUser($Event['replyToken'], $userId);

        //當bot收到任何訊息
        if ($Event['type'] == 'message') {
            // 拆分指令與參數
            // /add 1.1.1.1
            // 將會拆成
            // /add    ，也就是 $parts[0]
            // 1.1.1.1 ，也就是 $parts[1]
            $parts = explode(' ', $Event['message']['text']);
            $command = $parts[0];
            // 新增 IP
            if ($command == '/add') {
                $ipAddress = $parts[1];
                $manageIP->addIP($Event['replyToken'], $ipAddress);
                // 刪除 IP
            } elseif ($command == '/del') {
                $ipAddress = $parts[1];
                $manageIP->delIP($Event['replyToken'], $ipAddress);
                // 列出 IP
            } elseif ($command == '/list') {
                $manageIP->listIP($Event['replyToken']);
                // 回應找不到
            } else {
                $manageIP->commandNotFound($Event['replyToken']);
            }
        } elseif ($Event['type'] == 'postback') {
            file_put_contents('log/postback.json', json_encode($Event, true));
        }
    }
} catch (Exception $e) {
    file_put_contents('log/error.log', json_encode($e->getMessage()), FILE_APPEND); //錯誤內容
}
file_put_contents('log/alldata.json', $HttpRequestBody);
