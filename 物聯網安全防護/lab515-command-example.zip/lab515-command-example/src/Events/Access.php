<?php

namespace Lab515\Events;

use Lab515\Lib\Common;
use Lab515\Config\Config;
use LINE\LINEBot\MessageBuilder\TextMessageBuilder;

class Access
{
    private $bot;
    public function __construct()
    {
        $common = new Common();
        $this->bot = $common->init();
    }

    /**
     * 新增指定白名單 IP 
     * @param   string      $replyToken     傳送回復對象
     * @param   string      $userData       系統帳號密碼
     * @param   string      $userId       使用者 ID
     * @return  void
     */
    public function userAdd(string $replyToken, string $userData, string $userId)
    {
        // 拆分參數
        // admin,password
        // admin            ，也就是 $user[0]
        // password         ，也就是 $user[1]
        $user = explode(',', $userData);
        if (
            $user[0] == Config::ADMIN['account']
            &&
            $user[1] == Config::ADMIN['password']
        ) {
            $filePath = "users/";
            file_put_contents($filePath . $userId, $userId);
            $this->textMessage($replyToken, "已新增");
        } else {
            $this->textMessage($replyToken, "無法新增，請通知管理員協助");
        }
    }
    /**
     * 檢查使用者是否具有權限
     * @param   string      $replyToken   傳送回復對象
     * @param   string      $userId       使用者 ID
     * @return  void
     */
    public function checkUser(string $replyToken, $userId)
    {
        // 資料夾路徑
        $folderPath = 'users';
        // 使用 scandir 函數獲取資料夾中的所有檔案和資料夾名稱
        $files = scandir($folderPath);

        if (!in_array($userId, $files)) {
            $this->textMessage($replyToken, "此帳號不具控制防火牆權限，請通知管理員");
        }
    }
    /**
     * 傳送文字訊息
     * @param   string  $replyToken     傳送回復對象
     * @param   string  $message        傳送訊息內容
     * @return  void
     */
    public function textMessage(string $replyToken, string $message): void
    {
        $textMessageBuilder = new TextMessageBuilder($message);
        $this->bot->replyMessage(
            $replyToken,
            $textMessageBuilder
        );
    }
}
