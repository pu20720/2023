<?php

namespace Lab515\Events;

use Exception;
use Lab515\Lib\Common;
use Lab515\Lib\Openwrt;
use LINE\LINEBot\MessageBuilder\TextMessageBuilder;

class ManageIP
{
    private $bot;
    private $wrt;
    public function __construct()
    {
        $common = new Common();
        $this->bot = $common->init();
        $this->wrt = new Openwrt();
    }
    /**
     * 列防火牆清單
     * @param   string      $replyToken     傳送回復對象
     * @return  void
     */
    public function listIP(string $replyToken)
    {
        $result = $this->wrt->fireWareList();
        $IPs = "";
        foreach ($result as $ip) {
            $IPs .= $ip . "\n";
        }
        $this->textMessage($replyToken, "$IPs 目前防火牆已新增的 IP 清單");
    }
    /**
     * 新增指定白名單 IP 
     * @param   string      $replyToken     傳送回復對象
     * @param   string      $ipAddress      將進行新增的 IP
     * @return  void
     */
    public function addIP(string $replyToken, string $ipAddress)
    {
        try {
        $this->checkIP($replyToken, $ipAddress);
        $this->wrt->addWhiteIP($ipAddress);
        $this->textMessage($replyToken, "已新增 IP 為 $ipAddress");
        } catch (Exception $e) {
            $this->textMessage($replyToken, $e->getMessage());
        }
    }
    /**
     * 刪除指定白名單 IP 
     * @param   string      $replyToken     傳送回復對象
     * @param   string      $ipAddress      將進行刪除的 IP
     * @return  void
     */
    public function delIP(string $replyToken, string $ipAddress)
    {
        try {
            $this->checkIP($replyToken, $ipAddress);
            $this->wrt->delWhiteIP($ipAddress);
            $this->textMessage($replyToken, "已刪除 IP 為 $ipAddress");
        } catch (Exception $e) {
            $this->textMessage($replyToken, $e->getMessage());
        }
    }
    /**
     * 無效指令
     * @param string $replyToken
     * @return void
     */
    public function commandNotFound(string $replyToken)
    {
        $this->textMessage($replyToken, "無效指令");
    }
    /**
     * 傳送文字訊息
     * @param   string  $replyToken     傳送回復對象
     * @param   string  $message        傳送訊息內容
     * @return  void
     */
    public function textMessage($replyToken, $message): void
    {
        $textMessageBuilder = new TextMessageBuilder($message);
        $this->bot->replyMessage(
            $replyToken,
            $textMessageBuilder
        );
    }
    /**
     * 要為合法的 IP
     * 合法的 IPv4
     * 要求值不在 RFC 指定的私有範圍 IP 內
     * 
     * @param   string      $replyToken     傳送回復對象
     * @param   string      $ipAddress      檢查 IP
     * @return  void
     */
    public function checkIP(string $replyToken, string $ipAddress)
    {
        if (
            !filter_var(
                $ipAddress,
                FILTER_VALIDATE_IP,
                FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE
            )
            || $ipAddress === '0.0.0.0'
        ) {
            $this->textMessage($replyToken, "IP 輸入不正確");
        }
    }
}
