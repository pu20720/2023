# lab515
專題
## 目前指令
指令必須加一個 /
不然都會認定為一般訊息
```bash
# 新增可使用此機器人的使用者
# 帳號密碼為設定檔的 ADMIN
/useradd 系統帳號,密碼

# 新增防火牆 IP
## 要為合法的 IP，
## 合法的 IPv4
## 要求值不在 RFC 指定的私有範圍 IP 內
## 不符合即回應 "IP 輸入不正確"
## https://www.runoob.com/php/filter-validate-ip.html
/add ip

# 觀看目前防火牆 IP 清單
/list

# 刪除指定列表 IP
/del 數字

# 剩餘皆會回應 無效指令
```

## 初始化
```php
# 專案安裝
composer install

# 複製設定檔
cp src\Config\Config.php.example src\Config\Config.php

# 修改設定檔
# ChannelSecret
# Line 的 Channel secret 
# TOP->{YourId}->{BotName}-> Basic settings

# ChannelAccessToken
# Line 的 Channel access token
# TOP->{YourId}->{BotName}->Messaging API

# ADMIN 帳號密碼，此帳號用於新增使用者可使用此機器人

# WRT API資訊 ，OpenWRT 主機資訊
```
## 設定網頁伺服器
### 設定掛勾 webhook
## 祝你有美好的一天
