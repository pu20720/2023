package com.example.finalproject;


import java.net.URL;


import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
public class MYTSRegister extends Activity 
{
	Button myregister;
	EditText account;
	EditText mypwd;

	
	public static MYTSRegister rent;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.myregister);

		rent = this;

		Resources res = getResources();

		if (android.os.Build.VERSION.SDK_INT > 9) {
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}

		myregister = (Button) findViewById(R.id.mregister);

		//addr, id, sex, phone, mail
		account = (EditText) findViewById(R.id.account);
		mypwd = (EditText) findViewById(R.id.mypwd);


		//check login
        myregister.setOnClickListener(new View.OnClickListener() {

			public void onClick(View view) {

					Toast.makeText(view.getContext(), "註冊成功", Toast.LENGTH_LONG).show();

			}

		});
	}
}
