package com.example.finalproject;


import java.net.URL;


import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MYTSLogin extends Activity 
{
	Button mylogin;


	EditText account;
	EditText mypwd;

	

	
	public static MYTSLogin rent;




	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.myts);

		rent = this;

		Resources res = getResources();

		if (android.os.Build.VERSION.SDK_INT > 9) {
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}

		account = (EditText) findViewById(R.id.account);
		mypwd = (EditText) findViewById(R.id.mypwd);

		mylogin = findViewById(R.id.mylogin);


		//check login
		mylogin.setOnClickListener(new View.OnClickListener() {

				public void onClick(View view)
				{
					Intent app = new Intent(MYTSLogin.this, MainActivity.class);
					Bundle ndata = new Bundle();
					ndata.putString("user", account.getText().toString());
					app.putExtras(ndata);
					startActivity(app);
				}
		});

        Button mylogin2 = (Button) findViewById(R.id.mylogin2);

        //check login
        mylogin2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view)
            {
                Intent app = new Intent(MYTSLogin.this, MYTSRegister.class);
                startActivity(app);
            }
        });

	}
	
	//if press back, return to android code
    public boolean onKeyDown(int keyCode, KeyEvent event) 
    {
    	if(keyCode==KeyEvent.KEYCODE_BACK)
    	{  
    		android.os.Process.killProcess(android.os.Process.myPid());           
            finish();
    		return true;
    	}
		
		return super.onKeyDown(keyCode, event);  
    }
    
    
}
